<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_st_meter_air extends CI_Model {
    public function get_by_id($id) {
        return $this->db->get_where('t_st_meter_air', ['id' => $id])->row();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('t_st_meter_air', $data);
    }

    public function read_sent_for_penera($id_pegawai) {
        $this->db->select('t_st_meter_air.*, m_pt_meter_air.nama_pt');
        $this->db->from('t_st_meter_air');
        $this->db->join('m_pt_meter_air', 'm_pt_meter_air.id = t_st_meter_air.id_perusahaan');
        $this->db->where('status_kirim', 1);

        $this->db->group_start();
        $this->db->where('ketua_pelaksana', $id_pegawai);
        $this->db->or_where('pendamping_1', $id_pegawai);
        $this->db->or_where('pendamping_2', $id_pegawai);
        $this->db->or_where('pendamping_3', $id_pegawai);
        $this->db->group_end();
        return $this->db->get();
    }

    public function count($id_pegawai) {
        $this->db->from('t_st_meter_air');
        $this->db->where('status_kirim', 1);
        
        if ($id_pegawai) {
            $this->db->group_start();
            $this->db->where('ketua_pelaksana', $id_pegawai);
            $this->db->or_where('pendamping_1', $id_pegawai);
            $this->db->or_where('pendamping_2', $id_pegawai);
            $this->db->or_where('pendamping_3', $id_pegawai);
            $this->db->group_end();
        }
        return $this->db->count_all_results();
    }
}