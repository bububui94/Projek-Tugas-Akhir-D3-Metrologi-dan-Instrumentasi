<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Welcome to Cerapan Online</title>
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/sb-admin-2.css">
	<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">

	<style>
		html {
			font-family: "Fredoka One", cursive;
			background-color: #fafbff;
		}

		.custom-bg {
			background: linear-gradient(to right, #e2e8f0, #e5e7eb);
		}

		.custom-btn:hover {
			background-color: #f3e8ff !important;
			transition: background-color 0.3s ease-in-out;
		}

		@media (prefers-color-scheme: dark) {
			.custom-bg {
				background: linear-gradient(to left, #1f2937, #1a535c);
				color: white !important;
			}

			.custom-btn {
				background-color: #374151 !important;
				color: white !important;
			}

			.custom-btn:hover {
				background-color: #4b5563 !important;
			}
		}

		.animated-text span {
			display: inline-block;
			transition: transform 0.3s ease;
		}

		.animated-text:hover span:nth-child(odd) {
			transform: translateY(-8px);
		}

		.animated-text:hover span:nth-child(even) {
			transform: translateY(8px);
		}

		.letter-spacing-lg {
			letter-spacing: 5px;
		}
	</style>

	<style>
		.click-btn {
			position: relative;
			display: inline-flex;
			justify-content: center;
			align-items: center;
			width: 120px;
			height: 40px;
			border: none;
			background: transparent;
			color: #ff6b6b;
			/* Your button text color */
			font-size: 25px;
			text-decoration: none;
			cursor: pointer;
			box-sizing: border-box;
			padding: 0;
			user-select: none;
			overflow: visible;
		}

		.click-btn span {
			position: relative;
			display: block;
			width: 100%;
			height: 100%;
			line-height: 40px;
			text-align: center;
		}

		/* Corners border */
		.click-btn::before,
		.click-btn::after,
		.click-btn span::before,
		.click-btn span::after {
			content: "";
			position: absolute;
			width: 8px;
			height: 8px;
			border: 3px solid #ff6b6b;
			opacity: 0;
			transition: all 250ms ease;
			box-sizing: border-box;
		}

		/* Top-left corner */
		.click-btn::before {
			top: 0;
			left: 0;
			border-right: none;
			border-bottom: none;
			transform: translate(-50%, -50%);
		}

		/* Bottom-left corner */
		.click-btn::after {
			bottom: 0;
			left: 0;
			border-right: none;
			border-top: none;
			transform: translate(-50%, 50%);
		}

		/* Top-right corner */
		.click-btn span::before {
			top: 0;
			right: 0;
			border-left: none;
			border-bottom: none;
			transform: translate(50%, -50%);
		}

		/* Bottom-right corner */
		.click-btn span::after {
			bottom: 0;
			right: 0;
			border-left: none;
			border-top: none;
			transform: translate(50%, 50%);
		}

		/* Hover effect: show corners and animate them to position */
		.click-btn:hover::before,
		.click-btn:hover::after,
		.click-btn:hover span::before,
		.click-btn:hover span::after {
			opacity: 1;
			transform: translate(0, 0);
		}

		/* Remove text decoration on hover */
		.click-btn:hover {
			text-decoration: none;
			color: #ff6b6b;
		}
	</style>
</head>

<body>
	<div class="custom-bg text-dark">
		<div class="d-flex align-items-center justify-content-center min-vh-100 px-0">
			<div class="text-center">
				<h3 class="font-weight-bold mb-3 letter-spacing-lg">WELCOME TO</h3>
				<h3 class="font-weight-bold animated-text mb-5 letter-spacing-lg display-4 text-color-5">
					<?php
					$text = 'CERAPAN ONLINE';
					foreach (str_split($text) as $char) {
						echo "<span>" . ($char === ' ' ? '&nbsp;' : $char) . "</span>";
					}
					?>
				</h3>

				<div class="d-flex justify-content-center buttons-wrapper">
					<a class="click-btn font-weight-bold" href="<?= base_url('auth') ?>"><span>LOGIN</span></a>
				</div>
			</div>
		</div>
	</div>
</body>

</html>