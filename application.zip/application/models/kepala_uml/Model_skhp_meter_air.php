<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_skhp_meter_air extends CI_Model {
    public function add($data) {
        return $this->db->insert('t_skhp_meter_air', $data);
    }

    public function read() {
        $this->db->select('t_skhp_meter_air.*, m_pegawai.nama_lengkap, t_st_meter_air.nomor_st, t_cerapan_meter_air.nomor_seri');
        $this->db->from('t_skhp_meter_air');
        $this->db->join('m_pegawai', 'm_pegawai.id = t_skhp_meter_air.id_pegawai');
        $this->db->join('t_st_meter_air', 't_st_meter_air.id = t_skhp_meter_air.id_surat_tugas');
        $this->db->join('t_cerapan_meter_air', 't_cerapan_meter_air.id = t_skhp_meter_air.id_cerapan');
        return $this->db->get();
    }

    public function delete($id) {
        return $this->db->delete('t_skhp_meter_air', ['id' => $id]);
    }

    public function get_by_id($id) {
        return $this->db->get_where('t_skhp_meter_air', ['id' => $id])->row();
    }

    public function get_by_nomor_skhp($nomor_skhp) {
        return $this->db->get_where('t_skhp_meter_air', ['nomor_skhp' => $nomor_skhp])->row();
    }

    public function get_by_surat_tugas($id_surat_tugas) {
        $this->db->where('id_surat_tugas', $id_surat_tugas);
        return $this->db->get('t_skhp_meter_air')->result();
    }

    public function get_cerapan_details($id_cerapan) {
        return $this->db
            ->select('id_perusahaan, id_pegawai')
            ->where('id', $id_cerapan)
            ->get('t_cerapan_meter_air')
            ->row();
    }

    public function already_exists($id_cerapan, $id_surat_tugas) {
        return $this->db->where('id_cerapan', $id_cerapan)
                        ->where('id_surat_tugas', $id_surat_tugas)
                        ->get('t_skhp_meter_air')
                        ->row();
    }

    public function count() {
        return $this->db->count_all('t_skhp_meter_air');
    }
}