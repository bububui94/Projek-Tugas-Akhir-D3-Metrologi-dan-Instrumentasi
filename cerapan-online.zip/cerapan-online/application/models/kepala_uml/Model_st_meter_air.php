<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_st_meter_air extends CI_Model {
    public function add($data) {
        return $this->db->insert('t_st_meter_air', $data);
    }

    public function read() {
        $this->db->select('t_st_meter_air.*, m_pt_meter_air.nama_pt, m_pegawai.nama_lengkap');
        $this->db->from('t_st_meter_air');
        $this->db->join('m_pt_meter_air', 'm_pt_meter_air.id = t_st_meter_air.id_perusahaan');
        $this->db->join('m_pegawai', 'm_pegawai.id = t_st_meter_air.ketua_pelaksana');
        return $this->db->get();
    }

    public function delete($id) {
        return $this->db->delete('t_st_meter_air', ['id' => $id]);
    }

    public function get_by_id($id) {
        return $this->db->get_where('t_st_meter_air', ['id' => $id])->row();
    }

    public function get_by_nomor_st($nomor_st) {
        return $this->db->get_where('t_st_meter_air', ['nomor_st' => $nomor_st])->row();
    }

    public function mark_as_sent($id) {
        return $this->db
            ->where('id', $id)
            ->update('t_st_meter_air', ['status_kirim' => 1]);
    }

    public function count() {
        return $this->db->count_all('t_st_meter_air');
    }
}