<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><strong>Daftar Nozzle</strong></h1>
        </div>
        
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_nozzle"><i class="fa fa-plus"></i> Tambah Nozzle</button>
            <table class="table box table-sm" id="list_nozzle">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-3">NAMA/KODE SPBU</th>
                        <th class="col-1">MEREK</th>
                        <th class="col-2">NOMOR SERI</th>
                        <th class="col-2">JENIS BBM</th>
                        <th class="col-2">STATUS</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $no = 1;
                    foreach ($nozzle as $nz) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $nz->nama_spbu ?></td>
                            <td><?= $nz->merek ?></td>
                            <td><?= $nz->nomor_seri ?></td>
                            <td><?= $nz->jenis_bbm ?></td>
                            <td><?= $nz->status ?></td>

                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_nozzle_<?= $nz->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_nozzle_<?= $nz->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_nozzle_<?= $nz->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <div class="modal fade" id="detail_nozzle_<?= $nz->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail Identitas Nozzle</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Nama/Kode SPBU:</strong> <?= $nz->nama_spbu ?></p>
                                        <p><strong>Merek:</strong> <?= $nz->merek ?></p>
                                        <p><strong>Nomor Seri:</strong> <?= $nz->nomor_seri ?></p>
                                        <p><strong>Tahun Pembuatan:</strong> <?= $nz->tahun_pembuatan ?></p>
                                        <p><strong>Model Tipe:</strong> <?= $nz->model_tipe ?></p>
                                        <p><strong>Jenis Bahan Bakar Minyak:</strong> <?= $nz->jenis_bbm ?></p>
                                        <p><strong>Kapasitas Maksimum:</strong> <?= $nz->kapasitas_max ?> L/min</p>
                                        <p><strong>Kapasitas Minimum:</strong> <?= $nz->kapasitas_min ?> L/min</p>
                                        <p><strong>Tekanan Maksimum:</strong> <?= $nz->tekanan_max ?> MPa</p>
                                        <p><strong>Suhu Minimum:</strong> <?= $nz->suhu_min ?> °C</p>
                                        <p><strong>Suhu Maksimum:</strong> <?= $nz->suhu_max ?> °C</p>
                                        <p><strong>Status:</strong> <?= $nz->status ?></p>
                                        <?php if ($nz->status == 'Sudah Ditera' || $nz->status == 'Sudah Ditera Ulang') : ?>
                                        <p><strong>Sah / Batal:</strong> <?= $nz->sah_batal == 'SAH' ? '<span class="badge badge-success">SAH</span>' : '<span class="badge badge-danger">BATAL</span>' ?></p>
                                        <?php endif ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="edit_nozzle_<?= $nz->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/nozzle/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Edit Identitas Nozzle</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $nz->id ?>">

                                        <div class="form-group">
                                            <label for="spbu_id">Nama/Kode SPBU</label>
                                            <select name="spbu_id" class="form-control" required>
                                                <option value="">-- Pilih SPBU --</option>
                                                <?php foreach ($daftar_spbu as $spbu): ?>
                                                    <option value="<?= $spbu->id ?>" <?= $nz->spbu_id == $spbu->id ? 'selected' : '' ?>><?= $spbu->nama_spbu ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Merek</label>
                                            <input type="text" name="merek" class="form-control" value="<?= $nz->merek ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Seri</label>
                                            <input type="text" name="nomor_seri" class="form-control" value="<?= $nz->nomor_seri ?>" required>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <label>Tahun Pembuatan</label>
                                                <input type="number" name="tahun_pembuatan" class="form-control" value="<?= $nz->tahun_pembuatan ?>" required>
                                            </div>
                                            <div class="col-sm-8">
                                                <label>Model / Tipe</label>
                                                <input type="text" name="model_tipe" class="form-control" value="<?= $nz->model_tipe ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Jenis Bahan Bakar Minyak</label>
                                            <input type="text" name="jenis_bbm" class="form-control" value="<?= $nz->jenis_bbm ?>" required>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label>Kapasitas Minimum</label>
                                                <input type="number" name="kapasitas_min" class="form-control" value="<?= $nz->kapasitas_min ?>" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">L/min</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Kapasitas Maksimum</label>
                                                <input type="number" name="kapasitas_max" class="form-control" value="<?= $nz->kapasitas_max ?>" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">L/min</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Tekanan Maksimum</label>
                                            <input type="number" name="tekanan_max" class="form-control" value="<?= $nz->tekanan_max ?>" required>
                                            <div class="input-group-append">
                                                <span class="input-group-text">MPa</span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label>Suhu Minimum</label>
                                                <input type="number" name="suhu_min" class="form-control" value="<?= $nz->suhu_min ?>" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text"> °C</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Suhu Maksimum</label>
                                                <input type="number" name="suhu_max" class="form-control" value="<?= $nz->suhu_max ?>" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text"> °C</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select class="form-control status" name="status" required>
                                                <option value="">-- Pilih Status --</option>
                                                <option value="Belum Ditera" <?= $nz->status == 'Belum Ditera' ? 'selected' : '' ?>>Belum Ditera</option>
                                                <option value="Sudah Ditera" <?= $nz->status == 'Sudah Ditera' ? 'selected' : '' ?>>Sudah Ditera</option>
                                                <option value="Sudah Ditera Ulang" <?= $nz->status == 'Sudah Ditera Ulang' ? 'selected' : '' ?>>Sudah Ditera Ulang</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="sah_batal">SAH / BATAL</label>
                                            <select class="form-control sah_batal" name="sah_batal">
                                                <option value="">-- Pilih --</option>
                                                <option value="SAH" <?= $nz->sah_batal == 'SAH' ? 'selected' : '' ?>>SAH</option>
                                                <option value="BATAL" <?= $nz->sah_batal == 'BATAL' ? 'selected' : '' ?>>BATAL</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                                    
                            </div>
                        </div>
                    </div>

                        <div class="modal fade" id="delete_nozzle_<?= $nz->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/nozzle/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus Nozzle</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $nz->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus Nozzle ini?</h5>
                                        <p class="text-danger"><strong>Seluruh data</strong> yang terkait dengan Nozzle ini akan ikut terhapus. Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <div class="modal fade" id="add_nozzle" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/nozzle/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Nozzle</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="spbu_id">Nama/Kode SPBU</label>
                            <select name="spbu_id" class="form-control" required>
                                <option value="">-- Pilih SPBU --</option>
                                <?php foreach ($daftar_spbu as $spbu): ?>
                                    <option value="<?= $spbu->id ?>"><?= $spbu->nama_spbu ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Merek</label>
                            <input type="text" name="merek" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Nomor Seri</label>
                            <input type="text" name="nomor_seri" class="form-control" required>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label>Tahun Pembuatan</label>
                                <input type="number" name="tahun_pembuatan" class="form-control" required>
                            </div>
                            <div class="col-sm-8">
                                <label>Model / Tipe</label>
                                <input type="text" name="model_tipe" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Jenis Bahan Bakar Minyak</label>
                            <input type="text" name="jenis_bbm" class="form-control" required>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label>Kapasitas Minimum</label>
                                <div class="input-group">
                                    <input type="text" name="kapasitas_min" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text"> L/min</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>Kapasitas Maksimum</label>
                                <div class="input-group">
                                    <input type="text" name="kapasitas_max" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text"> L/min</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Tekanan Maksimum</label>
                            <div class="input-group">
                                <input type="text" name="tekanan_max" class="form-control" required>
                                <div class="input-group-append">
                                    <span class="input-group-text"> MPa</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label>Suhu Minimum</label>
                                <div class="input-group">
                                    <input type="text" name="suhu_min" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text"> °C</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>Suhu Maksimum</label>
                                <div class="input-group">
                                    <input type="text" name="suhu_max" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text"> °C</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" id="status" name="status" required>
                                <option value="">-- Pilih Status --</option>
                                <option value="Belum Ditera">Belum Ditera</option>
                                <option value="Sudah Ditera">Sudah Ditera</option>
                                <option value="Sudah Ditera Ulang">Sudah Ditera Ulang</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="sah_batal">SAH / BATAL</label>
                                <select class="form-control" id="sah_batal" name="sah_batal">
                                    <option value="">-- Pilih --</option>
                                    <option value="SAH">SAH</option>
                                    <option value="BATAL">BATAL</option>
                                </select>
                            </div>
                        </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        function toggleFields() {
            var status = $('#status').val();
            var show = status === 'Sudah Ditera' || status === 'Sudah Ditera Ulang'; // show only if sudah ditera or sudah ditera ulang

            if (show) {
                $('#sah_batal').closest('.form-group').show();
            } else {
                $('#sah_batal').val('').closest('.form-group').hide();
            }

            // Always update required attributes based on visibility logic
            $('#sah_batal').prop('required', show);
        }

        // Initial toggle
        toggleFields();

        // On change
        $('#status').change(toggleFields);
    });

    $(document).ready(function() {
        $('div[id^="edit_nozzle_"]').on('shown.bs.modal', function() {
            const $modal = $(this);
            const $status = $modal.find('.status');
            const $sahBatalGroup = $modal.find('.sah_batal').closest('.form-group');

            function toggleEditFields() {
                const val = $status.val();
                const show = val === 'Sudah Ditera' || val === 'Sudah Ditera Ulang';

                $sahBatalGroup.toggle(show);

                $modal.find('.sah_batal').prop('required', show);
            }

            $status.off('change').on('change', toggleEditFields);
            toggleEditFields(); // run on modal open
        });
    });
</script>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_nozzle').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center'
            }]
        });
    });
</script>