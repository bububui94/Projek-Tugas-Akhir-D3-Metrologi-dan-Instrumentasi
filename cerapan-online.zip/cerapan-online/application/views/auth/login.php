<!DOCTYPE html>
<html>

<head>
    <title>Login - Cerapan Online</title>
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/sb-admin-2.css">
    <style>
        .custom-bg {
            background: linear-gradient(to right, #e2e8f0, #e5e7eb);
        }

        .custom-btn:hover {
            background-color: #f3e8ff !important;
            transition: background-color 0.3s ease-in-out;
        }

        @media (prefers-color-scheme: dark) {
            .custom-bg {
                background: linear-gradient(to left, #1f2937, #1a535c);
                color: white !important;
            }

            .custom-btn {
                background-color: #374151 !important;
                color: white !important;
            }

            .custom-btn:hover {
                background-color: #4b5563 !important;
            }
        }
    </style>
</head>

<body class="bg-light">
    <div class="custom-bg text-dark">
        <div class="d-flex align-items-center justify-content-center min-vh-100 px-2">
            <div class="text-center container col-md-3">
                <h1 class="mb-3 text-color-5"><strong>Login</strong></h1>
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
                <?php endif; ?>
                <?= form_open('auth/login') ?>
                <div class="form-group">
                    <label class="fs-2 fw-medium"><h6><strong>Username</strong></h6></label>
                    <input type="text" name="username" class="form-control text-color-4" required autofocus>
                </div>
                <div class="form-group mt-3">
                    <label class="fs-2 fw-medium"><strong>Password</strong></label>
                    <input type="password" name="password" class="form-control text-color-4" required>
                </div>
                <button type="submit" class="btn btn-color-5 mt-3 w-100"><strong>Login</strong></button>
                <?= form_close() ?>
                <!-- <h4 class="display-4"><strong>Welcome</strong></h4>
                <h3 class="fs-2 fw-medium mt-4"><strong>to Cerapan Online</strong></h3>
                <p class="mt-4 mb-5">That contain Cerapan PUBBM and Meter Air</p> -->
            </div>
        </div>
    </div>
</body>

</html>