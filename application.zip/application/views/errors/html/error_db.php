<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Database Error</title>
	<link href="/assets/css/sb-admin-2.css" rel="stylesheet">
	<style>
		.custom-bg {
			background: linear-gradient(to right, #e2e8f0, #e5e7eb);
		}

		.custom-btn:hover {
			background-color: #f3e8ff !important;
			transition: background-color 0.3s ease-in-out;
		}

		@media (prefers-color-scheme: dark) {
			.custom-bg {
				background: linear-gradient(to left, #1f2937, #1a535c);
				color: white !important;
			}

			.custom-btn {
				background-color: #374151 !important;
				color: white !important;
			}

			.custom-btn:hover {
				background-color: #4b5563 !important;
			}
		}
	</style>
</head>

<body>
	<div class="custom-bg text-dark">
		<div class="d-flex align-items-center justify-content-center min-vh-100 px-2 mx-5">
			<div>
				<h4 class="display-4 text-center"><strong><?php echo $heading; ?></strong></h4>
				<p class="mt-4 mb-5"><?php echo $message; ?></p>
			</div>
		</div>
	</div>
</body>

</html>