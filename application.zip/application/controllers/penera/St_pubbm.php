<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class St_pubbm extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('penera/model_st_pubbm');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 3) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $id_pegawai = $this->session->userdata('id_pegawai');
        $data['surat_tugas'] = $this->model_st_pubbm->read_sent_for_penera($id_pegawai)->result();
        
        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/daftar_surat_tugas/list_st_pubbm', $data);
        $this->load->view('templates_penera/footer');
    }

    public function accept() {
        $id = $this->input->get('id'); // Ambil ID dari parameter URL

        if (!$id) {
            show_error('ID tidak ditemukan.', 400);
            return;
        }

        $st = $this->model_st_pubbm->get_by_id($id);
        if (!$st) {
            show_error('Data ST tidak ditemukan.', 404);
            return;
        }

        // Cegah duplikasi
        if ($st->status_terima == 1) {
            $this->session->set_flashdata('error', 'ST sudah pernah diterima.');
            redirect('penera/st_pubbm');
            return;
        }

        // Ambil list nomor seri
        $list_nomor_seri = json_decode(isset($st->list_nomor_seri) ? $st->list_nomor_seri : '[]');

        foreach ($list_nomor_seri as $nomor_seri) {
            $cek = $this->db->get_where('t_cerapan_pubbm', [
                'id_surat_tugas' => $st->id,
                'nomor_seri'     => $nomor_seri
            ])->num_rows();

            if ($cek == 0) {
                $this->db->insert('t_cerapan_pubbm', [
                    'id_surat_tugas' => $st->id,
                    'spbu_id'        => $st->spbu_id,
                    'nomor_seri'     => $nomor_seri,
                    'id_pegawai'     => $st->ketua_pelaksana,
                    'tgl_pelaksanaan'=> $st->tgl_pelaksanaan,
                    'ttu'            => $st->ttu,
                    'created_at'     => date('Y-m-d H:i:s')
                ]);
            }
        }

        // Update status
        $this->model_st_pubbm->update($id, [
            'status_terima' => 1,
            'status_kirim' => 1 // ← ini WAJIB kalau kamu pakai filter
        ]);

        $this->session->set_flashdata('success', 'ST berhasil dikirim ke cerapan.');
        redirect('penera/st_pubbm');
    }


    public function send() {
        $id = $this->input->post('id');

        if (!$id) {
            show_error('Invalid ID', 400);
            return;
        }

        // Ambil data ST berdasarkan ID
        $st = $this->model_st_pubbm->get_by_id($id);

        if (!$st) {
            $this->session->set_flashdata('error', 'Data ST tidak ditemukan.');
            redirect('penera/st_pubbm');
            return;
        }

        // Decode list nomor seri
        $list_nomor_seri = json_decode(isset($st->list_nomor_seri) ? $st->list_nomor_seri : '[]');

        if (!is_array($list_nomor_seri) || count($list_nomor_seri) === 0) {
            $this->session->set_flashdata('error', 'List Nomor Seri kosong atau format tidak valid.');
            redirect('penera/st_pubbm');
            return;
        }

        // Masukkan data ke cerapan PUBBM per nomor seri
        foreach ($list_nomor_seri as $nomor_seri) {
            // Cek apakah data sudah ada agar tidak dobel
            $cek = $this->db->get_where('t_cerapan_pubbm', [
                'st_pubbm_id' => $st->id,
                'nomor_seri'  => $nomor_seri
            ])->num_rows();

            if ($cek == 0) {
                $this->db->insert('t_cerapan_pubbm', [
                    'st_pubbm_id'     => $st->id,
                    'nomor_st'        => $st->nomor_st,
                    'spbu_id'         => $st->spbu_id,
                    'tgl_pelaksanaan' => $st->tgl_pelaksanaan,
                    'nomor_seri'      => $nomor_seri,
                    'ttu'             => $st->ttu, // ✅ ini dia baris yang kamu butuhin
                    'kap_min'         => $st->kap_min,    // ✅ Tambahan
                    'kap_max'        => $st->kap_max,   // ✅ Tambahan
                    'created_at'      => date('Y-m-d H:i:s')
                ]);
            }
        }

        // Update status_terima menjadi 1
        $this->model_st_pubbm->update($id, [
            'status_terima' => 1,
            'status_kirim' => 1 // ← ini WAJIB kalau kamu pakai filter
        ]);

        $this->session->set_flashdata('success', 'ST berhasil dikirim ke cerapan.');
        redirect('penera/st_pubbm');
    }

}