<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class St_meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('kepala_uml/model_st_meter_air');
        $this->load->model('kepala_uml/model_skhp_meter_air');
        $this->load->model('tata_usaha/model_pegawai');
        $this->load->model('tata_usaha/model_users');
        $this->load->model('tata_usaha/model_pt_meter_air');
        $this->load->model('tata_usaha/model_meter_air');
        $this->load->model('penera/model_cerapan_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 1) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['kepala_uml'] = $this->session->userdata('id_pegawai');
        $data ['surat_tugas'] = $this->model_st_meter_air->read()->result();
        $data ['perusahaan'] = $this->model_pt_meter_air->read()->result();
        $data ['users'] = $this->model_users->read_only_penera()->result();
        $data ['pegawai'] = $this->model_pegawai->read()->result();

        $this->load->view('templates_kepala_uml/header');
        $this->load->view('templates_kepala_uml/sidebar');
        $this->load->view('kepala_uml/surat_tugas/list_st_meter_air', $data);
        $this->load->view('templates_kepala_uml/footer');
    }

    public function add() {
        $this->form_validation->set_rules('kepala_uml', 'Kepala_UML', 'required|integer');
        $this->form_validation->set_rules('nomor_st', 'Nomor_ST', 'required|is_unique[t_st_meter_air.nomor_st]', ['is_unique' => 'Nomor ST sudah digunakan.']);
        $this->form_validation->set_rules('tera_tera_ulang', 'Tera_Tera_Ulang', 'required');
        $this->form_validation->set_rules('id_perusahaan', 'ID_Perusahaan', 'required');
        $this->form_validation->set_rules('jumlah_meter_air', 'Jumlah_Meter_Air', 'required|integer');
        $this->form_validation->set_rules('list_nomor_seri', 'List_Nomor_Seri', 'required');
        $this->form_validation->set_rules('ketua_pelaksana', 'Ketua_Pelaksana', 'required|integer');
        $this->form_validation->set_rules('tanggal_pelaksanaan', 'Tanggal_Pelaksanaan', 'required');
        $this->form_validation->set_rules('jumlah_pendamping', 'Jumlah_Pendamping', 'required');

        $jumlah_pendamping = (int) $this->input->post('jumlah_pendamping');
        if ($jumlah_pendamping >= 1) {
            $this->form_validation->set_rules('pendamping_1', 'Pendamping_1', 'required|integer');
        }
        if ($jumlah_pendamping >= 2) {
            $this->form_validation->set_rules('pendamping_2', 'Pendamping_2', 'required|integer');
        }
        if ($jumlah_pendamping >= 3) {
            $this->form_validation->set_rules('pendamping_3', 'Pendamping_3', 'required|integer');
        }

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('kepala_uml/st_meter_air');
            return;
        }

        $kepala_uml = $this->input->post('kepala_uml');
        if ($kepala_uml != $this->session->userdata('id_pegawai')) {
            $this->session->set_flashdata('error', 'Kepala UML tidak sesuai.');
        }

        $jumlah_meter_air = $this->input->post('jumlah_meter_air');
        $list_nomor_seri = $this->input->post('list_nomor_seri');
        $nomor_seri = array_filter(array_map('trim', explode("\n", $list_nomor_seri)));
        $id_perusahaan = $this->input->post('id_perusahaan');
        $tera_tera_ulang = $this->input->post('tera_tera_ulang');
        
        if (count($nomor_seri) != $jumlah_meter_air) {
            $this->session->set_flashdata('error', 'Jumlah nomor seri yang dimasukkan (' . count($nomor_seri) . ') tidak sama dengan jumlah meter air yang dipilih (' . $jumlah_meter_air . ')');
            redirect('kepala_uml/st_meter_air');
            return;
        }
        
        $allowed_status = [];
        if ($tera_tera_ulang === 'Tera') {
            $allowed_status = ['Belum Ditera'];
        } elseif ($tera_tera_ulang === 'Tera Ulang') {
            $allowed_status = ['Sudah Ditera', 'Sudah Ditera Ulang'];
        } else {
            $this->session->set_flashdata('error', 'Pilihan Tera / Tera Ulang tidak valid.');
            redirect('kepala_uml/st_meter_air');
            return;
        }
        
        $valid_serials = $this->model_meter_air->get_existing_serials($nomor_seri, $id_perusahaan);
        $invalid_serials = array_diff($nomor_seri, $valid_serials);

        $valid_status = $this->model_meter_air->get_existing_serials_by_status($nomor_seri, $id_perusahaan, $allowed_status);
        $invalid_status = array_diff($nomor_seri, $valid_status);
        
        if (!empty($invalid_serials)) {
            $this->session->set_flashdata('error', 'Nomor seri tidak sesuai: ' . implode(', ', $invalid_serials) . ', untuk perusahaan yang dipilih');
            redirect('kepala_uml/st_meter_air');
            return;
        }
        
        if (!empty($invalid_status)) {
            $this->session->set_flashdata('error', 'Nomor seri tidak memiliki status yang sesuai: ' . implode(', ', $invalid_status) . ', untuk tera/tera ulang yang dipilih');
            redirect('kepala_uml/st_meter_air');
            return;
        }

        $ketua_id = $this->input->post('ketua_pelaksana');
        $ketua = $this->model_users->get_by_id_ketua($ketua_id);

        if (!$ketua) {
            $this->session->set_flashdata('error', 'Invalid Ketua Pelaksana selected.');
            redirect('kepala_uml/st_meter_air');
            return;
        }

        $ketua_pelaksana_id = $ketua->id_pegawai;
        $pendamping_ids = [];

        for ($i = 1; $i <= $jumlah_pendamping; $i++) {
            $id = $this->input->post('pendamping_' . $i);

            // Check if exists in m_pegawai
            if (!$this->model_pegawai->get_by_id($id)) {
                $this->session->set_flashdata('error', "Pendamping $i tidak ditemukan.");
                redirect('kepala_uml/st_meter_air');
                return;
            }

            // Must not match ketua
            if ($id == $ketua_pelaksana_id) {
                $this->session->set_flashdata('error', "Pendamping $i tidak boleh sama dengan Ketua Pelaksana.");
                redirect('kepala_uml/st_meter_air');
                return;
            }

            // Must be unique among pendamping
            if (in_array($id, $pendamping_ids)) {
                $this->session->set_flashdata('error', "Pendamping $i duplikat dengan pendamping lain.");
                redirect('kepala_uml/st_meter_air');
                return;
            }

            $pendamping_ids[] = $id;
        }

        $nomor_st = $this->input->post('nomor_st');

        $data = [
            'kepala_uml'            => $kepala_uml,
            'nomor_st'              => $nomor_st,
            'tera_tera_ulang'       => $this->input->post('tera_tera_ulang'),
            'id_perusahaan'         => $id_perusahaan,
            'list_nomor_seri'       => $list_nomor_seri, // saved raw
            'ketua_pelaksana'       => $this->input->post('ketua_pelaksana'),
            'tanggal_pelaksanaan'   => $this->input->post('tanggal_pelaksanaan'),
            'pendamping_1'          => $this->input->post('pendamping_1') ?: '-',
            'pendamping_2'          => $this->input->post('pendamping_2') ?: '-',
            'pendamping_3'          => $this->input->post('pendamping_3') ?: '-',
            'tanggal_pembuatan'     => date('Y-m-d'),
        ];

        $this->model_st_meter_air->add($data);
        $this->generate_pdf($nomor_st);
        $this->session->set_flashdata('success', 'Surat tugas baru berhasil ditambahkan');
        redirect('kepala_uml/st_meter_air');
    }

    public function generate_pdf($nomor_st) {
        $this->load->library('dompdf_lib');
        $surat_tugas = $this->model_st_meter_air->get_by_nomor_st($nomor_st);

        if (!$surat_tugas) {
            show_error("Surat Tugas Nomor $nomor_st tidak ditemukan", 404);
            return;
        }

        $kepala_uml = $this->model_pegawai->get_by_id($surat_tugas->kepala_uml);
        $nomor_seri = array_filter(array_map('trim', explode("\n", $surat_tugas->list_nomor_seri)));
        $list_meter_air = $this->model_meter_air->get_by_nomor_seri($nomor_seri);
        $perusahaan = $this->model_pt_meter_air->get_by_id($surat_tugas->id_perusahaan);
        $ketua_pelaksana = $this->model_pegawai->get_by_id($surat_tugas->ketua_pelaksana);

        $pendamping_ids = [];

        if (!empty($surat_tugas->pendamping_1) && $surat_tugas->pendamping_1 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_1;
        }
        if (!empty($surat_tugas->pendamping_2) && $surat_tugas->pendamping_2 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_2;
        }
        if (!empty($surat_tugas->pendamping_3) && $surat_tugas->pendamping_3 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_3;
        }

        $pendampings = [];
        if (!empty($pendamping_ids)) {
            $pendampings = $this->model_pegawai->get_by_ids($pendamping_ids);
        }

        $data = [
            'kepala_uml'        => $kepala_uml,
            'surat_tugas'       => $surat_tugas,
            'list_meter_air'    => $list_meter_air,
            'perusahaan'        => $perusahaan,
            'ketua_pelaksana'   => $ketua_pelaksana,
            'pendampings'       => $pendampings,
        ];

        $html = $this->load->view('generate_pdf/st_meter_air_pdf', $data, true);

        $this->dompdf_lib->loadHtml($html);
        $this->dompdf_lib->setPaper('A4', 'portrait');
        $this->dompdf_lib->render();
        
        $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $nomor_st);
        $filename = 'Surat Tugas Nomor ' . $safe_nomor_st . '.pdf';
        $output = $this->dompdf_lib->output();
        file_put_contents(FCPATH . 'assets/st_meter_air/' . $filename, $output);
    }

    public function send() {
        $id = $this->input->post('id');

        if (!$id) {
            show_error('Invalid ID', 400);
            return;
        }

        $this->model_st_meter_air->mark_as_sent($id);

        $this->session->set_flashdata('success', 'Surat tugas berhasil dikirim ke penera');
        redirect('kepala_uml/st_meter_air');
    }


    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $record = $this->model_st_meter_air->get_by_id($id);
        if ($record && $record->nomor_st) {
            $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $record->nomor_st);
            $filename = 'Surat Tugas Nomor ' . $safe_nomor_st . '.pdf';
            $filepath = FCPATH . 'assets/st_meter_air/' . $filename;

            if (file_exists($filepath)) {
                unlink($filepath); // Delete PDF file
            }
        }

        $cerapan_list = $this->model_cerapan_meter_air->get_by_surat_tugas($id);
        $tahun_tera = date('Y', strtotime($record->tanggal_pelaksanaan));

        foreach ($cerapan_list as $cerapan) {
            $safe_cerapan = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $cerapan->nomor_seri);
            $cerapan_filename = 'Cerapan Meter Air ' . $safe_cerapan . ' Tahun ' . $tahun_tera . '.pdf';
            $cerapan_filepath = FCPATH . 'assets/cerapan_meter_air/' . $cerapan_filename;

            if (file_exists($cerapan_filepath)) {
                unlink($cerapan_filepath); // Delete each Cerapan PDF
            }
        }

        $skhp_list = $this->model_skhp_meter_air->get_by_surat_tugas($id);

        foreach ($skhp_list as $skhp) {
            $safe_nomor_skhp = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $skhp->nomor_skhp);
            $skhp_filename = 'SKHP Nomor ' . $safe_nomor_skhp . '.pdf';
            $skhp_filepath = FCPATH . 'assets/skhp_meter_air/' . $skhp_filename;

            if (file_exists($skhp_filepath)) {
                unlink($skhp_filepath); // Delete each SKHP PDF
            }
        }

        $this->model_st_meter_air->delete($id);
        $this->session->set_flashdata('success', 'Surat tugas berhasil dihapus');
        redirect('kepala_uml/st_meter_air');
    }
}