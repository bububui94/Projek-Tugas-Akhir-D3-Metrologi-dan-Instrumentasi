<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_nozzle extends CI_Model {
    public function add($data) {
        return $this->db->insert('m_nozzle', $data);
    }

    public function read() {
        $this->db->select('m_nozzle.*, m_spbu.nama_spbu');
        $this->db->from('m_nozzle');
        $this->db->join('m_spbu', 'm_spbu.id = m_nozzle.spbu_id');
        return $this->db->get();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('m_nozzle', $data);
    }

    public function delete($id) {
        return $this->db->delete('m_nozzle', ['id' => $id]);
    }

    public function get_by_spbu($spbu_id) {
        $this->db->where('spbu_id', $spbu_id);
        return $this->db->get('m_nozzle')->result();
    }

    public function get_by_nomor_seri($nomor_seri) {
        return $this->db
            ->where_in('nomor_seri', $nomor_seri)
            ->get('m_nozzle')
            ->result();
    }

    public function count() {
        return $this->db->count_all('m_nozzle');
    }
}