<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pubbm extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_nozzle');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 1) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['nozzle'] = $this->model_nozzle->read()->result();
        
        $this->load->view('templates_kepala_uml/header');
        $this->load->view('templates_kepala_uml/sidebar');
        $this->load->view('kepala_uml/daftar_alat_ukur/list_pubbm', $data);
        $this->load->view('templates_kepala_uml/footer');
    }
}