<?php
defined('BASEPATH') OR exit('no direct script access allowed'); 

class Model_users extends CI_Model {
    public function add($data) {
        return $this->db->insert('m_users', $data);
    }

    public function read() {
        $this->db->select('m_users.*, m_pegawai.nama_lengkap, m_pegawai.status, m_pegawai.nip, role.role');
        $this->db->from('m_users');
        $this->db->join('m_pegawai', 'm_pegawai.id = m_users.id_pegawai');
        $this->db->join('role', 'role.id = m_users.id_role');
        return $this->db->get();
    }

    public function read_only_penera() {
        $this->db->where('id_role', 3);
        return $this->db
            ->select('m_users.*, m_pegawai.nama_lengkap, m_pegawai.id as id_pegawai')
            ->join('m_pegawai', 'm_pegawai.id = m_users.id_pegawai')
            ->get('m_users');
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('m_users', $data);
    }

    public function get_by_id($id) {
        return $this->db->get_where('m_users', ['id' => $id])->row();
    }

    public function get_by_id_ketua($id_pegawai) {
        return $this->db->get_where('m_users', ['id_pegawai' => $id_pegawai, 'id_role' => 3])->row();
    }

    public function get_by_id_pegawai($id_pegawai) {
        return $this->db->get_where('m_users', ['id_pegawai' => $id_pegawai])->row();
    }

    public function count_tata_usaha() {
        $this->db->where('id_role', 2); // 2 = Tata Usaha
        return $this->db->count_all_results('m_users');
    }

    public function delete($id) {
        return $this->db->delete('m_users', ['id' => $id]);
    }
    
    public function enable_user() {
        $this->db->select('id, nama_lengkap');
        $this->db->from('m_pegawai');
        $this->db->where_in('status', ['PNS', 'PPPK']);
        $this->db->where_not_in('id', 'SELECT id_pegawai FROM m_users', false); // prevent duplicate links
        return $this->db->get();
    }

    public function pegawai_already_exists($id_pegawai) {
        return $this->db->where('id_pegawai', $id_pegawai)->count_all_results('m_users') > 0;
    }

    public function kepala_uml_exists() {
        $this->db->where('id_role', 1); // 1 = Kepala UML
        return $this->db->get('m_users')->num_rows() > 0;
    }

    public function count() {
        return $this->db->count_all('m_users');
    }
}