<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pt_meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_pt_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['perusahaan'] = $this->model_pt_meter_air->read()->result();
        
        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/meter_air/list_pt_meter_air', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('nama_pt', 'Nama_PT', 'required');
        $this->form_validation->set_rules('pemilik', 'Pemilik', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/pt_meter_air');
            return;
        }

        $data = [
            'nama_pt' => $this->input->post('nama_pt'),
            'pemilik' => $this->input->post('pemilik'),
            'alamat'  => $this->input->post('alamat'),
        ];

        $this->model_pt_meter_air->add($data);
        $this->session->set_flashdata('success', 'Perusahaan meter air baru berhasil ditambahkan');
        redirect('tata_usaha/pt_meter_air');
    }

    public function update() {
        $this->form_validation->set_rules('id', 'ID', 'required');
        $this->form_validation->set_rules('nama_pt', 'Nama_PT', 'required');
        $this->form_validation->set_rules('pemilik', 'Pemilik', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/pt_meter_air');
            return;
        }

        $id = $this->input->post('id');
        $data = [
            'nama_pt'   => $this->input->post('nama_pt'),
            'pemilik'   => $this->input->post('pemilik'),
            'alamat'    => $this->input->post('alamat'),
        ];

        $this->model_pt_meter_air->update($id, $data);
        $this->session->set_flashdata('success', 'Data perusahaan meter air berhasil diperbarui');
        redirect('tata_usaha/pt_meter_air');
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $this->model_pt_meter_air->delete($id);
        $this->session->set_flashdata('success', 'Perusahaan meter air berhasil dihapus');
        redirect('tata_usaha/pt_meter_air');
    }
}