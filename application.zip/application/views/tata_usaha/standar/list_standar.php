<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Bejana Ukur Standar</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_bejana_ukur_standar"><i class="fa fa-plus"></i> Tambah Bejana Ukur Standar</button>
            <table class="table box table-sm" id="list_bejana_ukur_standar">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-2">MEREK</th>
                        <th class="col-2">TIPE</th>
                        <th class="col-2">NOMOR SERI</th>
                        <th class="col-2">KAPASITAS</th>
                        <th class="col-2">KOREKSI</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($standar as $std) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $std->merek_bus ?></td>
                            <td><?= $std->tipe_bus ?></td>
                            <td><?= $std->nomor_seri_bus ?></td>
                            <td><?= $std->kapasitas ?> L</td>
                            <td><?= $std->koreksi_bus ?> L</td>

                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_bejana_ukur_standar_<?= $std->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_bejana_ukur_standar_<?= $std->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_bejana_ukur_standar_<?= $std->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <div class="modal fade" id="detail_bejana_ukur_standar_<?= $std->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail Bejana Ukur Standar</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Merek:</strong> <?= $std->merek_bus ?></p>
                                        <p><strong>Tipe Penggunaan:</strong> Tipe <?= $std->tipe_bus ?></p>
                                        <p><strong>Kelas Keakurasian:</strong> <?= $std->kelas_bus ?></p>
                                        <p><strong>Nomor Seri:</strong> <?= $std->nomor_seri_bus ?></p>
                                        <p><strong>Koefisien Muai Bahan (α):</strong> <?= $std->koefisien_muai_bahan ?> /°C</p>
                                        <p><strong>Kapasitas:</strong> <?= $std->kapasitas ?> L</p>
                                        <p><strong>Koreksi:</strong> <?= $std->koreksi_bus ?> L</p>
                                        <p><strong>Waktu Tetes:</strong> <?= $std->waktu_tetes ?> s</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="edit_bejana_ukur_standar_<?= $std->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/standar/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Edit Bejana Ukur Standar</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $std->id ?>">

                                        <div class="form-group">
                                            <label>Merek</label>
                                            <input type="text" name="merek_bus" class="form-control" value="<?= $std->merek_bus ?>">
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label for="tipe_bus">Tipe Penggunaan</label>
                                                <select class="form-control" name="tipe_bus" id="tipe_bus">
                                                    <option value="">-- Pilih Tipe BUS --</option>
                                                    <option value="Basah" <?= $std->tipe_bus == 'Basah' ? 'selected' : '' ?>>Tipe Basah</option>
                                                    <option value="Kering" <?= $std->tipe_bus == 'Kering' ? 'selected' : '' ?>>Tipe Kering</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="kelas_bus">kelas Keakurasian</label>
                                                <select class="form-control" name="kelas_bus" id="kelas_bus">
                                                    <option value="">-- Pilih Kelas BUS --</option>
                                                    <option value="I" <?= $std->kelas_bus == 'I' ? 'selected' : '' ?>>I (Satu)</option>
                                                    <option value="II" <?= $std->kelas_bus == 'II' ? 'selected' : '' ?>>II (Dua)</option>
                                                    <option value="III" <?= $std->kelas_bus == 'III' ? 'selected' : '' ?>>III (Tiga)</option>
                                                    <option value="IV" <?= $std->kelas_bus == 'IV' ? 'selected' : '' ?>>IV (Empat)</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label>Nomor Seri</label>
                                                <input class="form-control" type="text" name="nomor_seri_bus" value="<?= $std->nomor_seri_bus ?>">
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Koefisien Muai Bahan (α)</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="koefisien_muai_bahan" value="<?= $std->koefisien_muai_bahan ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">/°C</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <label>Kapasitas</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" name="kapasitas" value="<?= $std->kapasitas ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">L</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Koreksi</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="koreksi_bus" value="<?= $std->koreksi_bus ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">L</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Waktu Tetes</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" name="waktu_tetes" value="<?= $std->waktu_tetes ?>">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">s</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="delete_bejana_ukur_standar_<?= $std->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/standar/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus Bejana Ukur Standar</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $std->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus standar ini?</h5>
                                        <p class="text-danger">Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <div class="modal fade" id="add_bejana_ukur_standar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/standar/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Bejana Ukur Standar</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Merek</label>
                            <input type="text" name="merek_bus" class="form-control" required>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label for="tipe_bus">Tipe Penggunaan</label>
                                <select class="form-control" name="tipe_bus" id="tipe_bus" required>
                                    <option value="">-- Pilih Tipe BUS --</option>
                                    <option value="Basah">Tipe Basah</option>
                                    <option value="Kering">Tipe Kering</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label for="kelas_bus">kelas Keakurasian</label>
                                <select class="form-control" name="kelas_bus" id="kelas_bus" required>
                                    <option value="">-- Pilih Kelas BUS --</option>
                                    <option value="I">I (Satu)</option>
                                    <option value="II">II (Dua)</option>
                                    <option value="III">III (Tiga)</option>
                                    <option value="IV">IV (Empat)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label>Nomor Seri</label>
                                <input class="form-control" type="text" name="nomor_seri_bus" required>
                            </div>
                            <div class="col-sm-6">
                                <label>Koefisien Muai Bahan (α)</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="koefisien_muai_bahan" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">/°C</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label>Kapasitas</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" name="kapasitas" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">L</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <label>Koreksi</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="koreksi_bus" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">L</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <label>Waktu Tetes</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" name="waktu_tetes" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">s</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_bejana_ukur_standar').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>