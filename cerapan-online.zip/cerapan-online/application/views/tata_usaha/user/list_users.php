<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><strong>Daftar User</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_user"><i class="fa fa-plus"></i> Tambah User</button>
            <table class="table table-sm box" id="list_user">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-4">PEGAWAI</th>
                        <th class="col-2">ROLE</th>
                        <th class="col-2">USERNAME</th>
                        <th class="col-2">PASSWORD</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($users as $user) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $user->nama_lengkap ?></td>
                            <td><?= $user->role ?></td>
                            <td><?= $user->username ?></td>
                            <td><i class="fas fa-lock text-primary"></i> Secured</td>
                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_user_<?= $user->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_user_<?= $user->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_user_<?= $user->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <!-- Modal for Detail User -->
                        <div class="modal fade" id="detail_user_<?= $user->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail User</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Nama Pegawai:</strong> <?= $user->nama_lengkap ?></p>
                                        <p><strong>Status:</strong> <?= $user->status ?></p>
                                        <p><strong>NIP:</strong> <?= $user->nip ?></p>
                                        <p><strong>Role:</strong> <?= $user->role ?></p>
                                        <p><strong>Username:</strong> <?= $user->username ?></p>
                                        <p><strong>Password:</strong> <i class="fas fa-lock text-primary"></i> Secured</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for Editing User -->
                        <div class="modal fade" id="edit_user_<?= $user->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/users/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Edit User</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $user->id ?>">

                                        <div class="form-group">
                                            <label>Role</label>
                                            <?php
                                            $the_only_tata_usaha = $user->id_role == 2 && $count_tata_usaha <= 1;
                                            ?>
                                            <select name="id_role" class="form-control" required <?= $the_only_tata_usaha ? 'disabled' : '' ?>>
                                                <option value="3" <?= $user->id_role == 3 ? 'selected' : '' ?>>Penera</option>
                                                <option value="2" <?= $user->id_role == 2 ? 'selected' : '' ?>>Tata Usaha</option>
                                                <option value="1" <?= $user->id_role == 1 ? 'selected' : '' ?> <?= ($kepala_uml_exists && $user->id_role != 1) ? 'disabled' : '' ?>>Kepala UML <?= ($kepala_uml_exists && $user->id_role != 1) ? '(sudah ada)' : '' ?></option>
                                            </select>
                                            <?php if ($the_only_tata_usaha): ?>
                                                <h6 class="text-danger mt-2">Tidak bisa mengubah role karena satu-satunya Tata Usaha</h6>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" name="username" class="form-control" value="<?= $user->username ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Password <small>(biarkan kosong jika tidak ingin diubah)</small></label>
                                            <input type="password" name="password" class="form-control">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for Deleting User -->
                        <div class="modal fade" id="delete_user_<?= $user->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/users/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus User</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $user->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus user ini?</h5>
                                        <p class="text-danger">Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Modal for Adding User -->
        <div class="modal fade" id="add_user" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/users/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah User</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="id_pegawai">Nama Pegawai</label>
                            <select name="id_pegawai" class="form-control" required>
                                <option value="">-- Pilih Pegawai --</option>
                                <?php foreach ($pegawai as $pgw): ?>
                                    <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="id_role">Role</label>
                            <select class="form-control" name="id_role">
                                <option value="3">Penera</option>
                                <option value="2">Tata Usaha</option>
                                <option value="1" <?= isset($kepala_uml_exists) && $kepala_uml_exists ? 'disabled' : '' ?>>Kepala UML <?= isset($kepala_uml_exists) && $kepala_uml_exists ? '(sudah ada)' : '' ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_user').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>