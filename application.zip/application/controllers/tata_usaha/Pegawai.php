<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_pegawai');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['pegawai'] = $this->model_pegawai->read()->result();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/pegawai/list_pegawai', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $status = $this->input->post('status');

        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($status === 'PNS') {
            $this->form_validation->set_rules('nip', 'NIP', 'required');
            $this->form_validation->set_rules('golongan', 'Golongan', 'required');
            $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
        } else if ($status === 'PPPK') {
            $this->form_validation->set_rules('nip', 'NIP', 'required');
            $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
        }

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/pegawai');
            return;
        }

        $data = [
            'nama_lengkap' => $this->input->post('nama_lengkap'),
            'status'       => $status,
            'nip'          => ($status !== 'Magang') ? $this->input->post('nip') : '-',
            'golongan'     => ($status === 'PNS') ? $this->input->post('golongan') : '-',
            'jabatan'      => ($status !== 'Magang') ? $this->input->post('jabatan') : '-',
            'email'        => $this->input->post('email'),
        ];

        $this->model_pegawai->add($data);
        $this->session->set_flashdata('success', 'Pegawai baru berhasil ditambahkan');
        redirect('tata_usaha/pegawai');
    }

    public function update() {
        $status = $this->input->post('status');

        $this->form_validation->set_rules('id', 'ID', 'required');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($status === 'PNS') {
            $this->form_validation->set_rules('nip', 'NIP', 'required');
            $this->form_validation->set_rules('golongan', 'Golongan', 'required');
            $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
        } elseif ($status === 'PPPK') {
            $this->form_validation->set_rules('nip', 'NIP', 'required');
            $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');
        }

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/pegawai'); // Or wherever your view is
            return;
        }

        $data = [
            'nama_lengkap' => $this->input->post('nama_lengkap'),
            'status'       => $status,
            'nip'          => ($status !== 'Magang') ? $this->input->post('nip') : '-',
            'golongan'     => ($status === 'PNS') ? $this->input->post('golongan') : '-',
            'jabatan'      => ($status !== 'Magang') ? $this->input->post('jabatan') : '-',
            'email'        => $this->input->post('email'),
        ];

        $id = $this->input->post('id');
        $this->model_pegawai->update($id, $data);
        $this->session->set_flashdata('success', 'Data pegawai berhasil diperbarui');
        redirect('tata_usaha/pegawai');
    }

    public function delete() {
        $this->load->model('tata_usaha/model_users');

        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        if ($this->model_users->get_by_id_pegawai($id)->id_role == 2 && $this->model_users->count_tata_usaha() <= 1) {
            $this->session->set_flashdata('error', 'Tidak bisa menghapus pegawai yang terhubung ke satu-satunya User dengan role Tata Usaha');
            redirect('tata_usaha/pegawai');
            return;
        }

        $this->model_pegawai->delete($id);
        $this->session->set_flashdata('success', 'Pegawai berhasil dihapus');
        redirect('tata_usaha/pegawai');
    }
}