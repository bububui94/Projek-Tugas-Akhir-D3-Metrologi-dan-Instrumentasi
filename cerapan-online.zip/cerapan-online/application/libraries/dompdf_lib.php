<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;
use Dompdf\Options;

class Dompdf_lib {
    protected $dompdf;

    public function __construct() {
        require_once APPPATH . 'third_party/dompdf/autoload.inc.php';

        $options = new Options();
        $options->set('isRemoteEnabled', true);

        $this->dompdf = new Dompdf($options);
    }

    public function loadHtml($html) {
        $this->dompdf->loadHtml($html);
    }

    public function setPaper($size = 'A4', $orientation = 'portrait') {
        $this->dompdf->setPaper($size, $orientation);
    }

    public function render() {
        $this->dompdf->render();
    }

    public function output() {
        return $this->dompdf->output();
    }

    public function stream($filename = "document.pdf", $options = ['Attachment' => 0]) {
        $this->dompdf->stream($filename, $options);
    }
}
