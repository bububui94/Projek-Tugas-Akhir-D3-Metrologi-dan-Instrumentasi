<style>
.table-wrapper {
    overflow-x: auto;
    width: 100%;
}

.table-wrapper table {
    min-width: 1000px; /* atau lebih kalau kamu perlu */
}
</style>
<div class="container-fluid text-dark">
    <div class="content-wrapper">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h2 class="h3 mb-0 text-primary"><strong>Form Pengujian PUBBM</strong></h2>
        </div>

        <section class="content">
            <?= form_open('penera/cerapan_pubbm/simpan_form_pengujian'); ?>
            <input type="hidden" name="id" value="<?= $cerapan->id ?>">

            <table class="table table-bordered">
                <thead class="text-center bg-light">
                    <tr>
                        <th></th>
                        <th>Laju Alir Minimum</th>
                        <th>Laju Alir Operasional</th>
                        <th>Laju Alir Maksimum</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>1. Pembacaan totalisator awal pengujian</strong></td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_awal_min" name="total_awal_min"
                            value="<?= set_value('total_awal_min', isset($cerapan->total_awal_min)? $cerapan->total_awal_min : '') ?>"
                            oninput="hitungVolume('min')">
                        </td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_awal_opr" name="total_awal_opr"
                            value="<?= set_value('total_awal_opr', isset($cerapan->total_awal_opr)? $cerapan->total_awal_opr : '') ?>"
                            oninput="hitungVolume('opr')">
                        </td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_awal_max" name="total_awal_max"
                            value="<?= set_value('total_awal_max', isset($cerapan->total_awal_max)? $cerapan->total_awal_max : '') ?>"
                            oninput="hitungVolume('max')">
                        </td>
                    </tr>
                    <tr>
                        <td><strong>2. Pembacaan totalisator akhir pengujian</strong></td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_akhir_min" name="total_akhir_min"
                            value="<?= set_value('total_akhir_min', isset($cerapan->total_akhir_min)? $cerapan->total_akhir_min : '') ?>"
                            oninput="hitungVolume('min')">
                        </td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_akhir_opr" name="total_akhir_opr"
                            value="<?= set_value('total_akhir_opr', isset($cerapan->total_akhir_opr)? $cerapan->total_akhir_opr : '') ?>"
                            oninput="hitungVolume('opr')">
                        </td>
                        <td>
                            <input type="number" step="any" class="form-control" id="total_akhir_max" name="total_akhir_max"
                            value="<?= set_value('total_akhir_max', isset($cerapan->total_akhir_max)? $cerapan->total_akhir_max : '') ?>"
                            oninput="hitungVolume('max')">
                        </td>
                    </tr>
                    <tr>
                        <td><strong>3. Total volume yang digunakan</strong></td>
                        <td>
                            <input type="text" class="form-control" id="volum_total_min" name="volum_total_min" readonly value="<?= set_value('volum_total_min', isset($cerapan->volum_total_min)? $cerapan->volum_total_min : '') ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" id="volum_total_opr" name="volum_total_opr" readonly value="<?= set_value('volum_total_opr', isset($cerapan->volum_total_opr)? $cerapan->volum_total_opr : '') ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control" id="volum_total_max" name="volum_total_max" readonly value="<?= set_value('volum_total_max', isset($cerapan->volum_total_max)? $cerapan->volum_total_max : '') ?>">
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered">
                <tr>
                    <th><p>Qmin (L/min)</p></th>
                    <td><input type="text" name="kap_min" value="<?= $cerapan->kap_min ?>" readonly></td>
                </tr>
                <tr>
                    <th><p>Qmaks (L/min)</p></th>
                    <td><input type="text" name="kap_max" value="<?= $cerapan->kap_max ?>" readonly></td>
                </tr>
            </table>

        <div class="table-wrapper">
            <table class="table table-bordered text-center">
                <tr>
                    <th></th>
                    <th colspan="3">Laju Alir Minimum</th>
                    <th colspan="3">Laju Alir Operasional</th>
                    <th colspan="3">Laju Alir Maksimum</th>
                </tr>
                <tr>
                    <th></th>
                    <th>VFD (mL)</th>
                    <th>VREF (mL)</th>
                    <th>EFD (%)</th>
                    <th>VFD (mL)</th>
                    <th>VREF (mL)</th>
                    <th>EFD (%)</th>
                    <th>VFD (mL)</th>
                    <th>VREF (mL)</th>
                    <th>EFD (%)</th>
                </tr>

                <!-- Penyerahan 1 -->
                <tr>
                    <td>Penyerahan 1</td>
                    <!-- MIN -->
                    <td>
                        <input type="number" name="vfd_min_1" id="vfd_min_1" step="any"
                            value="<?= set_value('vfd_min_1', isset($cerapan->vfd_min_1)? $cerapan->vfd_min_1 : '') ?>"
                            oninput="onNumChange('efd','min',1)">
                    </td>
                    <td>
                        <input type="number" name="vref_min_1" id="vref_min_1" step="any"
                            value="<?= set_value('vref_min_1', isset($cerapan->vref_min_1)? $cerapan->vref_min_1 : '') ?>"
                            oninput="onNumChange('efd','min',1)">
                    </td>
                    <td>
                        <input type="text" name="efd_min_1" id="efd_min_1" readonly
                            value="<?= set_value('efd_min_1', isset($cerapan->efd_min_1)? $cerapan->efd_min_1 : '') ?>">
                    </td>

                    <!-- OPR -->
                    <td>
                        <input type="number" name="vfd_opr_1" id="vfd_opr_1" step="any"
                            value="<?= set_value('vfd_opr_1', isset($cerapan->vfd_opr_1)? $cerapan->vfd_opr_1 : '') ?>"
                            oninput="onNumChange('efd','opr',1)">
                    </td>
                    <td>
                        <input type="number" name="vref_opr_1" id="vref_opr_1" step="any"
                            value="<?= set_value('vref_opr_1', isset($cerapan->vref_opr_1)? $cerapan->vref_opr_1 : '') ?>"
                            oninput="onNumChange('efd','opr',1)">
                    </td>
                    <td>
                        <input type="text" name="efd_opr_1" id="efd_opr_1" readonly
                            value="<?= set_value('efd_opr_1', isset($cerapan->efd_opr_1)? $cerapan->efd_opr_1 : '') ?>">
                    </td>

                    <!-- MAX -->
                    <td>
                        <input type="number" name="vfd_max_1" id="vfd_max_1" step="any"
                            value="<?= set_value('vfd_max_1', isset($cerapan->vfd_max_1)? $cerapan->vfd_max_1 : '') ?>"
                            oninput="onNumChange('efd','max',1)">
                    </td>
                    <td>
                        <input type="number" name="vref_max_1" id="vref_max_1" step="any"
                            value="<?= set_value('vref_max_1', isset($cerapan->vref_max_1)? $cerapan->vref_max_1 : '') ?>"
                            oninput="onNumChange('efd','max',1)">
                    </td>
                    <td>
                        <input type="text" name="efd_max_1" id="efd_max_1" readonly
                            value="<?= set_value('efd_max_1', isset($cerapan->efd_max_1)? $cerapan->efd_max_1 : '') ?>">
                    </td>
                </tr>

                <!-- Penyerahan 2 -->
                <tr>
                    <td>Penyerahan 2</td>
                    <!-- MIN -->
                    <td>
                        <input type="number" name="vfd_min_2" id="vfd_min_2" step="any"
                            value="<?= set_value('vfd_min_2', isset($cerapan->vfd_min_2)? $cerapan->vfd_min_2 : '') ?>"
                            oninput="onNumChange('efd','min',2)">
                    </td>
                    <td>
                        <input type="number" name="vref_min_2" id="vref_min_2" step="any"
                            value="<?= set_value('vref_min_2', isset($cerapan->vref_min_2)? $cerapan->vref_min_2 : '') ?>"
                            oninput="onNumChange('efd','min',2)">
                    </td>
                    <td>
                        <input type="text" name="efd_min_2" id="efd_min_2" readonly
                            value="<?= set_value('efd_min_2', isset($cerapan->efd_min_2)? $cerapan->efd_min_2 : '') ?>">
                    </td>

                    <!-- OPR -->
                    <td>
                        <input type="number" name="vfd_opr_2" id="vfd_opr_2" step="any"
                            value="<?= set_value('vfd_opr_2', isset($cerapan->vfd_opr_2)? $cerapan->vfd_opr_2 : '') ?>"
                            oninput="onNumChange('efd','opr',2)">
                    </td>
                    <td>
                        <input type="number" name="vref_opr_2" id="vref_opr_2" step="any"
                            value="<?= set_value('vref_opr_2', isset($cerapan->vref_opr_2)? $cerapan->vref_opr_2 : '') ?>"
                            oninput="onNumChange('efd','opr',2)">
                    </td>
                    <td>
                        <input type="text" name="efd_opr_2" id="efd_opr_2" readonly
                            value="<?= set_value('efd_opr_2', isset($cerapan->efd_opr_2)? $cerapan->efd_opr_2 : '') ?>">
                    </td>

                    <!-- MAX -->
                    <td>
                        <input type="number" name="vfd_max_2" id="vfd_max_2" step="any"
                            value="<?= set_value('vfd_max_2', isset($cerapan->vfd_max_2)? $cerapan->vfd_max_2 : '') ?>"
                            oninput="onNumChange('efd','max',2)">
                    </td>
                    <td>
                        <input type="number" name="vref_max_2" id="vref_max_2" step="any"
                            value="<?= set_value('vref_max_2', isset($cerapan->vref_max_2)? $cerapan->vref_max_2 : '') ?>"
                            oninput="onNumChange('efd','max',2)">
                    </td>
                    <td>
                        <input type="text" name="efd_max_2" id="efd_max_2" readonly
                            value="<?= set_value('efd_max_2', isset($cerapan->efd_max_2)? $cerapan->efd_max_2 : '') ?>">
                    </td>
                </tr>

                <!-- Penyerahan 3 -->
                <tr>
                    <td>Penyerahan 3</td>
                    <!-- MIN -->
                    <td>
                        <input type="number" name="vfd_min_3" id="vfd_min_3" step="any"
                            value="<?= set_value('vfd_min_3', isset($cerapan->vfd_min_3)? $cerapan->vfd_min_3 : '') ?>"
                            oninput="onNumChange('efd','min',3)">
                    </td>
                    <td>
                        <input type="number" name="vref_min_3" id="vref_min_3" step="any"
                            value="<?= set_value('vref_min_3', isset($cerapan->vref_min_3)? $cerapan->vref_min_3 : '') ?>"
                            oninput="onNumChange('efd','min',3)">
                    </td>
                    <td>
                        <input type="text" name="efd_min_3" id="efd_min_3" readonly
                            value="<?= set_value('efd_min_3', isset($cerapan->efd_min_3)? $cerapan->efd_min_3 : '') ?>">
                    </td>

                    <!-- OPR -->
                    <td>
                        <input type="number" name="vfd_opr_3" id="vfd_opr_3" step="any"
                            value="<?= set_value('vfd_opr_3', isset($cerapan->vfd_opr_3)? $cerapan->vfd_opr_3 : '') ?>"
                            oninput="onNumChange('efd','opr',3)">
                    </td>
                    <td>
                        <input type="number" name="vref_opr_3" id="vref_opr_3" step="any"
                            value="<?= set_value('vref_opr_3', isset($cerapan->vref_opr_3)? $cerapan->vref_opr_3 : '') ?>"
                            oninput="onNumChange('efd','opr',3)">
                    </td>
                    <td>
                        <input type="text" name="efd_opr_3" id="efd_opr_3" readonly
                            value="<?= set_value('efd_opr_3', isset($cerapan->efd_opr_3)? $cerapan->efd_opr_3 : '') ?>">
                    </td>

                    <!-- MAX -->
                    <td>
                        <input type="number" name="vfd_max_3" id="vfd_max_3" step="any"
                            value="<?= set_value('vfd_max_3', isset($cerapan->vfd_max_3)? $cerapan->vfd_max_3 : '') ?>"
                            oninput="onNumChange('efd','max',3)">
                    </td>
                    <td>
                        <input type="number" name="vref_max_3" id="vref_max_3" step="any"
                            value="<?= set_value('vref_max_3', isset($cerapan->vref_max_3)? $cerapan->vref_max_3 : '') ?>"
                            oninput="onNumChange('efd','max',3)">
                    </td>
                    <td>
                        <input type="text" name="efd_max_3" id="efd_max_3" readonly
                            value="<?= set_value('efd_max_3', isset($cerapan->efd_max_3)? $cerapan->efd_max_3 : '') ?>">
                    </td>
                </tr>
            </table>
        </div>

            <table class="table table-bordered text-center">
                <tr>
                    <th></th>
                    <th></th>
                    <th>Laju Alir Minimum</th>
                    <th>Laju Alir Operasional</th>
                    <th>Laju Alir Maksimum</th>
                </tr>
                <tr>
                    <td><b>Kesalahan Rata-rata (EΔV) </b></td>
                    <td>(%)</td>
                    <td><input type="text" id="error_min" name="error_min" style="width: 100px;" readonly></td>
                    <td><input type="text" id="error_opr" name="error_opr" style="width: 100px;" readonly></td>
                    <td><input type="text" id="error_max" name="error_max" style="width: 100px;" readonly></td>
                </tr>
                <tr>
                    <td><b>Ketidaktetapan</b></td>
                    <td>(%)</td>
                    <td><input type="text" id="uncertainty_min" name="uncertainty_min" style="width: 100px;" readonly></td>
                    <td><input type="text" id="uncertainty_opr" name="uncertainty_opr" style="width: 100px;" readonly></td>
                    <td><input type="text" id="uncertainty_max" name="uncertainty_max" style="width: 100px;" readonly></td>
                </tr>
            </table>

        <h4 class="mb-3" style="margin-top: 40px;">Pengujian Laju Alir Maksimum</h4>
        <div class="mb-2">
            <label for="viskositas" class="form-label"><strong>Viskositas Fluida</strong></label>
            <select class="form-select" name="viskositas" id="viskositas" required
                    onchange="calcEFD_ED()">
                <option value="">-- Pilih Viskositas --</option>
                <option value="<=1" <?= set_select('viskositas','<=1', isset($cerapan->viskositas)&&$cerapan->viskositas==='<=1') ?>>&le; 1 mPa</option>
                <option value=">1"  <?= set_select('viskositas','>1',  isset($cerapan->viskositas)&&$cerapan->viskositas==='>1')  ?>>&gt; 1 mPa</option>
            </select>
        </div>

        <table class="table table-bordered">
        <thead class="text-center">
            <tr>
            <th rowspan="2">Jenis Pengujian</th>
            <th colspan="3">Penjatah Volume</th>
            <th colspan="3">Penjatah Harga</th>
            <th rowspan="2">ED</th>
            </tr>
            <tr>
            <th>VFD (mL)</th>
            <th>VREF (mL)</th>
            <th>EFD</th>
            <th>VFD (mL)</th>
            <th>VREF (mL)</th>
            <th>EFD</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>Akurasi Penjatah</td>

            <td><input type="number" step="any" id="vfd_vol"  name="vfd_vol"
                        value="<?= set_value('vfd_vol',  isset($cerapan->vfd_vol)?$cerapan->vfd_vol:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="number" step="any" id="vref_vol" name="vref_vol"
                        value="<?= set_value('vref_vol', isset($cerapan->vref_vol)?$cerapan->vref_vol:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="text" id="efd_vol" name="efd_vol" class="form-control" readonly
                        value="<?= set_value('efd_vol', isset($cerapan->efd_vol)?$cerapan->efd_vol:'') ?>"></td>

            <td><input type="number" step="any" id="vfd_hrg"  name="vfd_hrg"
                        value="<?= set_value('vfd_hrg',  isset($cerapan->vfd_hrg)?$cerapan->vfd_hrg:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="number" step="any" id="vref_hrg" name="vref_hrg"
                        value="<?= set_value('vref_hrg', isset($cerapan->vref_hrg)?$cerapan->vref_hrg:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="text" id="efd_hrg" name="efd_hrg" class="form-control" readonly
                        value="<?= set_value('efd_hrg', isset($cerapan->efd_hrg)?$cerapan->efd_hrg:'') ?>"></td>

            <!-- kolom ED ada di baris bawah (rowspan=2) -->
            </tr>

            <tr>
            <td>Penyerahan Eliminasi Udara</td>

            <td><input type="number" step="any" id="vfd_elu"  name="vfd_elu"
                        value="<?= set_value('vfd_elu',  isset($cerapan->vfd_elu)?$cerapan->vfd_elu:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="number" step="any" id="vref_elu" name="vref_elu"
                        value="<?= set_value('vref_elu', isset($cerapan->vref_elu)?$cerapan->vref_elu:'') ?>"
                        oninput="calcEFD_ED()" class="form-control"></td>

            <td><input type="text" id="efd_elu" name="efd_elu" class="form-control" readonly
                        value="<?= set_value('efd_elu', isset($cerapan->efd_elu)?$cerapan->efd_elu:'') ?>"></td>

            <td></td><td></td><td></td>

            <td rowspan="2"><input type="text" id="ed_result" name="ed_result" class="form-control" readonly
                        value="<?= set_value('ed_result', isset($cerapan->ed_result)?$cerapan->ed_result:'') ?>"></td>
            </tr>
        </tbody>
        </table>

        <table class="table table-bordered">
            <thead>
                <tr class="text-center">
                <th style="width:220px">Pilihan Hose Reel</th>
                <th>BKD (Batas Kesalahan Diizinkan) [mL]</th>
                <th>Vmin [L]</th>
                <th>Hasil Pengujian Anti-drain [mL]</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>
                    <label class="me-3 d-block">
                    <input type="radio" name="hose_reel" value="dengan"
                        <?= set_radio('hose_reel','dengan', isset($cerapan->hose_reel)&&$cerapan->hose_reel==='dengan') ?>
                        onchange="onAntidrainChange()"> Dengan hose reel
                    </label>
                    <label class="d-block">
                    <input type="radio" name="hose_reel" value="tanpa"
                        <?= set_radio('hose_reel','tanpa', isset($cerapan->hose_reel)&&$cerapan->hose_reel==='tanpa') ?>
                        onchange="onAntidrainChange()"> Tanpa hose reel
                    </label>
                </td>

                <!-- BKD otomatis (readonly) -->
                <td>
                    <input type="number" id="bkd_anti_drain" name="bkd_anti_drain" class="form-control" readonly
                        value="<?= set_value('bkd_anti_drain', isset($cerapan->bkd_anti_drain)?$cerapan->bkd_anti_drain:'') ?>">
                </td>

                <!-- Vmin (L) -->
                <td>
                    <input type="number" step="any" id="vmin_anti_drain" name="vmin_anti_drain" class="form-control"
                        value="<?= set_value('vmin_anti_drain', isset($cerapan->vmin_anti_drain)?$cerapan->vmin_anti_drain:'') ?>"
                        placeholder="Masukkan angka satuan L"
                        oninput="onAntidrainChange()">
                </td>

                <!-- Hasil uji anti-drain (mL) -->
                <td>
                    <input type="number" step="any" id="hasil_anti_drain" name="hasil_anti_drain" class="form-control"
                        value="<?= set_value('hasil_anti_drain', isset($cerapan->hasil_anti_drain)?$cerapan->hasil_anti_drain:'') ?>"
                        placeholder="Masukkan hasil uji"
                        oninput="onAntidrainChange()">
                </td>
                </tr>
            </tbody>
        </table>

        <table class="table table-bordered">
            <thead class="text-center">
                <tr>
                    <th></th>
                    <th>Volume (V) [L]</th>
                    <th>Waktu (t) [s]</th>
                    <th>Laju Alir (Q) [L/min]</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Laju Alir Maksimum</td>
                    <td>
                        <input type="number" step="any" id="vol_laju_max" name="vol_laju_max"
                        value="<?= set_value('vol_laju_max', isset($cerapan->vol_laju_max)?$cerapan->vol_laju_max:'') ?>"
                        oninput="calcEFD_ED()" class="form-control">
                    </td>
                    <td>
                        <input type="number" step="any" id="waktu_laju_max" name="waktu_laju_max"
                        value="<?= set_value('waktu_laju_max', isset($cerapan->waktu_laju_max)?$cerapan->waktu_laju_max:'') ?>"
                        oninput="calcEFD_ED()" class="form-control">
                    </td>
                    <td>
                        <input type="text" id="q_laju_max" name="q_laju_max" class="form-control" readonly
                        value="<?= set_value('q_laju_max', isset($cerapan->q_laju_max)?$cerapan->q_laju_max:'') ?>">
                    </td>
                </tr>
            </tbody>
        </table>

        <table class="table table-bordered text-center align-middle">
            <thead>
                <tr>
                    <th>Uji Fungsi</th>
                    <th>Lolos</th>
                    <th>Gagal</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-start">Fasilitas pemeriksa untuk perangkat penunjukan</td>
                    <td>
                        <input type="radio" name="uji_1" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_1','Lolos', isset($cerapan->uji_1) && $cerapan->uji_1==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_1" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_1','Gagal', isset($cerapan->uji_1) && $cerapan->uji_1==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start">Penyetelan nol</td>
                    <td>
                        <input type="radio" name="uji_2" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_2','Lolos', isset($cerapan->uji_2) && $cerapan->uji_2==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_2" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_2','Gagal', isset($cerapan->uji_2) && $cerapan->uji_2==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start">Perhitungan harga</td>
                    <td>
                        <input type="radio" name="uji_3" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_3','Lolos', isset($cerapan->uji_3) && $cerapan->uji_3==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_3" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_3','Gagal', isset($cerapan->uji_3) && $cerapan->uji_3==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start">Nozzle cut-off</td>
                    <td>
                        <input type="radio" name="uji_4" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_4','Lolos', isset($cerapan->uji_4) && $cerapan->uji_4==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_4" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_4','Gagal', isset($cerapan->uji_4) && $cerapan->uji_4==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start">Interlock</td>
                    <td>
                        <input type="radio" name="uji_5" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_5','Lolos', isset($cerapan->uji_5) && $cerapan->uji_5==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_5" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_5','Gagal', isset($cerapan->uji_5) && $cerapan->uji_5==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start">Penunjukan penjatah (pre-set)</td>
                    <td>
                        <input type="radio" name="uji_6" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_6','Lolos', isset($cerapan->uji_6) && $cerapan->uji_6==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_6" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_6','Gagal', isset($cerapan->uji_6) && $cerapan->uji_6==='Gagal') ?>>
                    </td>
                </tr>
                <tr>
                    <td class="text-start"><strong>Hasil keseluruhan</strong></td>
                    <td>
                        <input type="radio" name="uji_7" value="Lolos" onclick="toggleCheck(this)"
                        <?= set_radio('uji_7','Lolos', isset($cerapan->uji_7) && $cerapan->uji_7==='Lolos') ?>>
                    </td>
                    <td>
                        <input type="radio" name="uji_7" value="Gagal" onclick="toggleCheck(this)"
                        <?= set_radio('uji_7','Gagal', isset($cerapan->uji_7) && $cerapan->uji_7==='Gagal') ?>>
                    </td>
                </tr>
            </tbody>
        </table>
        
            <div class="form-group mt-3">
                <button type="submit" class="btn btn-danger">Kembali</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>

            <?= form_close(); ?>
        </section>
    </div>
</div>

<script>
    // ------ Helper angka: dukung koma ------
    function toNumber(x){
        if (x===null || x===undefined) return NaN;
        const s = String(x).trim().replace(',', '.');
        const n = parseFloat(s);
        return isNaN(n) ? NaN : n;
    }

    function formatAngka(n, maxDec=3){
        if (n===null || n===undefined || isNaN(n)) return '';
        const f = Math.pow(10, maxDec);
        const r = Math.round(n * f) / f;
        if (Number.isInteger(r)) return String(Math.trunc(r));
        return r.toFixed(maxDec).replace(/\.?0+$/, '');
        }

    // ------ TOTALISATOR (kalau kamu pakai total_awal_{jenis}) ------
    function hitungVolume(jenis) {
        const awal  = toNumber(document.getElementById('total_awal_'  + jenis)?.value);
        const akhir = toNumber(document.getElementById('total_akhir_' + jenis)?.value);
        const volume = akhir - awal;
        document.getElementById('volum_total_' + jenis).value =
            (!isNaN(awal) && !isNaN(akhir)) ? formatAngka(akhir - awal, 3) : '';
    }

    // ------ EFD baris per baris: ((VFD - VREF)/VREF)*100 ------
    function hitungEFD(tipe, urutan) {
        const vfd = toNumber(document.getElementById(`vfd_${tipe}_${urutan}`)?.value);
        const vref= toNumber(document.getElementById(`vref_${tipe}_${urutan}`)?.value);
        const out = document.getElementById(`efd_${tipe}_${urutan}`);
        if (!out) return;

        if (!isNaN(vfd) && !isNaN(vref) && vref !== 0) {
            const efd = ((vfd - vref) / vref) * 100;
            out.value = efd.toFixed(2); // simpan ANGKA saja
        } else {
            out.value = '';
        }
        calculateAverageEFD();
        calculateUncertainty();
    }

    // ------ Rata-rata EFD per mode ------
    function calculateAverageEFD() {
        ['min','opr','max'].forEach(type => {
            let sum = 0, count = 0;
            for (let i = 1; i <= 3; i++) {
            const el = document.getElementById(`efd_${type}_${i}`);
            const val = toNumber(el?.value);
            if (!isNaN(val)) { sum += val; count++; }
            }
            const out = document.getElementById(`error_${type}`);
            if (out) out.value = count ? (sum / count).toFixed(2) : '';
        });
    }

    // ------ Uncertainty sederhana (range) per mode ------
    function calculateUncertainty() {
        ['min','opr','max'].forEach(type => {
            const vals = [];
            for (let i = 1; i <= 3; i++) {
            const v = toNumber(document.getElementById(`efd_${type}_${i}`)?.value);
            if (!isNaN(v)) vals.push(v);
            }
            const out = document.getElementById(`uncertainty_${type}`);
            if (!out) return;
            if (vals.length) out.value = (Math.max(...vals) - Math.min(...vals)).toFixed(2);
            else out.value = '';
        });
    }

    // ------ Akurasi/Eliminasi/Harga + ED ------
    function calculateEFDandED() {
        const eav_max = toNumber(document.getElementById('error_max')?.value);

        const vfd_vol = toNumber(document.getElementById('vfd_vol')?.value);
        const vref_vol= toNumber(document.getElementById('vref_vol')?.value);

        const vfd_hrg = toNumber(document.getElementById('vfd_hrg')?.value);
        const vref_hrg= toNumber(document.getElementById('vref_hrg')?.value);

        const vfd_elu = toNumber(document.getElementById('vfd_elu')?.value);
        const vref_elu= toNumber(document.getElementById('vref_elu')?.value);

        const efd_vol = (!isNaN(vfd_vol) && !isNaN(vref_vol) && vref_vol!==0) ? ((vfd_vol - vref_vol)/vref_vol)*100 : NaN;
        const efd_hrgV= (!isNaN(vfd_hrg) && !isNaN(vref_hrg) && vref_hrg!==0) ? ((vfd_hrg - vref_hrg)/vref_hrg)*100 : NaN;
        const efd_eluV= (!isNaN(vfd_elu) && !isNaN(vref_elu) && vref_elu!==0) ? ((vfd_elu - vref_elu)/vref_elu)*100 : NaN;

        const ed = (!isNaN(eav_max) && !isNaN(efd_eluV)) ? (eav_max - efd_eluV) : NaN;

        const set = (id,val)=>{ const el=document.getElementById(id); if(el) el.value = isNaN(val)? '' : val.toFixed(2); };
        set('efd_vol', efd_vol);
        set('efd_hrg', efd_hrgV);
        set('efd_elu', efd_eluV);
        set('ed_result', ed);
    }

    // ------ Laju alir maksimum: Q = (V / t) * 60 ------
    function hitungLajuAlirMax() {
        const v = toNumber(document.getElementById('vol_laju_max')?.value); // liter
        const t = toNumber(document.getElementById('waktu_laju_max')?.value);  // detik
        const out = document.getElementById('q_laju_max');
        if (!out) return;
        if (!isNaN(v) && !isNaN(t) && t !== 0) out.value = ((v/t)*60).toFixed(2);
        else out.value = '';
    }

    function onAntidrainChange(){
        const vmin = toNum(document.getElementById('vmin_anti_drain')?.value); // dalam Liter
        const hose = document.querySelector('input[name="hose_reel"]:checked')?.value; // 'dengan' | 'tanpa'

        let bkd = NaN;
        if (!isNaN(vmin) && hose){  // pastikan ada Vmin dan pilihan hose
            if (vmin === 2)      bkd = (hose === 'dengan') ? 40 : 20;   // mL
            else if (vmin === 5) bkd = (hose === 'dengan') ? 100 : 50;  // mL
            else                 bkd = (hose === 'dengan' ? 20 : 10) * vmin; // mL
        }

        const out = document.getElementById('bkd_anti_drain');
        if (out) out.value = isNaN(bkd) ? '' : Math.round(bkd * 1000) / 1000; // rapi (≤3 desimal)
    }

    // ------ Satu listener untuk SEMUA VFD/VREF ------
    document.addEventListener('input', function(e){
        const t = e.target;
        if (t && (t.id||'').startsWith('vfd_') || (t.id||'').startsWith('vref_')) {
            const parts = (t.id||'').split('_'); // contoh: vfd_min_1
            const mode = parts[1];               // min/opr/max
            const idx  = parseInt(parts[2],10);  // 1/2/3
            if (mode && idx) hitungEFD(mode, idx);
        }
    });

    // ------ Listener aman (cek elemen ada dulu) ------
    ['vfd_vol','vref_vol','vfd_elu','vref_elu','vfd_hrg','vref_hrg'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', calculateEFDandED);
        });
        const volMaxEl = document.getElementById('volume_laju_max');
        if (volMaxEl) volMaxEl.addEventListener('input', hitungLajuAlirMax);
        const tMaxEl = document.getElementById('waktu_laju_max');
        if (tMaxEl) tMaxEl.addEventListener('input', hitungLajuAlirMax);

    // ------ Saat halaman EDIT dibuka, hitung semua dari nilai yang sudah terisi ------
    document.addEventListener('DOMContentLoaded', function(){
        // EFD untuk semua kombinasi (ubah 1..3 sesuai jumlah barismu)
        ['min','opr','max'].forEach(m => [1,2,3].forEach(i => hitungEFD(m,i)));

        // Akurasi/Eliminasi/Harga + ED
        calculateEFDandED();

        // Laju alir maks
        hitungLajuAlirMax();

        // Kalau kamu pakai totalisator min/opr/max, panggil tiga ini:
        hitungVolume('min'); 
        hitungVolume('opr'); 
        hitungVolume('max');
        // Kalau cuma satu totalisator: panggil versi satunya saja (hitungVolumeTotal), bukan fungsi di atas.
    });

    document.addEventListener('DOMContentLoaded', onAntidrainChange);
    document.querySelectorAll('input[name="hose_reel"]').forEach(r => r.addEventListener('change', onAntidrainChange));
    document.getElementById('vmin_anti_drain')?.addEventListener('input', onAntidrainChange);
    
</script>
