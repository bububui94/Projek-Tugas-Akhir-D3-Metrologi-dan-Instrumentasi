<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_meter_air extends CI_Model {
    public function add($data) {
        $nominal = $data['laju_alir_nominal'];
        $rasio = $data['rasio'];
        $data['laju_alir_maksimum'] = $nominal * 1.25;
        $data['laju_alir_minimum'] = $nominal / $rasio;
        $data['laju_alir_transisi'] = ($nominal / $rasio) * 1.6;
        return $this->db->insert('m_meter_air', $data);        
    }

    public function read() {
        $this->db->select('m_meter_air.*, m_pt_meter_air.nama_pt');
        $this->db->from('m_meter_air');
        $this->db->join('m_pt_meter_air', 'm_pt_meter_air.id = m_meter_air.id_perusahaan');
        return $this->db->get();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        $nominal = $data['laju_alir_nominal'];
        $rasio = $data['rasio'];
        $data['laju_alir_maksimum'] = $nominal * 1.25;
        $data['laju_alir_minimum'] = $nominal / $rasio;
        $data['laju_alir_transisi'] = ($nominal / $rasio) * 1.6;
        return $this->db->update('m_meter_air', $data);
    }

    public function delete($id) {
        return $this->db->delete('m_meter_air', ['id' => $id]);
    }

    public function get_existing_serials($nomor_seri, $id_perusahaan) {
        $this->db->select('nomor_seri');
        $this->db->from('m_meter_air');
        $this->db->where('id_perusahaan', $id_perusahaan);
        $this->db->where_in('nomor_seri', $nomor_seri);
        $query = $this->db->get();

        return array_column($query->result_array(), 'nomor_seri');
    }

    public function get_existing_serials_by_status($nomor_seri, $id_perusahaan, $allowed_status) {
        $this->db->select('nomor_seri');
        $this->db->from('m_meter_air');
        $this->db->where('id_perusahaan', $id_perusahaan);
        $this->db->where_in('nomor_seri', $nomor_seri);
        $this->db->where_in('status', $allowed_status);
        $query = $this->db->get();

        return array_column($query->result_array(), 'nomor_seri');
    }

    public function get_by_nomor_seri($nomor_seri) {
        return $this->db
            ->where_in('nomor_seri', $nomor_seri)
            ->get('m_meter_air')
            ->result();
    }

    public function get_by_single_nomor_seri($nomor_seri) {
        return $this->db->get_where('m_meter_air', ['nomor_seri' => $nomor_seri])->row();
    }

    public function count() {
        return $this->db->count_all('m_meter_air');
    }
}