<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Surat Tugas PUBBM</strong></h1>
        </div>

        <section class="content">
            <table class="table box table-sm" id="list_st_pubbm">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-3">NO. SURAT TUGAS</th>
                        <th class="col-3">SPBU PEMILIK</th>
                        <th class="col-2">TERA / TERA ULANG</th>
                        <th class="col-2">TANGGAL PELAKSANAAN</th>
                        <th class="col-1 text-center" colspan="2" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($surat_tugas as $st) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $st->nomor_st ?></td>
                            <td><?= $st->nama_spbu ?></td>
                            <td><?= $st->ttu ?></td>
                            <td><?= indo_date($st->tgl_pelaksanaan) ?></td>

                            <?php $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $st->nomor_st); ?>
                            <td><a href="<?= base_url('assets/st_pubbm/Surat Tugas Nomor ' . $safe_nomor_st . '.pdf') ?>" target="_blank" class="btn btn-warning btn-sm"> <i class="fas fa-download"></i></a></td>
                            <td>
                                <?php if ($st->status_terima == 0): ?>
                                    <?= form_open('penera/st_pubbm/send', ['class' => 'send-st-form']); ?>
                                        <input type="hidden" name="id" value="<?= $st->id ?>">
                                        <button type="submit" class="btn btn-success btn-sm btn-kirim" data-id="<?= $st->id ?>">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    <?= form_close(); ?>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check"></i></button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#list_st_pubbm').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });

        $('.send-st-form').on('submit', function(e) {
            const btn = $(this).find('button[type="submit"]');
            btn.prop('disabled', true);
            btn.removeClass('btn-success').addClass('btn-secondary');
        });
    });
</script>