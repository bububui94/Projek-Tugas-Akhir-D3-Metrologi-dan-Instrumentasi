<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_pt_meter_air extends CI_Model {
    public function add($data) {
        return $this->db->insert('m_pt_meter_air', $data);        
    }

    public function read() {
        $this->db->select('m_pt_meter_air.*, COUNT(m_meter_air.id) as jumlah_meter_air');
        $this->db->from('m_pt_meter_air');
        $this->db->join('m_meter_air', 'm_meter_air.id_perusahaan = m_pt_meter_air.id', 'left');
        $this->db->group_by('m_pt_meter_air.id');
        return $this->db->get();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('m_pt_meter_air', $data);
    }

    public function delete($id) {
        return $this->db->delete('m_pt_meter_air', ['id' => $id]);
    }

    public function get_by_id($id) {
        return $this->db
            ->get_where('m_pt_meter_air', ['id' => $id])
            ->row();
    }

    public function count() {
        return $this->db->count_all('m_pt_meter_air');
    }
}