<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('penera/model_st_pubbm');
        $this->load->model('penera/model_st_meter_air');
        $this->load->model('penera/model_cerapan_pubbm');
        $this->load->model('penera/model_cerapan_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 3) {
            show_error('Unauthorized access');
        }
    }
    public function index() {
        $id_pegawai = $this->session->userdata('id_pegawai');

        $data ['st_pubbm'] = $this->model_st_pubbm->count($id_pegawai);
        $data ['st_meter_air'] = $this->model_st_meter_air->count($id_pegawai);
        $data ['cerapan_pubbm'] = $this->model_cerapan_pubbm->count($id_pegawai);
        $data ['cerapan_meter_air'] = $this->model_cerapan_meter_air->count($id_pegawai);

        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/dashboard', $data);
        $this->load->view('templates_penera/footer');
    }
}