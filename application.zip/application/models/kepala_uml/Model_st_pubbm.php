<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_st_pubbm extends CI_Model {
    public function add($data) {
        return $this->db->insert('t_st_pubbm', $data);
    }

    public function read() {
        $this->db->select('t_st_pubbm.*, m_spbu.nama_spbu, m_pegawai.nama_lengkap');
        $this->db->from('t_st_pubbm');
        $this->db->join('m_spbu', 'm_spbu.id = t_st_pubbm.spbu_id', 'left');
        $this->db->join('m_pegawai', 'm_pegawai.id = t_st_pubbm.ketua_pelaksana', 'left');
        $this->db->order_by('t_st_pubbm.id', 'ASC');
        return $this->db->get();
    }

    public function delete($id) {
        return $this->db->delete('t_st_pubbm', ['id' => $id]);
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('t_st_pubbm', $data);
    }

    public function get_by_id($id) {
        return $this->db->get_where('t_st_pubbm', ['id' => $id])->row();
    }

    public function get_by_nomor_st($nomor_st) {
        return $this->db->get_where('t_st_pubbm', ['nomor_st' => $nomor_st])->row();
    }

    public function mark_as_sent($id) {
        return $this->db
            ->where('id', $id)
            ->update('t_st_pubbm', ['status_kirim' => 1]);
    }

    public function read_sent_only() {
        $this->db->select('t_st_pubbm.*, m_spbu.nama_spbu, m_pegawai.nama_lengkap');
        $this->db->from('t_st_pubbm');
        $this->db->join('m_spbu', 'm_spbu.id = t_st_pubbm.spbu_id', 'left');
        $this->db->join('m_pegawai', 'm_pegawai.id = t_st_pubbm.ketua_pelaksana', 'left');
        $this->db->where('t_st_pubbm.status_kirim', 1); 
        $this->db->order_by('t_st_pubbm.id', 'ASC');
        return $this->db->get();
    }

    public function count() {
        return $this->db->count_all('t_st_pubbm');
    }
}
