<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_cerapan_pubbm extends CI_Model {
    public function get_all() {
        $this->db->select('t_cerapan_pubbm.*, t_st_pubbm.status_kirim, t_st_pubbm.status_terima, m_spbu.nama_spbu');
        $this->db->from('t_cerapan_pubbm');
        $this->db->join('t_st_pubbm', 't_st_pubbm.id = t_cerapan_pubbm.st_pubbm_id'); // join benar ✅
        $this->db->join('m_spbu', 'm_spbu.id = t_cerapan_pubbm.spbu_id', 'left');
        $this->db->where('t_st_pubbm.status_kirim', 1);
        $this->db->where('t_st_pubbm.status_terima', 1); // hanya tampil kalau status_terima = 1 ✅
        return $this->db->get()->result();
    }

    public function insert($data) {
        $this->db->insert('t_cerapan_pubbm', $data);
        return $this->db->insert_id(); 
    }

    public function get_by_id($id_cerapan) {
        $this->db->select('t_cerapan_pubbm.*, m_nozzle.kapasitas_min as kap_min, m_nozzle.kapasitas_max as kap_max');
        $this->db->from('t_cerapan_pubbm');
        $this->db->join('m_nozzle', 'm_nozzle.nomor_seri = t_cerapan_pubbm.nomor_seri', 'left');
        $this->db->where('t_cerapan_pubbm.id', $id_cerapan);
        return $this->db->get()->row();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('t_cerapan_pubbm', $data);
    }

    public function count($id_pegawai) {
        if ($id_pegawai) {
            $this->db->where('id_pegawai', $id_pegawai);
        }
        return $this->db->count_all_results('t_cerapan_meter_air');
    }
}