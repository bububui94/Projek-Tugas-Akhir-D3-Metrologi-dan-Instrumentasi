<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><strong>Daftar Pegawai</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_pegawai"><i class="fa fa-plus"></i> Tambah Pegawai</button>
            <table class="table box table-sm" id="list_pegawai">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-4">NAMA LENGKAP</th>
                        <th class="col-1">STATUS</th>
                        <th class="col-3">NIP</th>
                        <th class="col-2">JABATAN</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($pegawai as $pgw) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $pgw->nama_lengkap ?></td>
                            <td><?= $pgw->status ?></td>
                            <td><?= $pgw->nip ?></td>
                            <td><?= $pgw->jabatan ?></td>
                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_pegawai_<?= $pgw->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_pegawai_<?= $pgw->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_pegawai_<?= $pgw->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <!-- Modal for Detail Pegawai -->
                        <div class="modal fade" id="detail_pegawai_<?= $pgw->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail Pegawai</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Nama Lengkap:</strong> <?= $pgw->nama_lengkap ?></p>
                                        <p><strong>Status:</strong> <?= $pgw->status ?></p>
                                        <p><strong>NIP:</strong> <?= $pgw->nip ?: '-' ?></p>
                                        <p><strong>Golongan:</strong> <?= $pgw->golongan ?: '-' ?></p>
                                        <p><strong>Jabatan:</strong> <?= $pgw->jabatan ?: '-' ?></p>
                                        <p><strong>Email:</strong> <?= $pgw->email ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for Editing Pegawai -->
                        <div class="modal fade" id="edit_pegawai_<?= $pgw->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/pegawai/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Edit Pegawai</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $pgw->id ?>">

                                        <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input type="text" name="nama_lengkap" class="form-control" value="<?= $pgw->nama_lengkap ?>" required placeholder="Nama Lengkap dan Gelar">
                                        </div>
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select class="form-control status-select" name="status" required>
                                                <option value="PNS" <?= $pgw->status == 'PNS' ? 'selected' : '' ?>>PNS</option>
                                                <option value="PPPK" <?= $pgw->status == 'PPPK' ? 'selected' : '' ?>>PPPK</option>
                                                <option value="Magang" <?= $pgw->status == 'Magang' ? 'selected' : '' ?>>Magang</option>
                                            </select>
                                        </div>
                                        <div class="form-group nip-field" style="display:none;">
                                            <label>NIP</label>
                                            <input type="text" name="nip" class="form-control" value="<?= $pgw->nip ?>">
                                        </div>
                                        <div class="form-group golongan-field" style="display:none;">
                                            <label>Golongan</label>
                                            <input type="text" name="golongan" class="form-control" value="<?= $pgw->golongan ?>">
                                        </div>
                                        <div class="form-group jabatan-field" style="display:none;">
                                            <label>Jabatan</label>
                                            <input type="text" name="jabatan" class="form-control" value="<?= $pgw->jabatan ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control" value="<?= $pgw->email ?>" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for Deleting Pegawai -->
                        <div class="modal fade" id="delete_pegawai_<?= $pgw->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/pegawai/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus Pegawai</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $pgw->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus pegawai ini?</h5>
                                        <p class="text-danger"><strong>User yang terkait</strong> dengan pegawai ini akan ikut terhapus. Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Add Modal -->
        <div class="modal fade" id="add_pegawai" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/pegawai/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Pegawai</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" class="form-control" required placeholder="Nama Lengkap dan Gelar">
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control status-select" name="status" required>
                                <option value="PNS">PNS</option>
                                <option value="PPPK">PPPK</option>
                                <option value="Magang">Magang</option>
                            </select>
                        </div>
                        <div class="form-group nip-field" style="display:none;">
                            <label>NIP</label>
                            <input type="text" name="nip" class="form-control">
                        </div>
                        <div class="form-group golongan-field" style="display:none;">
                            <label>Golongan</label>
                            <input type="text" name="golongan" class="form-control">
                        </div>
                        <div class="form-group jabatan-field" style="display:none;">
                            <label>Jabatan</label>
                            <input type="text" name="jabatan" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $('.modal').on('shown.bs.modal', function() {
        $(this).find('.status-select').trigger('change');
    });

    $(document).ready(function() {
        $('.status-select').on('change', function() {
            const status = $(this).val();
            const modalBody = $(this).closest('.modal-body');

            const nip = modalBody.find('.nip-field');
            const golongan = modalBody.find('.golongan-field');
            const jabatan = modalBody.find('.jabatan-field');

            if (status === 'PNS') {
                nip.show();
                golongan.show();
                jabatan.show();
            } else if (status === 'PPPK') {
                nip.show()
                golongan.hide().find('input').val('');
                jabatan.show();
            } else if (status === 'Magang') {
                nip.hide().find('input').val('');
                golongan.hide().find('input').val('');
                jabatan.hide().find('input').val('');
            }
        });

        $('.status-select').trigger('change');
    });
</script>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_pegawai').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>