<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ST PUBBM <?= $surat_tugas->nomor_st ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/css/st_pubbm_pdf.css') ?>">
</head>

<body>
    <hr>
    <table>
        <tr class="font-size-14 bold center underline">
            <td colspan="6">SURAT TUGAS</td>
        </tr>
        <tr class="font-size-10 center">
            <td colspan="6">Nomor: <?= $surat_tugas->nomor_st ?></td>
        </tr>
        <tr><td colspan="6"><br></td></tr>

        <tr>
            <td class="col-15">Dasar</td>
            <td class="col-5">:</td>
            <td colspan="4">Permohonan <?= $surat_tugas->ttu ?> UTTP PUBBM dari <?= $daftar_spbu->nama_spbu ?></td>
        </tr>

        <tr><td colspan="6"><br></td></tr>

        <tr class="center bold">
            <td colspan="6">MEMERINTAHKAN</td>
        </tr>

        <tr>
            <td>Kepada</td>
            <td>:</td>
            <td colspan="4">Ketua Pelaksana</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Nama / NIP</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->nama_lengkap ?> / <?= $ketua_pelaksana->nip ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Jabatan</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->jabatan ?></td>
        </tr>

        <tr><td colspan="6"><br></td></tr>

        <tr>
            <td colspan="2"></td>
            <td colspan="4">Pendamping</td>
        </tr>

        <?php $no = 1; foreach ($pendampings as $pendamping): ?>
        <tr>
            <td colspan="2"></td>
            <td class="col-5"><?= $no++ ?>.</td>
            <td class="col-15">Nama / NIP</td>
            <td class="col-1">:</td>
            <td><?= $pendamping->nama_lengkap ?> / <?= $pendamping->nip ?></td>
        </tr>
        <tr>
            <td colspan="3"></td>
            <td class="col-15">Jabatan</td>
            <td class="col-1">:</td>
            <td><?= $pendamping->jabatan ?></td>
        </tr>
        <?php endforeach; ?>

        <tr><td colspan="6"><br></td></tr>

        <tr>
            <td>Untuk</td>
            <td>:</td>
            <td colspan="4">Melaksanakan pelayanan <?= $surat_tugas->ttu ?> UTTP PUBBM</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">SPBU</td>
            <td>:</td>
            <td><?= $daftar_spbu->nama_spbu ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Lokasi</td>
            <td>:</td>
            <td><?= $daftar_spbu->lokasi ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Tanggal</td>
            <td>:</td>
            <td><?= indo_date($surat_tugas->tgl_pelaksanaan) ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Jumlah Nozzle</td>
            <td>:</td>
            <td>Terlampir</td>
        </tr>
    </table>

    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">

    <table>
        <tr>
            <td class="col-60"></td>
            <td class="center">Dibuat di Sumedang</td>
        </tr>
        <tr>
            <td></td>
            <td class="center">pada tanggal <?= indo_date($surat_tugas->tgl_pembuatan) ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="center">Kepala UML</td>
        </tr>
        <tr><td><br><br><br></td></tr>
        <tr>
            <td></td>
            <td class="center">(.......................................)</td>
        </tr>
    </table>

    <div class="page-break"></div>

    <h4>Lampiran</h4>
    <br class="spacing-2">
    <table class="table-bordered">
        <thead>
            <tr class="bold">
                <th class="col-5">No.</th>
                <th class="col-15">Merek</th>
                <th class="col-15">Model/Tipe</th>
                <th class="col-15">Nomor Seri</th>
                <th class="col-10">Kapasitas Max (L/min)</th>
                <th class="col-10">Kapasitas Min (L/min)</th>
                <th class="col-10">Tekanan Max (MPa)</th>
                <th class="col-10">Suhu Min (C)</th>
                <th class="col-10">Suhu Max (C)</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($list_pubbm as $pubbm): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $pubbm->merek ?></td>
                <td><?= $pubbm->model_tipe ?></td>
                <td><?= $pubbm->nomor_seri ?></td>
                <td><?= $pubbm->kapasitas_max ?></td>
                <td><?= $pubbm->kapasitas_min ?></td>
                <td><?= $pubbm->tekanan_max ?></td>
                <td><?= $pubbm->suhu_min ?></td>
                <td><?= $pubbm->suhu_max ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>
