<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('model_auth');
    }

    public function index() {
        if ($this->session->userdata('logged_in')) {
            // User already logged in — redirect based on role
            $role = $this->session->userdata('id_role');
            if ($role == 1) {
                redirect('kepala_uml/dashboard');
            } elseif ($role == 2) {
                redirect('tata_usaha/dashboard');
            } elseif ($role == 3) {
                redirect('penera/dashboard');
            } else {
                redirect('auth/logout');
            }
        }

        // If not logged in, show login page
        $this->load->view('auth/login');
    }

    public function login() {
        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password', TRUE);

        $user = $this->model_auth->get_by_username($username);

        if ($user && password_verify($password, $user->password)) {
            $this->session->set_userdata([
                'user_id'   => $user->id,
                'id_role'   => $user->id_role,
                'username'  => $user->username,
                'id_pegawai'=> $user->id_pegawai,
                'logged_in' => TRUE
            ]);

            // Redirect based on role
            if ($user->id_role == 1) {
                redirect('kepala_uml/dashboard');
            } elseif ($user->id_role == 2) {
                redirect('tata_usaha/dashboard');
            } elseif ($user->id_role == 3) {
                redirect('penera/dashboard');
            } else {
                redirect('auth/logout');
            }
        } else {
            $this->session->set_flashdata('error', 'Invalid username or password.');
            redirect('auth');
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
}
