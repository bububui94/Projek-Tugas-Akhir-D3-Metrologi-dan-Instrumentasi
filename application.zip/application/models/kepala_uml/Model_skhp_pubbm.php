<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_skhp_pubbm extends CI_Model {
    public function count() {
        return $this->db->count_all('t_skhp_pubbm');
    }
}