<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_users');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['users'] = $this->model_users->read()->result();
        $data['count_tata_usaha'] = $this->model_users->count_tata_usaha();
        $data ['kepala_uml_exists'] = $this->model_users->kepala_uml_exists();
        $data ['pegawai'] = $this->model_users->enable_user()->result();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/user/list_users', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('id_pegawai', 'ID_Pegawai', 'required|integer');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('id_role', 'ID_Role', 'required|integer');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/users');
            return;
        }

        $data = [
            'id_pegawai' => $this->input->post('id_pegawai'),
            'username'  => $this->input->post('username'),
            'password'  => password_hash($this->input->post('password'), PASSWORD_DEFAULT), // hashing!
            'id_role'   => $this->input->post('id_role'),
        ];

        if ($this->model_users->pegawai_already_exists($this->input->post('id_pegawai'))) {
            $this->session->set_flashdata('error', 'Pegawai hanya boleh memiliki satu User.');
            redirect('tata_usaha/users');
        }

        if ($this->input->post('id_role') == 1 && $this->model_users->kepala_uml_exists()) {
            $this->session->set_flashdata('error', 'Hanya boleh ada satu Kepala UML');
            redirect('tata_usaha/users');
            return;
        }

        $this->model_users->add($data);
        $this->session->set_flashdata('success', 'User baru berhasil ditambahkan');
        redirect('tata_usaha/users');
    }

    public function update() {
        $this->form_validation->set_rules('id', 'ID', 'required|integer');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('id_role', 'ID_Role', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/users');
            return;
        }
        
        $id = $this->input->post('id');
        $password = $this->input->post('password');
        
        if ($this->model_users->get_by_id($id)->id_role == 2 && $this->model_users->count_tata_usaha() <= 1  && $this->input->post('id_role') != 2) {
            $this->session->set_flashdata('error', 'Tidak bisa mengubah satu-satunya User dengan role Tata Usaha');
            redirect('tata_usaha/users');
            return;
        }
        
        $data = [
            'username'  => $this->input->post('username'),
            'id_role'   => $this->input->post('id_role'),
        ];
        
        if (!empty($password)) {
            $data ['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $this->model_users->update($id, $data);
        $this->session->set_flashdata('success', 'Data user berhasil diperbarui');
        redirect('tata_usaha/users');
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        if ($this->model_users->get_by_id($id)->id_role == 2 && $this->model_users->count_tata_usaha() <= 1) {
            $this->session->set_flashdata('error', 'Tidak bisa menghapus satu-satunya User dengan role Tata Usaha');
            redirect('tata_usaha/users');
            return;
        }

        $this->model_users->delete($id);
        $this->session->set_flashdata('success', 'User berhasil dihapus');
        redirect('tata_usaha/users');
    }
}