<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nozzle extends CI_Controller {
    public function __construct() {
        parent :: __construct();
        $this->load->model('tata_usaha/model_nozzle');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $this->load->model('tata_usaha/model_spbu');
        $data ['daftar_spbu'] = $this->model_spbu->read()->result();
        $data ['nozzle'] = $this->model_nozzle->read()->result();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/pubbm/list_nozzle', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('spbu_id', 'SPBU_ID', 'required|integer');
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('nomor_seri', 'Nomor_Seri', 'required');
        $this->form_validation->set_rules('tahun_pembuatan', 'Tahun_Pembuatan', 'required');
        $this->form_validation->set_rules('model_tipe', 'Model_Tipe', 'required');
        $this->form_validation->set_rules('jenis_bbm', 'Jenis_BBM', 'required');
        $this->form_validation->set_rules('kapasitas_max', 'Kapasitas_Max', 'required');
        $this->form_validation->set_rules('kapasitas_min', 'Kapasitas_Min', 'required');
        $this->form_validation->set_rules('tekanan_max', 'Tekanan_Max', 'required');
        $this->form_validation->set_rules('suhu_min', 'Suhu_Min', 'required');
        $this->form_validation->set_rules('suhu_max', 'Suhu_Max', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/nozzle');
            return;
        }

        $id = $this->input->post('id');
        $status = $this->input->post('status');
        $data = [
            'spbu_id'            => $this->input->post('spbu_id'),
            'merek'              => $this->input->post('merek'),
            'nomor_seri'         => $this->input->post('nomor_seri'),
            'tahun_pembuatan'    => $this->input->post('tahun_pembuatan'),
            'model_tipe'         => $this->input->post('model_tipe'),
            'jenis_bbm'          => $this->input->post('jenis_bbm'),
            'kapasitas_max'      => $this->input->post('kapasitas_max'),
            'kapasitas_min'      => $this->input->post('kapasitas_min'),
            'tekanan_max'        => $this->input->post('tekanan_max'),
            'suhu_min'           => $this->input->post('suhu_min'),
            'suhu_max'           => $this->input->post('suhu_max'),
            'status'             => $status,
            'sah_batal'         => ($status !== 'Belum Ditera') ? $this->input->post('sah_batal') : '-',
        ];

        $this->model_nozzle->add($data);
        redirect('tata_usaha/nozzle');
    }

    public function update() {
        $this->form_validation->set_rules('spbu_id', 'SPBU_ID', 'required|integer');
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('nomor_seri', 'Nomor_Seri', 'required');
        $this->form_validation->set_rules('tahun_pembuatan', 'Tahun_Pembuatan', 'required');
        $this->form_validation->set_rules('model_tipe', 'Model_Tipe', 'required');
        $this->form_validation->set_rules('jenis_bbm', 'Jenis_BBM', 'required');
        $this->form_validation->set_rules('kapasitas_max', 'Kapasitas_Max', 'required');
        $this->form_validation->set_rules('kapasitas_min', 'Kapasitas_Min', 'required');
        $this->form_validation->set_rules('tekanan_max', 'Tekanan_Max', 'required');
        $this->form_validation->set_rules('suhu_min', 'Suhu_Min', 'required');
        $this->form_validation->set_rules('suhu_max', 'Suhu_Max', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');

        $status = $this->input->post('status');
        if ($status != 'Belum Ditera') {
            $this->form_validation->set_rules('sah_batal', 'Sah_Batal', 'required'); }

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/nozzle');
            return;
            }
        
        $id = $this->input->post('id');
        $status = $this->input->post('status');
        $data = [
            'spbu_id'          => $this->input->post('spbu_id'),
            'merek'            => $this->input->post('merek'),
            'nomor_seri'       => $this->input->post('nomor_seri'),
            'tahun_pembuatan'  => $this->input->post('tahun_pembuatan'),
            'model_tipe'       => $this->input->post('model_tipe'),
            'jenis_bbm'        => $this->input->post('jenis_bbm'),
            'kapasitas_max'    => $this->input->post('kapasitas_max'),
            'kapasitas_min'    => $this->input->post('kapasitas_min'),
            'tekanan_max'      => $this->input->post('tekanan_max'),
            'suhu_max'         => $this->input->post('suhu_max'),
            'suhu_min'         => $this->input->post('suhu_min'),
            'status'            => $status,
            'sah_batal'         => ($status !== 'Belum Ditera') ? $this->input->post('sah_batal') : '-',
            ];

        $this->model_nozzle->update($id, $data);
        redirect('tata_usaha/nozzle');
        }
    
    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $this->model_nozzle->delete($id);
        redirect('tata_usaha/nozzle');
    }

}

    
