<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_pegawai extends CI_Model {
    public function add($data) {
        return $this->db->insert('m_pegawai', $data);
    }

    public function read() {
        return $this->db->get('m_pegawai');
    }
    
    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('m_pegawai', $data);
    }
    
    public function delete($id) {
        return $this->db->delete('m_pegawai', ['id' => $id]);
    }

    public function get_by_id($id) {
        return $this->db->get_where('m_pegawai', ['id' => $id])->row();
    }

    public function get_by_ids($ids) {
        return $this->db
            ->where_in('id', $ids)
            ->get('m_pegawai')
            ->result();
    }

    public function count() {
        return $this->db->count_all('m_pegawai');
    }
}