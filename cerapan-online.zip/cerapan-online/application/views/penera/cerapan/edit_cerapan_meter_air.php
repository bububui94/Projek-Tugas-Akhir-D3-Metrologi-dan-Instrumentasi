<div class="container-fluid text-dark">
    <div class="content-wrapper">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h2 class="h3 mb-0 text-primary"><strong>Edit Cerapan Meter Air (<?= $cerapan->tera_tera_ulang ?>)</strong></h2>
        </div>

        <section class="content">
            <?= form_open('penera/cerapan_meter_air/update/' . $cerapan->id); ?>
            <table class="table-sm text-center">
                <tr>
                    <td class="col-sm-3"></td>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-1"></td>
                </tr>
                <tr>
                    <th>Perusahaan Pemilik</th>
                    <th>Kelas</th>
                    <th>Nomor Seri</th>
                    <th>Q₁ (m³/h)</th>
                    <th>Q₂ (m³/h)</th>
                    <th>Q₃ (m³/h)</th>
                    <th>Q₄ (m³/h)</th>
                </tr>
                <tr>
                    <td>
                        <p><?= $cerapan->nama_pt ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->kelas ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->nomor_seri ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->laju_alir_minimum ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->laju_alir_transisi ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->laju_alir_nominal ?></p>
                    </td>
                    <td>
                        <p><?= $cerapan->laju_alir_maksimum ?></p>
                    </td>
                </tr>
                <tr>
                    <th colspan="2">Laju Alir</th>
                    <th>Jenis Cairan Uji</th>
                    <th>Q₁ (L/min)</th>
                    <th>Q₂ (L/min)</th>
                    <th>Q₃ (L/min)</th>
                    <th>Q₄ (L/min)</th>
                </tr>
                <tr>
                    <td colspan="2">
                        <div class="form-group">
                            <select class="form-control" name="laju_alir_uji">
                                <option value="">-- Pilih Laju Alir Uji --</option>
                                <option value="q1_cerapan">Laju Alir Minimum (Q₁)</option>
                                <option value="q2_cerapan">Laju Alir Transisi (Q₂)</option>
                                <option value="q3_cerapan">Laju Alir Nominal (Q₃)</option>
                            </select>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="text" value="<?= $cerapan->jenis_cairan ?>" name="jenis_cairan" class="form-control" required>
                        </div>
                    </td>
                    <td>
                        <p><?= number_format($cerapan->laju_alir_minimum * 1000 / 60, 2) ?></p>
                    </td>
                    <td>
                        <p><?= number_format($cerapan->laju_alir_transisi * 1000 / 60, 2) ?></p>
                    </td>
                    <td>
                        <p><?= number_format($cerapan->laju_alir_nominal * 1000 / 60, 2) ?></p>
                    </td>
                    <td>
                        <p><?= number_format($cerapan->laju_alir_maksimum * 1000 / 60, 2) ?></p>
                    </td>
                </tr>
            </table>

            <table class="table-sm table-hover" id="q1_cerapan" style="display: none;">
                <tr>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-3"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                </tr>
                <tr class="text-center">
                    <th colspan="2">Standar untuk Q₁</th>
                    <th>Tipe</th>
                    <th>Kelas</th>
                    <th>Koreksi</th>
                    <th>Waktu Tetes</th>
                </tr>
                <tr class="text-center">
                    <td colspan="2">
                        <div class="form-group">
                            <select class="form-control text-center" name="q1_standar" id="q1_standar">
                                <option value="">-- Pilih Standar --</option>
                                <?php foreach ($standar as $std) : ?>
                                    <option value="<?= $std->id ?>" <?= $cerapan->q1_standar == $std->id ? 'selected' : '' ?>><?= $std->merek_bus ?> <?= $std->kapasitas ?>L ( <?= $std->nomor_seri_bus ?> )</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </td>
                    <td>
                        <p id="q1_tipe_bus"></p>
                    </td>
                    <td>
                        <p id="q1_kelas_bus"></p>
                    </td>
                    <td>
                        <p id="q1_koreksi_bus"></p>
                    </td>
                    <td>
                        <p id="q1_waktu_tetes"></p>
                    </td>
                </tr>
                <tr class="text-center">
                    <th rowspan="2"><strong>No.</strong></th>
                    <th rowspan="2"><strong>Uraian</strong></th>
                    <th rowspan="2"><strong>Satuan</strong></th>
                    <th colspan="3"><strong>Pengujian Q₁</strong></th>
                </tr>
                <tr class="text-center">
                    <th>
                        <p><strong>Ke-1</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-2</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-3</strong></p>
                    </th>
                </tr>
                <tr>
                    <td></td>
                    <td colspan="2">
                        <p><strong>Bejana Ukur Standar</strong></p>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>1.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vb1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb1_r1 ?>" name="q1_vb1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb1_r2 ?>" name="q1_vb1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb1_r3 ?>" name="q1_vb1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>2.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vb2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb2_r1 ?>" name="q1_vb2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb2_r2 ?>" name="q1_vb2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vb2_r3 ?>" name="q1_vb2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>3.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vb)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vb_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vb_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vb_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <p><strong>Meter Air</strong></p>
                    </td>
                    <td colspan="4"></td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>4.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vm1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm1_r1 ?>" name="q1_vm1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm1_r2 ?>" name="q1_vm1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm1_r3 ?>" name="q1_vm1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>5.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vm2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm2_r1 ?>" name="q1_vm2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm2_r2 ?>" name="q1_vm2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_vm2_r3 ?>" name="q1_vm2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>6.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vm)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vm_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vm_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_vm_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>7.</p>
                    </td>
                    <td>
                        <p>Suhu (Tm)</p>
                    </td>
                    <td class="text-center">
                        <p>°C</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_tm_r1 ?>" name="q1_tm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_tm_r2 ?>" name="q1_tm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_tm_r3 ?>" name="q1_tm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>8.</p>
                    </td>
                    <td>
                        <p>Tekanan (Pm)</p>
                    </td>
                    <td class="text-center">
                        <p>kPa</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_pm_r1 ?>" name="q1_pm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_pm_r2 ?>" name="q1_pm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_pm_r3 ?>" name="q1_pm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>9.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Meter Air</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_error_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_error_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q1_error_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>10.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Rata-Rata</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q1_average_error" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>11.</p>
                    </td>
                    <td>
                        <p>Batas Kesalahan yang Diizinkan (BKD) <span class="info-trigger"><i class="fas fa-info-circle"></i></span></p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q1_bkd ?>" name="q1_bkd" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>12.</p>
                    </td>
                    <td>
                        <p>Ketidaktetapan (Repeatability)</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q1_repeat" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <?php if ($cerapan->diameter == 15 && in_array($cerapan->laju_alir_nominal, [1, 1.6, 2.5])) : ?>
                    <tr>
                        <td class="text-center">
                            <p>13.</p>
                        </td>
                        <td>
                            <p>Kepekaan (Khusus DN = 15 mm)</p>
                        </td>
                        <td class="text-center">
                            <p>L/min</p>
                        </td>
                        <td colspan="3">
                            <div class="form-group">
                                <input type="number" step="any" value="<?= $cerapan->q1_sensitivity ?>" name="q1_sensitivity" class="form-control">
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td colspan="3" class="text-center">
                        <p><strong>Keterangan:</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <textarea name="q1_keterangan" class="form-control"><?= !empty($cerapan->q1_keterangan) ? $cerapan->q1_keterangan : '-'; ?></textarea>
                        </div>
                    </td>
                </tr>
                <tr class="text-center">
                    <td colspan="3">
                        <p><strong>Hasil Pengujian</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="text" name="q1_sah_batal" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
            </table>

            <table class="table-sm table-hover" id="q2_cerapan" style="display: none;">
                <tr>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-3"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                </tr>
                <tr class="text-center">
                    <th colspan="2">Standar untuk Q₂</th>
                    <th>Tipe</th>
                    <th>Kelas</th>
                    <th>Koreksi</th>
                    <th>Waktu Tetes</th>
                </tr>
                <tr class="text-center">
                    <td colspan="2">
                        <div class="form-group">
                            <select class="form-control text-center" name="q2_standar" id="q2_standar">
                                <option value="">-- Pilih Standar --</option>
                                <?php foreach ($standar as $std) : ?>
                                    <option value="<?= $std->id ?>" <?= $cerapan->q2_standar == $std->id ? 'selected' : '' ?>><?= $std->merek_bus ?> <?= $std->kapasitas ?>L ( <?= $std->nomor_seri_bus ?> )</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </td>
                    <td>
                        <p id="q2_tipe_bus"></p>
                    </td>
                    <td>
                        <p id="q2_kelas_bus"></p>
                    </td>
                    <td>
                        <p id="q2_koreksi_bus"></p>
                    </td>
                    <td>
                        <p id="q2_waktu_tetes"></p>
                    </td>
                </tr>
                <tr class="text-center">
                    <th rowspan="2"><strong>No.</strong></th>
                    <th rowspan="2"><strong>Uraian</strong></th>
                    <th rowspan="2"><strong>Satuan</strong></th>
                    <th colspan="3"><strong>Pengujian Q₂</strong></th>
                </tr>
                <tr class="text-center">
                    <th>
                        <p><strong>Ke-1</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-2</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-3</strong></p>
                    </th>
                </tr>
                <tr>
                    <td></td>
                    <td colspan="2">
                        <p><strong>Bejana Ukur Standar</strong></p>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>1.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vb1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb1_r1 ?>" name="q2_vb1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb1_r2 ?>" name="q2_vb1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb1_r3 ?>" name="q2_vb1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>2.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vb2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb2_r1 ?>" name="q2_vb2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb2_r2 ?>" name="q2_vb2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vb2_r3 ?>" name="q2_vb2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>3.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vb)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vb_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vb_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vb_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <p><strong>Meter Air</strong></p>
                    </td>
                    <td colspan="4"></td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>4.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vm1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm1_r1 ?>" name="q2_vm1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm1_r2 ?>" name="q2_vm1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm1_r3 ?>" name="q2_vm1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>5.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vm2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm2_r1 ?>" name="q2_vm2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm2_r2 ?>" name="q2_vm2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_vm2_r3 ?>" name="q2_vm2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>6.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vm)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vm_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vm_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_vm_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>7.</p>
                    </td>
                    <td>
                        <p>Suhu (Tm)</p>
                    </td>
                    <td class="text-center">
                        <p>°C</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_tm_r1 ?>" name="q2_tm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_tm_r2 ?>" name="q2_tm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_tm_r3 ?>" name="q2_tm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>8.</p>
                    </td>
                    <td>
                        <p>Tekanan (Pm)</p>
                    </td>
                    <td class="text-center">
                        <p>kPa</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_pm_r1 ?>" name="q2_pm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_pm_r2 ?>" name="q2_pm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_pm_r3 ?>" name="q2_pm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>9.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Meter Air</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_error_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_error_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q2_error_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>10.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Rata-Rata</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q2_average_error" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>11.</p>
                    </td>
                    <td>
                        <p>Batas Kesalahan yang Diizinkan (BKD) <span class="info-trigger"><i class="fas fa-info-circle"></i></span></p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q2_bkd ?>" name="q2_bkd" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>12.</p>
                    </td>
                    <td>
                        <p>Ketidaktetapan (Repeatability)</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q2_repeat" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" class="text-center">
                        <p><strong>Keterangan:</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <textarea name="q2_keterangan" class="form-control"><?= !empty($cerapan->q2_keterangan) ? $cerapan->q2_keterangan : '-'; ?></textarea>
                        </div>
                    </td>
                </tr>
                <tr class="text-center">
                    <td colspan="3">
                        <p><strong>Hasil Pengujian</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="text" name="q2_sah_batal" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
            </table>

            <table class="table-sm table-hover" id="q3_cerapan" style="display: none;">
                <tr>
                    <td class="col-sm-1"></td>
                    <td class="col-sm-3"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                    <td class="col-sm-2"></td>
                </tr>
                <tr class="text-center">
                    <th colspan="2">Standar untuk Q₃</th>
                    <th>Tipe</th>
                    <th>Kelas</th>
                    <th>Koreksi</th>
                    <th>Waktu Tetes</th>
                </tr>
                <tr class="text-center">
                    <td colspan="2">
                        <div class="form-group">
                            <select class="form-control text-center" name="q3_standar" id="q3_standar">
                                <option value="">-- Pilih Standar --</option>
                                <?php foreach ($standar as $std) : ?>
                                    <option value="<?= $std->id ?>" <?= $cerapan->q3_standar == $std->id ? 'selected' : '' ?>><?= $std->merek_bus ?> <?= $std->kapasitas ?>L ( <?= $std->nomor_seri_bus ?> )</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </td>
                    <td>
                        <p id="q3_tipe_bus"></p>
                    </td>
                    <td>
                        <p id="q3_kelas_bus"></p>
                    </td>
                    <td>
                        <p id="q3_koreksi_bus"></p>
                    </td>
                    <td>
                        <p id="q3_waktu_tetes"></p>
                    </td>
                </tr>
                <tr class="text-center">
                    <th rowspan="2"><strong>No.</strong></th>
                    <th rowspan="2"><strong>Uraian</strong></th>
                    <th rowspan="2"><strong>Satuan</strong></th>
                    <th colspan="3"><strong>Pengujian Q₃</strong></th>
                </tr>
                <tr class="text-center">
                    <th>
                        <p><strong>Ke-1</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-2</strong></p>
                    </th>
                    <th>
                        <p><strong>Ke-3</strong></p>
                    </th>
                </tr>
                <tr>
                    <td></td>
                    <td colspan="2">
                        <p><strong>Bejana Ukur Standar</strong></p>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>1.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vb1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb1_r1 ?>" name="q3_vb1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb1_r2 ?>" name="q3_vb1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb1_r3 ?>" name="q3_vb1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>2.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vb2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb2_r1 ?>" name="q3_vb2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb2_r2 ?>" name="q3_vb2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vb2_r3 ?>" name="q3_vb2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>3.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vb)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vb_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vb_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vb_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <p><strong>Meter Air</strong></p>
                    </td>
                    <td colspan="4"></td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>4.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Awal (Vm1)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm1_r1 ?>" name="q3_vm1_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm1_r2 ?>" name="q3_vm1_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm1_r3 ?>" name="q3_vm1_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>5.</p>
                    </td>
                    <td>
                        <p>Pembacaaan Akhir (Vm2)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm2_r1 ?>" name="q3_vm2_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm2_r2 ?>" name="q3_vm2_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_vm2_r3 ?>" name="q3_vm2_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>6.</p>
                    </td>
                    <td>
                        <p>Volume yang Diukur (Vm)</p>
                    </td>
                    <td class="text-center">
                        <p>L</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vm_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vm_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_vm_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>7.</p>
                    </td>
                    <td>
                        <p>Suhu (Tm)</p>
                    </td>
                    <td class="text-center">
                        <p>°C</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_tm_r1 ?>" name="q3_tm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_tm_r2 ?>" name="q3_tm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_tm_r3 ?>" name="q3_tm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>8.</p>
                    </td>
                    <td>
                        <p>Tekanan (Pm)</p>
                    </td>
                    <td class="text-center">
                        <p>kPa</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_pm_r1 ?>" name="q3_pm_r1" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_pm_r2 ?>" name="q3_pm_r2" class="form-control">
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_pm_r3 ?>" name="q3_pm_r3" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>9.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Meter Air</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_error_r1" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_error_r2" class="form-control" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input type="number" step="any" name="q3_error_r3" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>10.</p>
                    </td>
                    <td>
                        <p>Kesalahan Penunjukan Rata-Rata</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q3_average_error" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>11.</p>
                    </td>
                    <td>
                        <p>Batas Kesalahan yang Diizinkan (BKD) <span class="info-trigger"><i class="fas fa-info-circle"></i></span></p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" value="<?= $cerapan->q3_bkd ?>" name="q3_bkd" class="form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <p>12.</p>
                    </td>
                    <td>
                        <p>Ketidaktetapan (Repeatability)</p>
                    </td>
                    <td class="text-center">
                        <p>%</p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="number" step="any" name="q3_repeat" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" class="text-center">
                        <p><strong>Keterangan:</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <textarea name="q3_keterangan" class="form-control"><?= !empty($cerapan->q3_keterangan) ? $cerapan->q3_keterangan : '-'; ?></textarea>
                        </div>
                    </td>
                </tr>
                <tr class="text-center">
                    <td colspan="3">
                        <p><strong>Hasil Pengujian</strong></p>
                    </td>
                    <td colspan="3">
                        <div class="form-group">
                            <input type="text" name="q3_sah_batal" class="form-control" readonly>
                        </div>
                    </td>
                </tr>
            </table>
            <div class="text-right m-3">
                <button type="button" class="btn btn-secondary mr-3" onclick="if(confirm('Apakah kamu yakin untuk membatalkan perubahan dan menutup tab ini?')) window.close()">Cancel</button>
                <?php if ($cerapan->status_kirim == 0) : ?>
                    <button type="submit" class="btn btn-primary">Update</button>
                <?php else : ?>
                    <button type="button" class="btn btn-secondary" onclick="alert('Data sudah dikirim, tidak bisa di update')">Update</button>
                <?php endif; ?>
            </div>
            <?= form_close(); ?>
        </section>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
                <p class="text-danger">Data yang sedang diedit tidak akan tersimpan</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<div id="info-popup" class="info-popup">
    <?php if($cerapan->tera_tera_ulang == 'Tera') : ?>
    <strong>BKD untuk Tera</strong>
    <table>
        <tr>
            <th class="col-20">Kelas</th>
            <th class="col-25">Laju Alir</th>
            <th class="col-35">Suhu</th>
            <th class="col-20">BKD</th>
        </tr>
        <tr>
            <th class="no-top-border">Akurasi</th>
            <th class="no-top-border">(m³/h)</th>
            <th class="no-top-border">(°C)</th>
            <th class="no-top-border">(%)</th>
        </tr>
        <tr>
            <td rowspan="3">1</td>
            <td rowspan="2">Q₂ ≤ Q ≤ Q₄</td>
            <td>0.1 s.d. 30</td>
            <td>± 1</td>
        </tr>
        <tr>
            <td>> 30</td>
            <td>± 2</td>
        </tr>
        <tr>
            <td>Q₁ ≤ Q < Q₂</td>
            <td>Tidak Tergantung</td>
            <td>± 3</td>
        </tr>
        <tr>
            <td rowspan="3">2</td>
            <td rowspan="2">Q₂ ≤ Q ≤ Q₄</td>
            <td>0.1 s.d. 30</td>
            <td>± 2</td>
        </tr>
        <tr>
            <td>> 30</td>
            <td>± 3</td>
        </tr>
        <tr>
            <td>Q₁ ≤ Q < Q₂</td>
            <td>Tidak Tergantung</td>
            <td>± 5</td>
        </tr>
    </table>
    <?php else : ?>
    <strong>BKD untuk Tera Ulang</strong>
    <table>
        <tr>
            <th class="col-20">Kelas</th>
            <th class="col-25">Laju Alir</th>
            <th class="col-35">Suhu</th>
            <th class="col-20">BKD</th>
        </tr>
        <tr>
            <th class="no-top-border">Akurasi</th>
            <th class="no-top-border">(m³/h)</th>
            <th class="no-top-border">(°C)</th>
            <th class="no-top-border">(%)</th>
        </tr>
        <tr>
            <td rowspan="3">1</td>
            <td rowspan="2">Q₂ ≤ Q ≤ Q₄</td>
            <td>0.1 s.d. 30</td>
            <td>± 2</td>
        </tr>
        <tr>
            <td>> 30</td>
            <td>± 4</td>
        </tr>
        <tr>
            <td>Q₁ ≤ Q < Q₂</td>
            <td>Tidak Tergantung</td>
            <td>± 6</td>
        </tr>
        <tr>
            <td rowspan="3">2</td>
            <td rowspan="2">Q₂ ≤ Q ≤ Q₄</td>
            <td>0.1 s.d. 30</td>
            <td>± 4</td>
        </tr>
        <tr>
            <td>> 30</td>
            <td>± 6</td>
        </tr>
        <tr>
            <td>Q₁ ≤ Q < Q₂</td>
            <td>Tidak Tergantung</td>
            <td>± 10</td>
        </tr>
    </table>
    <?php endif; ?>
</div>

<style>
    .info-popup {
        display: none;
        position: absolute;
        background: #fff;
        border: 1px solid #ccc;
        padding: 10px;
        z-index: 9999;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        font-size: 10pt;
        max-width: 400px;
    }

    .info-popup table {
        margin-top: 5px;
        font-size: 9pt;
        width: 100%;
        border-collapse: collapse;
    }

    .info-popup th, .info-popup td {
        padding: 2px 4px;
        border: 1px solid black;
        text-align: center;
    }

    .info-popup th.col-20 {
        width: 20%;
        border-bottom: none;
        padding-bottom: 0;
    }

    .info-popup th.col-25 {
        width: 25%;
        border-bottom: none;
        padding-bottom: 0;
    }

    .info-popup th.col-35 {
        width: 35%;
        border-bottom: none;
        padding-bottom: 0;
    }

    .info-popup th.no-top-border {
        border-top: none;
        padding-top: 0;
    }

    .info-trigger {
        cursor: pointer;
        color: #007bff;
        font-weight: bold;
        margin-left: 4px;
    }
</style>

<script>
    $(document).ready(function() {
        $('.info-trigger').on('click', function(e) {
            e.stopPropagation();

            const icon = $(this);
            const popup = $('#info-popup');
            const offset = icon.offset();

            popup.css({
                top: offset.top + icon.outerHeight() + 5,
                left: offset.left,
            }).fadeIn(150);
        });

        // Hide popup on outside click
        $(document).on('click', function() {
            $('#info-popup').fadeOut(100);
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const prefixes = ['q1_', 'q2_', 'q3_'];
        const standarData = <?= json_encode($standar) ?>;
        const lajuAlirMinimum = <?= isset($cerapan->laju_alir_minimum) ? $cerapan->laju_alir_minimum : 0 ?>;

        // Show/hide tables based on laju_alir_uji
        const flowSelector = document.querySelector('select[name="laju_alir_uji"]');
        const tableIds = ['q1_cerapan', 'q2_cerapan', 'q3_cerapan'];
        if (flowSelector) {
            flowSelector.addEventListener('change', function() {
                tableIds.forEach(id => {
                    const table = document.getElementById(id);
                    if (table) {
                        table.style.display = (this.value === id) ? 'table' : 'none';
                    }
                });
            });
        }

        prefixes.forEach(prefix => {
            let koreksiBus = 0;
            const select = document.getElementById(prefix + 'standar');
            if (select) {
                select.addEventListener('change', function() {
                    const selected = standarData.find(std => std.id == this.value);
                    koreksiBus = selected ? parseFloat(selected.koreksi_bus) || 0 : 0;

                    const fields = {
                        tipe_bus: selected?.tipe_bus || '-',
                        kelas_bus: selected?.kelas_bus || '-',
                        koreksi_bus: selected?.koreksi_bus || '-',
                        waktu_tetes: selected?.waktu_tetes || '-'
                    };

                    Object.keys(fields).forEach(field => {
                        const el = document.getElementById(prefix + field);
                        if (el) el.textContent = fields[field];
                    });

                    calcVb();
                });

                if (select.value) {
                    select.dispatchEvent(new Event('change'));
                }
            }

            // VB Calculation
            const vb1 = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vb1_r' + i)[0]);
            const vb2 = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vb2_r' + i)[0]);
            const vbRes = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vb_r' + i)[0]);

            const getDecimals = v => (String(v).split('.')[1] || '').length;

            function calcVb() {
                for (let i = 0; i < 3; i++) {
                    const v1 = parseFloat(vb1[i]?.value) || 0;
                    const v2 = parseFloat(vb2[i]?.value) || 0;
                    const maxDec = Math.max(getDecimals(v1), getDecimals(v2), getDecimals(koreksiBus));
                    vbRes[i].value = (v2 - v1 + koreksiBus).toFixed(maxDec);
                }
                calcError();
            }

            [...vb1, ...vb2].forEach(input => input?.addEventListener('input', calcVb));

            // VM Calculation
            const vm1 = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vm1_r' + i)[0]);
            const vm2 = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vm2_r' + i)[0]);
            const vmRes = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vm_r' + i)[0]);

            function calcVm() {
                for (let i = 0; i < 3; i++) {
                    const v1 = parseFloat(vm1[i]?.value) || 0;
                    const v2 = parseFloat(vm2[i]?.value) || 0;
                    const maxDec = Math.max(getDecimals(v1), getDecimals(v2));
                    vmRes[i].value = (v2 - v1).toFixed(maxDec);
                }
                calcError();
            }

            [...vm1, ...vm2].forEach(input => input?.addEventListener('input', calcVm));

            // Error & Repeatability
            const vm = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vm_r' + i)[0]);
            const vb = [1, 2, 3].map(i => document.getElementsByName(prefix + 'vb_r' + i)[0]);
            const error = [1, 2, 3].map(i => document.getElementsByName(prefix + 'error_r' + i)[0]);
            const avg = document.getElementsByName(prefix + 'average_error')[0];
            const repeat = document.getElementsByName(prefix + 'repeat')[0];

            function calcError() {
                let errs = [],
                    sum = 0;
                for (let i = 0; i < 3; i++) {
                    const vVm = parseFloat(vm[i]?.value) || 0;
                    const vVb = parseFloat(vb[i]?.value) || 0;
                    if (vVb !== 0) {
                        const e = ((vVm - vVb) / vVb) * 100;
                        error[i].value = e.toFixed(2);
                        errs.push(e);
                        sum += e;
                    } else {
                        error[i].value = '';
                    }
                }
                avg.value = errs.length ? (sum / errs.length).toFixed(2) : '';
                repeat.value = errs.length ? (Math.max(...errs) - Math.min(...errs)).toFixed(2) : '';
                checkResult();
            }

            [...vm, ...vb].forEach(input => input?.addEventListener('input', calcError));

            // SAH / BATAL Check
            const bkd = document.getElementsByName(prefix + 'bkd')[0];
            const result = document.getElementsByName(prefix + 'sah_batal')[0];
            const sensitivity = prefix === 'q1_' ? document.getElementsByName(prefix + 'sensitivity')[0] : null;

            function checkResult() {
                const avgVal = parseFloat(avg?.value) || 0;
                const repVal = parseFloat(repeat?.value) || 0;
                const bkdVal = parseFloat(bkd?.value) || 0;
                const sensVal = sensitivity ? parseFloat(sensitivity.value) : null;

                const cond1 = Math.abs(avgVal) <= Math.abs(bkdVal);
                const cond2 = Math.abs(repVal) <= Math.abs(bkdVal / 3);
                const cond3 = sensitivity ? sensVal <= 0.4 * (lajuAlirMinimum * 1000 / 60) : true;

                result.value = (cond1 && cond2 && cond3) ? 'SAH' : 'BATAL';
            }

            [avg, repeat, bkd, sensitivity].forEach(input => input?.addEventListener('input', checkResult));

            // Initial trigger
            calcVb();
            calcVm();
        });
    });
</script>