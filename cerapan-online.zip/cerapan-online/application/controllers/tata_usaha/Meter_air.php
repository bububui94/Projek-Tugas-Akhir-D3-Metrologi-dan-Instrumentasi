<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $this->load->model('tata_usaha/model_pt_meter_air');
        $data ['perusahaan'] = $this->model_pt_meter_air->read()->result();
        $data ['meter_air'] = $this->model_meter_air->read()->result();
        
        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/meter_air/list_meter_air', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('id_perusahaan', 'ID_Perusahaan', 'required|integer');
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('tahun_pembuatan', 'Tahun_Pembuatan', 'required|integer');
        $this->form_validation->set_rules('kelas', 'Kelas', 'required');
        $this->form_validation->set_rules('model_tipe', 'Model_Tipe', 'required');
        $this->form_validation->set_rules('list_nomor_seri', 'List_Nomor_Seri', 'required');
        $this->form_validation->set_rules('diameter', 'Diameter', 'required|numeric|less_than_equal_to[50]');
        $this->form_validation->set_rules('pemasangan', 'Pemasangan', 'required');
        $this->form_validation->set_rules('laju_alir_nominal', 'Laju_Alir_Nominal', 'required|numeric');
        $this->form_validation->set_rules('rasio', 'Rasio', 'required|numeric');
        $this->form_validation->set_rules('suhu_min', 'Suhu_Min', 'required|numeric');
        $this->form_validation->set_rules('suhu_max', 'Suhu_Max', 'required|numeric');
        $this->form_validation->set_rules('tekanan_min', 'Tekanan_Min', 'required|numeric');
        $this->form_validation->set_rules('tekanan_max', 'Tekanan_Max', 'required|numeric');
        $this->form_validation->set_rules('status', 'Status', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/meter_air');
            return;
        }

        $list_nomor_seri = explode("\n", $this->input->post('list_nomor_seri'));
        $list_nomor_seri = array_filter(array_map('trim', $list_nomor_seri));

        foreach ($list_nomor_seri as $nomor_seri) {
            $data = [
                'id_perusahaan'     => $this->input->post('id_perusahaan'),
                'merek'             => $this->input->post('merek'),
                'tahun_pembuatan'   => $this->input->post('tahun_pembuatan'),
                'kelas'             => $this->input->post('kelas'),
                'model_tipe'        => $this->input->post('model_tipe'),
                'nomor_seri'        => $nomor_seri,
                'diameter'          => $this->input->post('diameter'),
                'pemasangan'        => $this->input->post('pemasangan'),
                'laju_alir_nominal' => $this->input->post('laju_alir_nominal'),
                'rasio'             => $this->input->post('rasio'),
                'suhu_min'          => $this->input->post('suhu_min'),
                'suhu_max'          => $this->input->post('suhu_max'),
                'tekanan_min'       => $this->input->post('tekanan_min'),
                'tekanan_max'       => $this->input->post('tekanan_max'),
                'status'            => $this->input->post('status'),
            ];

            $this->model_meter_air->add($data);
        }
        $this->session->set_flashdata('success', 'Meter air baru berhasil ditambahkan');
        redirect('tata_usaha/meter_air');
    }

    public function update() {
        $this->form_validation->set_rules('id_perusahaan', 'ID_Perusahaan', 'required|integer');
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('tahun_pembuatan', 'Tahun_Pembuatan', 'required|integer');
        $this->form_validation->set_rules('kelas', 'Kelas', 'required');
        $this->form_validation->set_rules('model_tipe', 'Model_Tipe', 'required');
        $this->form_validation->set_rules('nomor_seri', 'Nomor_Seri', 'required');
        $this->form_validation->set_rules('diameter', 'Diameter', 'required|numeric|less_than_equal_to[50]');
        $this->form_validation->set_rules('pemasangan', 'Pemasangan', 'required');
        $this->form_validation->set_rules('laju_alir_nominal', 'Laju_Alir_Nominal', 'required|numeric');
        $this->form_validation->set_rules('rasio', 'Rasio', 'required|numeric');
        $this->form_validation->set_rules('suhu_min', 'Suhu_Min', 'required|numeric');
        $this->form_validation->set_rules('suhu_max', 'Suhu_Max', 'required|numeric');
        $this->form_validation->set_rules('tekanan_min', 'Tekanan_Min', 'required|numeric');
        $this->form_validation->set_rules('tekanan_max', 'Tekanan_Max', 'required|numeric');
        $this->form_validation->set_rules('status', 'Status', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/meter_air');
            return;
        }

        $id = $this->input->post('id');
        $data = [
            'id_perusahaan'     => $this->input->post('id_perusahaan'),
            'merek'             => $this->input->post('merek'),
            'tahun_pembuatan'   => $this->input->post('tahun_pembuatan'),
            'kelas'             => $this->input->post('kelas'),
            'model_tipe'        => $this->input->post('model_tipe'),
            'nomor_seri'        => $this->input->post('nomor_seri'),
            'diameter'          => $this->input->post('diameter'),
            'pemasangan'        => $this->input->post('pemasangan'),
            'laju_alir_nominal' => $this->input->post('laju_alir_nominal'),
            'rasio'             => $this->input->post('rasio'),
            'suhu_min'          => $this->input->post('suhu_min'),
            'suhu_max'          => $this->input->post('suhu_max'),
            'tekanan_min'       => $this->input->post('tekanan_min'),
            'tekanan_max'       => $this->input->post('tekanan_max'),
            'status'            => $this->input->post('status'),
        ];

        $this->model_meter_air->update($id, $data);
        $this->session->set_flashdata('success', 'Data meter air berhasil diperbarui');
        redirect('tata_usaha/meter_air');
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $this->model_meter_air->delete($id);
        $this->session->set_flashdata('success', 'Meter air berhasil dihapus');
        redirect('tata_usaha/meter_air');
    }
}