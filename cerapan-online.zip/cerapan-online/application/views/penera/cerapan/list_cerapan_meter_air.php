<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Cerapan Meter Air</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <table class="table box table-sm" id="list_cerapan_meter_air">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-3">NO. SURAT TUGAS</th>
                        <th class="col-3">PERUSAHAAN PEMILIK</th>
                        <th class="col-2">NOMOR SERI</th>
                        <th class="col-2">TANGGAL PELAKSANAAN</th>
                        <th class="col-1 text-center" colspan="2" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($cerapan as $crp) :
                        $is_complete = true;
                        foreach ((array) $crp as $key => $value) {
                            if (is_null($value) || $value === '') {
                                $is_complete = false;
                                break;
                            }
                        }
                    ?>

                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $crp->nomor_st ?></td>
                            <td><?= $crp->nama_pt ?></td>
                            <td><?= $crp->nomor_seri ?></td>
                            <td><?= indo_date($crp->tanggal_pelaksanaan) ?></td>

                            <td>
                                <?php if ($crp->status_kirim == 0) : ?>
                                    <a href="<?= base_url('penera/cerapan_meter_air/edit/' . $crp->id) ?>" target="_blank" class="btn btn-primary btn-sm"> <i class="fas fa-edit"></i></a>
                                <?php else: ?>
                                    <?php $safe_cerapan = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $crp->nomor_seri);
                                    $tahun_tera = date('Y', strtotime($crp->tanggal_pelaksanaan)); ?>
                                    <a href="<?= base_url('assets/cerapan_meter_air/Cerapan Meter Air ' . $safe_cerapan . ' Tahun ' . $tahun_tera . '.pdf') ?>" target="_blank" class="btn btn-warning btn-sm"> <i class="fas fa-download"></i></a>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($crp->status_kirim == 0) : ?>
                                    <button class="btn btn-success btn-sm edit-complete" data-complete="<?= $is_complete ? '1' : '0' ?>" <?php if($is_complete) : ?> data-toggle="modal" data-target="#send_cerapan_meter_air_<?= $crp->id ?>" type="button" <?php endif; ?>><i class="fas fa-paper-plane"></i></button>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        <i class="fas fa-check-circle"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <div class="modal fade" id="send_cerapan_meter_air_<?= $crp->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('penera/cerapan_meter_air/send'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Kirim Cerapan Meter Air</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $crp->id ?>">

                                        <h5>Apakah kamu yakin untuk mengirim cerapan meter air ini?</h5>
                                        <p class="text-danger">Cerapan yang sudah dikirim <strong>tidak dapat diubah!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Send</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.edit-complete').each(function() {
            var isComplete = $(this).data('complete');
            if (isComplete === 0 || isComplete === '0') {
                $(this).prop('', true)
                    .removeClass('btn-success')
                    .addClass('btn-secondary');
            }
        });

        $('.edit-complete').click(function(e) {
            var isComplete = $(this).data('complete');
            if (isComplete === 0 || isComplete === '0') {
                e.preventDefault();
                alert('Semua data cerapan harus terisi terlebih dahulu');
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_cerapan_meter_air').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>