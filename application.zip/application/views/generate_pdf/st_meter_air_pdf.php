<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ST Meter Air <?= $surat_tugas->nomor_st ?></title>

    <link rel="stylesheet" href="<?= base_url('assets/css/st_meter_air_pdf.css') ?>">
</head>

<body>
    <img class="kop-surat" src="<?= base_url('assets/img/Kop_Surat_Akmet.png') ?>" alt="kop_akmet">
    <hr>
    <br>
    <table>
        <tr>
            <td class="col-10"></td>
            <td class="col-5"></td>
            <td class="col-5"></td>
            <td class="col-15"></td>
            <td class="col-5"></td>
            <td></td>
        </tr>
        <tr class="font-size-14 bold center underline">
            <td colspan="6">SURAT TUGAS</td>
        </tr>
        <tr>
            <td colspan="6" class="font-size-10 center">Nomor Surat: <?= $surat_tugas->nomor_st ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>Dasar</td>
            <td>:</td>
            <td colspan="4">Permohonan <?= $surat_tugas->tera_tera_ulang ?> UTTP meter air dari perusahaan <?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr class="center ">
            <td colspan="6">MEMERINTAHKAN</td>
        </tr>
        <tr>
            <td>Kepada</td>
            <td>:</td>
            <td colspan="4">Ketua Pelaksana</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Nama/NIP</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->nama_lengkap ?> / <?= $ketua_pelaksana->nip ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Jabatan</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->jabatan ?></td>
        </tr>
        <?php if ($pendampings) : ?>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="4">Pendamping</td>
        </tr>
        <?php
        $no = 1;
        foreach ($pendampings as $pendamping) : ?>
            <tr>
                <td colspan="2"></td>
                <td><?= $no++ ?>.</td>
                <td>Nama/NIP</td>
                <td>:</td>
                <td><?= $pendamping->nama_lengkap ?> / <?= $pendamping->nip ?></td>
            </tr>
            <tr>
                <td colspan="3"></td>
                <td>Jabatan</td>
                <td>:</td>
                <td><?= $pendamping->jabatan ?></td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>Untuk</td>
            <td>:</td>
            <td colspan="4">Melaksanakan pelayanan <?= $surat_tugas->tera_tera_ulang ?> UTTP meter air</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Perusahaan</td>
            <td>:</td>
            <td><?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Alamat</td>
            <td>:</td>
            <td><?= $perusahaan->alamat ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Tanggal</td>
            <td>:</td>
            <td><?= indo_date($surat_tugas->tanggal_pelaksanaan) ?></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td colspan="2">Jumlah Meter Air</td>
            <td>:</td>
            <td>Terlampir</td>
        </tr>
    </table>
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <table>
        <tr>
            <td class="col-60"></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td class="center">Dibuat di Sumedang</td>
        </tr>
        <tr>
            <td></td>
            <td class="center">pada tanggal <?= indo_date($surat_tugas->tanggal_pembuatan) ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="center">Kepala UML,</td>
        </tr>
        <tr>
            <td></td>
            <td class="center"><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Rijal.jpg') ?>" alt="ttd"></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold center underline"><?= $kepala_uml->nama_lengkap ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="center"><?= $kepala_uml->jabatan ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="center">NIP. <?= $kepala_uml->nip ?></td>
        </tr>
    </table>

    <div class="page-break"></div>

    <h4>Lampiran</h4>
    <br class="spacing-2">
    <table class="table-bordered">
        <thead>
            <tr class="bold">
                <th class="col-5">No.</th>
                <th class="col-15">Merek</th>
                <th class="col-20">Model/Tipe</th>
                <th class="col-20">No. Seri</th>
                <th class="col-10">Q<sub>1</sub> (m³/h)</th>
                <th class="col-10">Q<sub>2</sub> (m³/h)</th>
                <th class="col-10">Q<sub>3</sub> (m³/h)</th>
                <th class="col-10">Q<sub>4</sub> (m³/h)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($list_meter_air as $meter_air) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $meter_air->merek ?></td>
                    <td><?= $meter_air->model_tipe ?></td>
                    <td><?= $meter_air->nomor_seri ?></td>
                    <td><?= $meter_air->laju_alir_minimum ?></td>
                    <td><?= $meter_air->laju_alir_transisi ?></td>
                    <td><?= $meter_air->laju_alir_nominal ?></td>
                    <td><?= $meter_air->laju_alir_maksimum ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>