<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Meter Air</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <div>
                <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_meter_air"><i class="fa fa-plus"></i> Tambah Meter Air</button>
            </div>

            <table class="table box table-sm" id="list_meter_air">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-2">PERUSAHAAN PEMILIK</th>
                        <th class="col-2">MEREK</th>
                        <th class="col-2">MODEL / TIPE</th>
                        <th class="col-2">NO. SERI</th>
                        <th class="col-2">STATUS</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($meter_air as $ma) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $ma->nama_pt ?></td>
                            <td><?= $ma->merek ?></td>
                            <td><?= $ma->model_tipe ?></td>
                            <td><?= $ma->nomor_seri ?></td>
                            <td><?= $ma->status ?></td>

                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_meter_air_<?= $ma->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_meter_air_<?= $ma->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_meter_air_<?= $ma->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <div class="modal fade" id="detail_meter_air_<?= $ma->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail Meter Air</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Perusahaan Pemilik:</strong> <?= $ma->nama_pt ?></p>
                                        <p><strong>Merek:</strong> <?= $ma->merek ?></p>
                                        <p><strong>Tahun Pembuatan:</strong> <?= $ma->tahun_pembuatan ?></p>
                                        <p><strong>Kelas:</strong> <?= $ma->kelas ?></p>
                                        <p><strong>Model / Tipe:</strong> <?= $ma->model_tipe ?></p>
                                        <p><strong>Nomor Seri:</strong> <?= $ma->nomor_seri ?></p>
                                        <p><strong>Diameter Dalam (DN):</strong> <?= $ma->diameter ?> mm</p>
                                        <p><strong>Tipe Pemasangan Meter Air:</strong> <?= $ma->pemasangan ?></p>
                                        <p><strong>Laju Alir Nominal (Q₃):</strong> <?= $ma->laju_alir_nominal ?> m³/h</p>
                                        <p><strong>Rasio (Q₃ / Q₁):</strong> <?= $ma->rasio ?></p>
                                        <p><strong>Laju Alir Minimum (Q₁):</strong> <?= $ma->laju_alir_minimum ?> m³/h</p>
                                        <p><strong>Laju Alir Transisi (Q₂):</strong> <?= $ma->laju_alir_transisi ?> m³/h</p>
                                        <p><strong>Laju Alir Maksimum (Q₄):</strong> <?= $ma->laju_alir_maksimum ?> m³/h</p>
                                        <p><strong>Suhu Minimum:</strong> <?= $ma->suhu_min ?> °C</p>
                                        <p><strong>Suhu Maksimum:</strong> <?= $ma->suhu_max ?> °C</p>
                                        <p><strong>Tekanan Minimum:</strong> <?= $ma->tekanan_min ?> kPa</p>
                                        <p><strong>Tekanan Maksimum:</strong> <?= $ma->tekanan_max ?> kPa</p>
                                        <p><strong>Status:</strong> <?= $ma->status ?></p>
                                        <?php if ($ma->status == 'Sudah Ditera' || $ma->status == 'Sudah Ditera Ulang') : ?>
                                            <p><strong>Sah / Batal:</strong> <?= $ma->sah_batal == 'SAH' ? '<span class="badge badge-success">SAH</span>' : '<span class="badge badge-danger">BATAL</span>' ?></p>
                                        <?php endif ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="edit_meter_air_<?= $ma->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/meter_air/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Edit Meter Air</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $ma->id ?>">

                                        <div class="form-group">
                                            <label for="id_perusahaan">Perusahaan Pemilik Meter Air</label>
                                            <select name="id_perusahaan" class="form-control" required>
                                                <option value="">-- Pilih Perusahaan --</option>
                                                <?php foreach ($perusahaan as $pt): ?>
                                                    <option value="<?= $pt->id ?>" <?= $ma->id_perusahaan == $pt->id ? 'selected' : '' ?>><?= $pt->nama_pt ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-7">
                                                <label>Merek</label>
                                                <input type="text" name="merek" class="form-control" value="<?= $ma->merek ?>" required>
                                            </div>
                                            <div class="col-sm-5">
                                                <label for="kelas">Kelas Meter Air</label>
                                                <select class="form-control" name="kelas" required>
                                                    <option value="">-- Pilih Kelas --</option>
                                                    <option value="1" <?= $ma->kelas == '1' ? 'selected' : '' ?>>1 (Satu)</option>
                                                    <option value="2" <?= $ma->kelas == '2' ? 'selected' : '' ?>>2 (Dua)</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <label>Tahun Pembuatan</label>
                                                <input type="number" name="tahun_pembuatan" class="form-control" value="<?= $ma->tahun_pembuatan ?>" required>
                                            </div>
                                            <div class="col-sm-8">
                                                <label>Model / Tipe</label>
                                                <input type="text" name="model_tipe" class="form-control" value="<?= $ma->model_tipe ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Seri</label>
                                            <input type="text" name="nomor_seri" class="form-control" value="<?= $ma->nomor_seri ?>" required>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-5">
                                                <label>Diameter Dalam (DN)</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="diameter" step="any" name="diameter" value="<?= $ma->diameter ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">mm</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-7">
                                                <label for="pemasangan">Tipe Pemasangan Meter Air</label>
                                                <select class="form-control" name="pemasangan" required>
                                                    <option value="">-- Pilih --</option>
                                                    <option value="Vertikal" <?= $ma->pemasangan == 'Vertikal' ? 'selected' : '' ?>>Vertikal</option>
                                                    <option value="Horizontal" <?= $ma->pemasangan == 'Horizontal' ? 'selected' : '' ?>>Horizontal</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-8">
                                                <label>Laju Alir Nominal (Q₃)</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="laju_alir_nominal" value="<?= $ma->laju_alir_nominal ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">m³/h</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Rasio (Q₃ / Q₁)</label>
                                                <input type="number" step="any" name="rasio" class="form-control" value="<?= $ma->rasio ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label>Suhu Minimum</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="suhu_min" value="<?= $ma->suhu_min ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">°C</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Suhu Maksimum</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="suhu_max" value="<?= $ma->suhu_max ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">°C</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label>Tekanan Minimum</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="tekanan_min" value="<?= $ma->tekanan_min ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">kPa</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Tekanan Maksimum</label>
                                                <div class="input-group">
                                                    <input class="form-control" type="number" step="any" name="tekanan_max" value="<?= $ma->tekanan_max ?>" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">kPa</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select class="form-control status" name="status" required>
                                                <option value="">-- Pilih Status --</option>
                                                <?php if ($ma->status == 'Belum Ditera') : ?>
                                                    <option value="Belum Ditera" <?= $ma->status == 'Belum Ditera' ? 'selected' : '' ?>>Belum Ditera</option>
                                                <?php endif; ?>
                                                <option value="Sudah Ditera" <?= $ma->status == 'Sudah Ditera' ? 'selected' : '' ?>>Sudah Ditera</option>
                                                <option value="Sudah Ditera Ulang" <?= $ma->status == 'Sudah Ditera Ulang' ? 'selected' : '' ?>>Sudah Ditera Ulang</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="delete_meter_air_<?= $ma->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/meter_air/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus Meter Air</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $ma->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus meter air ini?</h5>
                                        <p class="text-danger">Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <div class="modal fade" id="add_meter_air" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/meter_air/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Meter Air</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="id_perusahaan">Perusahaan Pemilik Meter Air</label>
                            <select name="id_perusahaan" class="form-control" required>
                                <option value="">-- Pilih Perusahaan --</option>
                                <?php foreach ($perusahaan as $pt): ?>
                                    <option value="<?= $pt->id ?>"><?= $pt->nama_pt ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-7">
                                <label>Merek</label>
                                <input type="text" name="merek" class="form-control" required>
                            </div>
                            <div class="col-sm-5">
                                <label for="kelas">Kelas Meter Air</label>
                                <select class="form-control" name="kelas" required>
                                    <option value="">-- Pilih Kelas --</option>
                                    <option value="1">1 (Satu)</option>
                                    <option value="2">2 (Dua)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label>Tahun Pembuatan</label>
                                <input type="number" name="tahun_pembuatan" class="form-control" required>
                            </div>
                            <div class="col-sm-8">
                                <label>Model / Tipe</label>
                                <input type="text" name="model_tipe" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                                <label>Nomor Seri (dapat lebih dari 1)</label>
                                <textarea name="list_nomor_seri" class="form-control" rows="3" required placeholder="Masukkan satu nomor seri per baris"></textarea>
                            </div>
                            <div class="col-sm-3 text-danger">
                                <label>Contoh:</label>
                                <small class="form-text">SN-001<br>SN-002<br>SN-003<br>SN-004</small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-5">
                                <label>Diameter Dalam (DN)</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="diameter" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">mm</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <label for="pemasangan">Tipe Pemasangan Meter Air</label>
                                <select class="form-control" name="pemasangan" required>
                                    <option value="">-- Pilih --</option>
                                    <option value="Vertikal">Vertikal</option>
                                    <option value="Horizontal">Horizontal</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-8">
                                <label>Laju Alir Nominal (Q₃)</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="laju_alir_nominal" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">m³/h</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <label>Rasio (Q₃ / Q₁)</label>
                                <input type="number" step="any" name="rasio" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label>Suhu Minimum</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="suhu_min" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">°C</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>Suhu Maksimum</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="suhu_max" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">°C</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label>Tekanan Minimum</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="tekanan_min" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">kPa</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label>Tekanan Maksimum</label>
                                <div class="input-group">
                                    <input class="form-control" type="number" step="any" name="tekanan_max" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">kPa</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status" required>
                                <option value="">-- Pilih Status --</option>
                                <option value="Belum Ditera">Belum Ditera</option>
                                <option value="Sudah Ditera">Sudah Ditera</option>
                                <option value="Sudah Ditera Ulang">Sudah Ditera Ulang</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_meter_air').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }],
        });
    });
</script>