<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Surat Tugas Meter Air</strong></h1>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('success') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <div>
                <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_st_meter_air"><i class="fa fa-plus"></i> Tambah Surat Tugas</button>
            </div>

            <table class="table box table-sm" id="list_st_meter_air">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-3">NO. SURAT</th>
                        <th class="col-3">PERUSAHAAN PEMILIK</th>
                        <th class="col-2">TERA / TERA ULANG</th>
                        <th class="col-2">KETUA PELAKSANA</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($surat_tugas as $st) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $st->nomor_st ?></td>
                            <td><?= $st->nama_pt ?></td>
                            <td><?= $st->tera_tera_ulang ?></td>
                            <td><?= $st->nama_lengkap ?></td>

                            <?php $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $st->nomor_st); ?>
                            <td><a href="<?= base_url('assets/st_meter_air/Surat Tugas Nomor ' . $safe_nomor_st . '.pdf') ?>" target="_blank" class="btn btn-warning btn-sm"> <i class="fas fa-download"></i></a></td>

                            <?php if ($st->status_kirim == 0): ?>
                                <td>
                                    <?= form_open('kepala_uml/st_meter_air/send'); ?>
                                        <input type="hidden" name="id" value="<?= $st->id ?>">
                                        <button type="submit" class="btn btn-success btn-sm">
                                            <i class="fas fa-paper-plane"></i>
                                        </button>
                                    <?= form_close(); ?>
                                </td>
                            <?php else: ?>
                                <td>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        <i class="fas fa-check-circle"></i>
                                    </button>
                                </td>
                            <?php endif; ?>

                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_st_meter_air_<?= $st->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <div class="modal fade" id="delete_st_meter_air_<?= $st->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('kepala_uml/st_meter_air/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus ST Meter Air</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $st->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus ST meter air ini?</h5>
                                        <p class="text-danger"><strong>Seluruh cerapan dan SKHP</strong> yang terkait dengan ST ini akan ikut terhapus. Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <div class="modal fade" id="add_st_meter_air" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <?= form_open('kepala_uml/st_meter_air/add', ['id' => 'form-add-st']); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Surat Tugas</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="kepala_uml" value="<?= $kepala_uml ?>">
                        <div class="form-group row">
                            <div class="col-sm-7">
                                <label>No. Surat Tugas</label>
                                <input type="text" name="nomor_st" class="form-control" required>
                            </div>
                            <div class="col-sm-5">
                                <label for="tera_tera_ulang">Tera / Tera Ulang</label>
                                <select class="form-control" name="tera_tera_ulang" required>
                                    <option value="">-- Pilih --</option>
                                    <option value="Tera">Tera</option>
                                    <option value="Tera Ulang">Tera Ulang</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                                <label for="id_perusahaan">Perusahaan Pemilik Meter Air</label>
                                <select name="id_perusahaan" class="form-control" required>
                                    <option value="">-- Pilih Perusahaan --</option>
                                    <?php foreach ($perusahaan as $pt): ?>
                                        <option value="<?= $pt->id ?>"><?= $pt->nama_pt ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <label>Jumlah Meter Air</label>
                                <input type="number" name="jumlah_meter_air" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                                <label>Nomor Seri (dapat lebih dari 1)</label>
                                <textarea name="list_nomor_seri" class="form-control" rows="3" required placeholder="Masukkan satu nomor seri per baris"></textarea>
                                <div class="invalid-feedback d-block" id="serial-error" style="display: none;"></div>
                            </div>
                            <div class="col-sm-3 text-danger">
                                <label>Contoh:</label>
                                <small class="form-text">SN-001<br>SN-002<br>SN-003<br>SN-004</small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-5">
                                <label for="ketua_pelaksana">Ketua Pelaksana</label>
                                <select class="form-control" name="ketua_pelaksana" id="ketua_pelaksana" required>
                                    <option value="">-- Pilih Ketua Pelaksana --</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?= $user->id_pegawai ?>" data-id-pegawai="<?= $user->id_pegawai ?>"><?= $user->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                <label>Tanggal Pelaksanaan</label>
                                <input type="date" name="tanggal_pelaksanaan" class="form-control" required>
                            </div>
                            <div class="col-sm-3">
                                <label for="jumlah_pendamping">Jumlah Pendamping</label>
                                <select class="form-control" name="jumlah_pendamping" id="jumlah_pendamping" required>
                                    <option value="">-- Pilih --</option>
                                    <option value="0">Tidak Ada</option>
                                    <option value="1">1 (Satu)</option>
                                    <option value="2">2 (Dua)</option>
                                    <option value="3">3 (Tiga)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 pendamping-container" id="wrapper_pendamping_1">
                                <label for="pendamping_1">Pendamping 1</label>
                                <select class="form-control pendamping" name="pendamping_1" id="pendamping_1">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4 pendamping-container" id="wrapper_pendamping_2">
                                <label for="pendamping_2">Pendamping 2</label>
                                <select class="form-control pendamping" name="pendamping_2" id="pendamping_2">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4 pendamping-container" id="wrapper_pendamping_3">
                                <label for="pendamping_3">Pendamping 3</label>
                                <select class="form-control pendamping" name="pendamping_3" id="pendamping_3">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelector("#form-add-st").addEventListener("submit", function(e) {
        const jumlahInput = document.querySelector("[name='jumlah_meter_air']");
        const textarea = document.querySelector("[name='list_nomor_seri']");
        const errorDiv = document.getElementById("serial-error");

        const jumlah = parseInt(jumlahInput.value);
        const serials = textarea.value
            .split("\n")
            .map(s => s.trim())
            .filter(Boolean); // Remove empty lines

        // Clear previous error states
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        textarea.classList.remove("is-invalid");

        if (serials.length !== jumlah) {
            e.preventDefault(); // prevent form submission
            textarea.classList.add("is-invalid");
            errorDiv.style.display = "block";
            errorDiv.innerHTML = `Jumlah nomor seri yang dimasukkan (<strong>${serials.length}</strong>) tidak sama dengan jumlah meter air (<strong>${jumlah}</strong>).`;
        }
    });
</script>

<script>
    $(document).ready(function() {
        function getSelectedKetuaPelaksanaId() {
            const ketuaOpt = $('#ketua_pelaksana option:selected');
            return ketuaOpt.data('id-pegawai');
        }

        function getSelectedPendampingValues() {
            return $('.pendamping').map(function() {
                return $(this).val();
            }).get().filter(Boolean); // remove empty
        }

        function updatePendampingVisibility() {
            const ketuaPelaksanaId = getSelectedKetuaPelaksanaId();
            const selectedPendampings = getSelectedPendampingValues();

            $('.pendamping').each(function() {
                const $select = $(this);
                const currentVal = $select.val();
                let hasReset = false;

                $select.find('option').each(function() {
                    const val = $(this).val();

                    if (val === '') {
                        $(this).show();
                        return;
                    }

                    if (val == ketuaPelaksanaId || (selectedPendampings.includes(val) && val !== currentVal)) {
                        $(this).hide();
                        if (currentVal == val && !hasReset) {
                            $select.val('');
                            hasReset = true;
                        }
                    } else {
                        $(this).show();
                    }
                });
            });
        }

        function updatePendampingFields() {
            const jumlah = parseInt($('#jumlah_pendamping').val());

            for (let i = 1; i <= 3; i++) {
                const wrapper = $(`#wrapper_pendamping_${i}`);
                const $field = $(`#pendamping_${i}`);

                if (i <= jumlah) {
                    wrapper.show();
                    $field.prop('required', true);
                } else {
                    wrapper.hide();
                    $field.val('');
                    $field.prop('required', false);
                }
            }

            updatePendampingVisibility();
        }

        $('#ketua_pelaksana').on('change', updatePendampingVisibility);
        $('.pendamping').on('change', updatePendampingVisibility);
        $('#jumlah_pendamping').on('change', updatePendampingFields);

        // Init on modal open (first load)
        updatePendampingFields();
    });
</script>


<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_st_meter_air').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>