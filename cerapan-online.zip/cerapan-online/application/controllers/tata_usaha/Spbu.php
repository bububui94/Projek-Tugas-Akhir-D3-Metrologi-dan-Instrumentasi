<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Spbu extends CI_Controller {
    public function __construct() {
        parent :: __construct();
        $this->load->model('tata_usaha/model_spbu');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $this->load->model('tata_usaha/model_pt_pubbm');
        $data ['perusahaan'] = $this->model_pt_pubbm->read()->result();
        $data ['daftar_spbu'] = $this->model_spbu->read()->result();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/pubbm/list_spbu', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('perusahaan_id', 'Perusahaan_ID', 'required|integer');
        $this->form_validation->set_rules('nama_spbu', 'Nama_SPBU', 'required');
        $this->form_validation->set_rules('lokasi', 'Lokasi', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/spbu');
            return;
        }

        $id = $this->input->post('id');
        $data = [
            'perusahaan_id'     => $this->input->post('perusahaan_id'),
            'nama_spbu'         => $this->input->post('nama_spbu'),
            'lokasi'            => $this->input->post('lokasi')
        ];

        $this->model_spbu->add($data);
        redirect('tata_usaha/spbu');
    }

    public function update() {
        $this->form_validation->set_rules('perusahaan_id', 'Perusahaan_ID', 'required');
        $this->form_validation->set_rules('nama_spbu', 'Nama_SPBU', 'required');
        $this->form_validation->set_rules('lokasi', 'Lokasi', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/spbu');
            return;
        }
        
        $id = $this->input->post('id');
        $data = [
            'perusahaan_id'     => $this->input->post('perusahaan_id'),
            'nama_spbu'         => $this->input->post('nama_spbu'),
            'lokasi'            => $this->input->post('lokasi')
        ];

        $this->model_spbu->update($id, $data);
        redirect('tata_usaha/spbu');
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $this->model_spbu->delete($id);
        redirect('tata_usaha/spbu');
    }
}