<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Cerapan PUBBM</strong></h1>
        </div>

        <section class="content">
            <table class="table box table-sm" id="list_cerapan_pubbm">
                <thead>
                    <tr>
                        <th>NO.</th>
                        <th>NO. SURAT TUGAS</th>
                        <th>SPBU PEMILIK</th>
                        <th>NOMOR SERI</th>
                        <th>TANGGAL PELAKSANAAN</th>
                        <th colspan="2">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($cerapan as $crp) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $crp->nomor_st ?></td>
                            <td><?= $crp->nama_spbu ?></td>
                            <td><?= $crp->nomor_seri ?></td>
                            <td><?= indo_date($crp->tgl_pelaksanaan) ?></td>

                            <!-- Tombol Edit -->
                            <td>
                                <a href="<?= base_url('penera/cerapan_pubbm/edit/' . $crp->id) ?>" target="_blank" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </td>
                            <!-- Tombol Send -->
                            <td>
                                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#send_st_pubbm_<?= $crp->id ?>" type="button">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#list_cerapan_pubbm').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>