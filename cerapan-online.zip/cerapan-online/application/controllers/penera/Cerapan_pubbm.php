<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cerapan_pubbm extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('penera/model_cerapan_pubbm');
        $this->load->model('kepala_uml/model_st_pubbm');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 3) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $this->load->model('penera/model_cerapan_pubbm'); // pastikan ini dipanggil
        $data['cerapan'] = $this->model_cerapan_pubbm->get_all();

        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/cerapan/list_cerapan_pubbm', $data); // ganti nama view-nya disini
        $this->load->view('templates_penera/footer');
    }

    public function edit($id) {
        $this->load->model('penera/model_cerapan_pubbm');

        $data['cerapan'] = $this->model_cerapan_pubbm->get_by_id($id); // ← penting!

        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/cerapan/edit_cerapan_pubbm', $data); // ← data dikirim
        $this->load->view('templates_penera/footer');
    }


    public function simpan_form_awal() {
        $id = $this->input->post('id');

        $data = [
            'q1a' => $this->input->post('q1a'),
            'ket_q1a' => $this->input->post('ket_q1a'),
            'q1b' => $this->input->post('q1b'),
            'ket_q1b' => $this->input->post('ket_q1b'),
            'q1c' => $this->input->post('q1c'),
            'ket_q1c' => $this->input->post('ket_q1c'),
            'q2a' => $this->input->post('q2a'),
            'ket_q2a' => $this->input->post('ket_q2a'),
            'q2b' => $this->input->post('q2b'),
            'ket_q2b' => $this->input->post('ket_q2b'),
            'q2c' => $this->input->post('q2c'),
            'ket_q2c' => $this->input->post('ket_q2c'),
            'q3a' => $this->input->post('q3a'),
            'ket_q3a' => $this->input->post('ket_q3a'),
            'q3b' => $this->input->post('q3b'),
            'ket_q3b' => $this->input->post('ket_q3b'),
            'q3c' => $this->input->post('q3c'),
            'ket_q3c' => $this->input->post('ket_q3c'),
            'q4' => $this->input->post('q4'),
            'ket_q4' => $this->input->post('ket_q4'),
            'q5' => $this->input->post('q5'),
            'ket_q5' => $this->input->post('ket_q5'),
            'q6' => $this->input->post('q6'),
            'ket_q6' => $this->input->post('ket_q6'),
            'q7' => $this->input->post('q7'),
            'ket_q7' => $this->input->post('ket_q7'),
            'q8' => $this->input->post('q8'),
            'ket_q8' => $this->input->post('ket_q8'),
            'q9' => $this->input->post('q9'),
            'ket_q9' => $this->input->post('ket_q9'),
            'q10' => $this->input->post('q10'),
            'ket_q10' => $this->input->post('ket_q10'),
            'q11' => $this->input->post('q11'),
            'ket_q11' => $this->input->post('ket_q11'),
            'q12' => $this->input->post('q12'),
            'ket_q12' => $this->input->post('ket_q12'),
            
            'kesimpulan' => $this->input->post('kesimpulan')
        ];

        $this->model_cerapan_pubbm->update($id, $data);

        // Arahkan ke halaman selanjutnya
        redirect('penera/cerapan_pubbm/form_pengujian_pubbm/' . $id);
    }

    public function form_pengujian_pubbm($id) {
        $data['cerapan'] = $this->model_cerapan_pubbm->get_by_id($id);
        
        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/cerapan/form_pengujian_pubbm', $data); // kamu buat view ini nanti
        $this->load->view('templates_penera/footer');
    }

    public function simpan_form_pengujian() {
        $id = $this->input->post('id'); 

        $hose_reel = $this->input->post('hose_reel'); // 'dengan' / 'tanpa' / null
        if (!in_array($hose_reel, ['dengan', 'tanpa'], true)) {
            $hose_reel = null; // biar aman kalau radio belum dipilih
        }

        $data = [
            'total_awal_min' => $this->input->post('total_awal_min'),
            'total_akhir_min' => $this->input->post('total_akhir_min'),
            'volum_total_min' => $this->input->post('volum_total_min'),

            'total_awal_opr' => $this->input->post('total_awal_opr'),
            'total_akhir_opr' => $this->input->post('total_akhir_opr'),
            'volum_total_opr' => $this->input->post('volum_total_opr'),

            'total_awal_max' => $this->input->post('total_awal_max'),
            'total_akhir_max' => $this->input->post('total_akhir_max'),
            'volum_total_max' => $this->input->post('volum_total_max'),

            'kap_min' => $this->input->post('kap_min'),
            'kap_max' => $this->input->post('kap_max'),

            'vfd_min_1' => $this->input->post('vfd_min_1'),
            'vref_min_1' => $this->input->post('vref_min_1'),
            'efd_min_1' => $this->input->post('efd_min_1'),
            'vfd_opr_1' => $this->input->post('vfd_opr_1'),
            'vref_opr_1' => $this->input->post('vref_opr_1'),
            'efd_opr_1' => $this->input->post('efd_opr_1'),
            'vfd_max_1' => $this->input->post('vfd_max_1'),
            'vref_max_1' => $this->input->post('vref_max_1'),
            'efd_max_1' => $this->input->post('efd_max_1'),
            'vfd_min_2' => $this->input->post('vfd_min_2'),
            'vref_min_2' => $this->input->post('vref_min_2'),
            'efd_min_2' => $this->input->post('efd_min_2'),
            'vfd_opr_2' => $this->input->post('vfd_opr_2'),
            'vref_opr_2' => $this->input->post('vref_opr_2'),
            'efd_opr_2' => $this->input->post('efd_opr_2'),
            'vfd_max_2' => $this->input->post('vfd_max_2'),
            'vref_max_2' => $this->input->post('vref_max_2'),
            'efd_max_2' => $this->input->post('efd_max_2'),
            'vfd_min_3' => $this->input->post('vfd_min_3'),
            'vref_min_3' => $this->input->post('vref_min_3'),
            'efd_min_3' => $this->input->post('efd_min_3'),
            'vfd_opr_3' => $this->input->post('vfd_opr_3'),
            'vref_opr_3' => $this->input->post('vref_opr_3'),
            'efd_opr_3' => $this->input->post('efd_opr_3'),
            'vfd_max_3' => $this->input->post('vfd_max_3'),
            'vref_max_3' => $this->input->post('vref_max_3'),
            'efd_max_3' => $this->input->post('efd_max_3'),

            'error_min' => $this->input->post('error_min'),
            'error_opr' => $this->input->post('error_opr'),
            'error_max' => $this->input->post('error_max'),

            'uncertainty_min' => $this->input->post('uncertainty_min'),
            'uncertainty_opr' => $this->input->post('uncertainty_opr'),
            'uncertainty_max' => $this->input->post('uncertainty_max'),

            'viskositas' => $this->input->post('viskositas'),

            'vfd_vol' => $this->input->post('vfd_vol'),
            'vref_vol' => $this->input->post('vref_vol'),
            'efd_vol' => $this->input->post('efd_vol'),
            'vfd_hrg' => $this->input->post('vfd_hrg'),
            'vref_hrg' => $this->input->post('vref_hrg'),
            'efd_hrg' => $this->input->post('efd_hrg'),
            'vfd_elu' => $this->input->post('vfd_elu'),
            'vref_elu' => $this->input->post('vref_elu'),
            'efd_elu' => $this->input->post('efd_elu'),
            'ed_result' => $this->input->post('ed_result'),

            'hose_reel' => $hose_reel,
            'anti_drain' => $this->input->post('anti_drain'),

            'vol_laju_max' => $this->input->post('vol_laju_max'),
            'waktu_laju_max' => $this->input->post('waktu_laju_max'),
            'q_laju_max' => $this->input->post('q_laju_max'),

            'uji_1' =>$this->input->post('uji_1'),
            'uji_2' =>$this->input->post('uji_2'),
            'uji_3' =>$this->input->post('uji_3'),
            'uji_4' =>$this->input->post('uji_4'),
            'uji_5' =>$this->input->post('uji_5'),
            'uji_6' =>$this->input->post('uji_6'),
            'uji_7' =>$this->input->post('uji_7')

        ];

        $this->model_cerapan_pubbm->update($id, $data);
        $this->session->set_flashdata('success', 'Data cerapan berhasil diperbarui');
        redirect('penera/cerapan_pubbm' );
    }



}