<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><strong>Daftar SPBU</strong></h1>
        </div>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('error') ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="content">
            <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_spbu"><i class="fa fa-plus"></i> Tambah SPBU</button>
            <table class="table box table-sm" id="list_spbu">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-2">PERUSAHAAN</th>
                        <th class="col-3">NAMA/KODE SPBU</th>
                        <th class="col-5">LOKASI</th>
                        <th class="col-1 text-center" colspan="3" style="vertical-align: middle;">AKSI</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $no = 1;
                    foreach ($daftar_spbu as $spbu) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $spbu->nama_pt ?></td>
                            <td><?= $spbu->nama_spbu ?></td>
                            <td><?= $spbu->lokasi ?></td>

                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_spbu_<?= $spbu->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit_spbu_<?= $spbu->id ?>" type="button"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_spbu_<?= $spbu->id ?>" type="button"><i class="fas fa-trash"></i></button></td>
                        </tr>

                        <div class="modal fade" id="detail_spbu_<?= $spbu->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail SPBU</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Nama/Kode SPBU:</strong> <?= $spbu->nama_spbu ?></p>
                                        <p><strong>Lokasi:</strong> <?= $spbu->lokasi ?></p>
                                        <p><strong>Jumlah Nozzle:</strong> <?= $spbu->jumlah_nozzle ?></p>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="edit_spbu_<?= $spbu->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/spbu/update'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Edit SPBU</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $spbu->id ?>">

                                        <div class="form-group">
                                            <label for="perusahaan_id">Perusahaan Pemilik SPBU</label>
                                            <select name="perusahaan_id" class="form-control" required>
                                                <option value="">-- Pilih Perusahaan --</option>
                                                <?php foreach ($perusahaan as $pt): ?>
                                                    <option value="<?= $pt->id ?>" <?= $spbu->perusahaan_id == $pt->id ? 'selected' : '' ?>><?= $pt->nama_pt ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nama/Kode SPBU</label>
                                            <input type="text" name="nama_spbu" class="form-control" value="<?= $spbu->nama_spbu ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Lokasi</label>
                                            <input type="text" name="lokasi" class="form-control" value="<?= $spbu->lokasi ?>">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="delete_spbu_<?= $spbu->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('tata_usaha/spbu/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus SPBU</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $spbu->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus SPBU ini?</h5>
                                        <p class="text-danger"><strong>Seluruh data</strong> yang terkait dengan SPBU ini akan ikut terhapus. Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <div class="modal fade" id="add_spbu" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <?= form_open('tata_usaha/spbu/add'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah SPBU</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="perusahaan_id">Perusahaan Pemilik SPBU</label>
                            <select name="perusahaan_id" class="form-control" required>
                                <option value="">-- Pilih Perusahaan --</option>
                                <?php foreach ($perusahaan as $pt): ?>
                                    <option value="<?= $pt->id ?>"><?= $pt->nama_pt ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nama/Kode SPBU</label>
                            <input type="text" name="nama_spbu" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Lokasi</label>
                            <input type="text" name="lokasi" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_spbu').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }]
        });
    });
</script>