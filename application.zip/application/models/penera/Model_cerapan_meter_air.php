<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_cerapan_meter_air extends CI_Model {
    public function read() {
        $this->db->select('t_cerapan_meter_air.*, t_st_meter_air.nomor_st');
        $this->db->from('t_cerapan_meter_air');
        $this->db->join('t_st_meter_air', 't_st_meter_air.id = t_cerapan_meter_air.id_surat_tugas');
        $this->db->where('t_cerapan_meter_air.status_kirim', 1);
        $this->db->where_not_in('t_cerapan_meter_air.id', 'SELECT id_cerapan FROM t_skhp_meter_air', false);
        return $this->db->get();
    }


    public function read_by_ketua($id_pegawai) {
        $this->db->select('t_cerapan_meter_air.*, t_st_meter_air.nomor_st, t_st_meter_air.tanggal_pelaksanaan, m_pt_meter_air.nama_pt, m_pegawai.nama_lengkap');
        $this->db->from('t_cerapan_meter_air');
        $this->db->join('t_st_meter_air', 't_st_meter_air.id = t_cerapan_meter_air.id_surat_tugas');
        $this->db->join('m_pt_meter_air', 'm_pt_meter_air.id = t_cerapan_meter_air.id_perusahaan');
        $this->db->join('m_pegawai', 'm_pegawai.id = t_cerapan_meter_air.id_pegawai');
        $this->db->where('t_cerapan_meter_air.id_pegawai', $id_pegawai);
        return $this->db->get();
    }

    public function get_by_id($id) {
        $this->db->select('t_cerapan_meter_air.*, t_st_meter_air.nomor_st, m_pt_meter_air.nama_pt, m_meter_air.kelas, m_meter_air.laju_alir_minimum, m_meter_air.laju_alir_transisi, m_meter_air.laju_alir_nominal, m_meter_air.laju_alir_maksimum, m_meter_air.diameter');
        $this->db->from('t_cerapan_meter_air');
        $this->db->join('t_st_meter_air', 't_st_meter_air.id = t_cerapan_meter_air.id_surat_tugas');
        $this->db->join('m_pt_meter_air', 'm_pt_meter_air.id = t_cerapan_meter_air.id_perusahaan');
        $this->db->join('m_meter_air', 'm_meter_air.nomor_seri = t_cerapan_meter_air.nomor_seri');
        $this->db->where('t_cerapan_meter_air.id', $id);
        return $this->db->get();        
    }

    public function get_by_id_cerapan($id) {
        return $this->db->get_where('t_cerapan_meter_air', ['id' => $id])->row();
    }

    public function get_by_surat_tugas($id_surat_tugas) {
        $this->db->where('id_surat_tugas', $id_surat_tugas);
        return $this->db->get('t_cerapan_meter_air')->result();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('t_cerapan_meter_air', $data);
    }

    public function mark_as_sent($id) {
        return $this->db
            ->where('id', $id)
            ->update('t_cerapan_meter_air', ['status_kirim' => 1]);
    }

    public function update_meter_air($id) {
        $cerapan = $this->db
            ->select('tera_tera_ulang, nomor_seri, q1_sah_batal, q2_sah_batal, q3_sah_batal')
            ->where('id', $id)
            ->get('t_cerapan_meter_air')
            ->row();

        if (!$cerapan) return;

        $is_sah = (
            $cerapan->q1_sah_batal === 'SAH' &&
            $cerapan->q2_sah_batal === 'SAH' &&
            $cerapan->q3_sah_batal === 'SAH'
        );

        $sah_batal = $is_sah ? 'SAH' : 'BATAL';

        $is_tera = (
            $cerapan->tera_tera_ulang === 'Tera'
        );

        $tera_tera_ulang = $is_tera ? 'Sudah Ditera' : 'Sudah Ditera Ulang';

        $this->db
            ->where('nomor_seri', $cerapan->nomor_seri)
            ->update('m_meter_air', ['sah_batal' => $sah_batal, 'status' => $tera_tera_ulang]);
    }

    public function count($id_pegawai) {
        if ($id_pegawai) {
            $this->db->where('id_pegawai', $id_pegawai);
        }
        return $this->db->count_all_results('t_cerapan_meter_air');
    }
}