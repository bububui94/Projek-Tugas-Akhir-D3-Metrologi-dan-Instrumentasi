<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Skhp_meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('kepala_uml/model_skhp_meter_air');
        $this->load->model('kepala_uml/model_st_meter_air');
        $this->load->model('tata_usaha/model_pegawai');
        $this->load->model('tata_usaha/model_pt_meter_air');
        $this->load->model('tata_usaha/model_meter_air');
        $this->load->model('penera/model_cerapan_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 1) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['skhp_meter_air'] = $this->model_skhp_meter_air->read()->result();
        $data ['cerapan'] = $this->model_cerapan_meter_air->read()->result();

        foreach ($data['cerapan'] as $crp) {
            $data['available_surat_tugas'][$crp->id_surat_tugas] = $crp->nomor_st;
        }

        $this->load->view('templates_kepala_uml/header');
        $this->load->view('templates_kepala_uml/sidebar');
        $this->load->view('kepala_uml/skhp/list_skhp_meter_air', $data);
        $this->load->view('templates_kepala_uml/footer');
    }

    public function add() {
        $this->form_validation->set_rules('nomor_skhp', 'Nomor_SKHP', 'required|is_unique[t_skhp_meter_air.nomor_skhp]', ['is_unique' => 'Nomor SKHP sudah digunakan.']);
        $this->form_validation->set_rules('id_surat_tugas', 'ID_Surat_Tugas', 'required');
        $this->form_validation->set_rules('id_cerapan', 'ID_Cerapan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('kepala_uml/skhp_meter_air');
            return;
        }

        $id_surat_tugas = $this->input->post('id_surat_tugas');
        $id_cerapan = $this->input->post('id_cerapan');

        $already_exists = $this->model_skhp_meter_air->already_exists($id_cerapan, $id_surat_tugas);

        if ($already_exists) {
            $this->session->set_flashdata('error', 'SKHP sudah ada untuk nomor seri tersebut dalam surat tugas yang sama');
            redirect('kepala_uml/skhp_meter_air');
            return;
        }

        $related = $this->model_skhp_meter_air->get_cerapan_details($id_cerapan);

        if (!$related) {
            $this->session->set_flashdata('error', 'Data cerapan tidak ditemukan.');
            redirect('kepala_uml/skhp_meter_air');
            return;
        }

        $nomor_skhp =$this->input->post('nomor_skhp');

        $data = [
            'nomor_skhp'            => $nomor_skhp,
            'id_surat_tugas'        => $id_surat_tugas,
            'id_cerapan'            => $id_cerapan,
            'pengujian_selanjutnya' => date('Y-m-d', strtotime('+5 years')),
            'id_perusahaan'         => $related->id_perusahaan,
            'id_pegawai'            => $related->id_pegawai,
            'tanggal_dibuat'        => date('Y-m-d'),
        ];

        $this->model_skhp_meter_air->add($data);
        $this->generate_pdf($nomor_skhp);
        $this->session->set_flashdata('success', 'Surat tugas hasil pengujian baru berhasil ditambahkan');
        redirect('kepala_uml/skhp_meter_air');
    }

    public function generate_pdf($nomor_skhp) {
        $this->load->library('dompdf_lib');
        $skhp = $this->model_skhp_meter_air->get_by_nomor_skhp($nomor_skhp);

        if (!$skhp) {
            show_error("SKHP Nomor $nomor_skhp tidak ditemukan", 404);
            return;
        }
        
        $surat_tugas = $this->model_st_meter_air->get_by_id($skhp->id_surat_tugas);
        $kepala_uml = $this->model_pegawai->get_by_id($surat_tugas->kepala_uml);
        $cerapan = $this->model_cerapan_meter_air->get_by_id_cerapan($skhp->id_cerapan);
        $meter_air = $this->model_meter_air->get_by_single_nomor_seri($cerapan->nomor_seri);
        $perusahaan = $this->model_pt_meter_air->get_by_id($skhp->id_perusahaan);
        $ketua_pelaksana = $this->model_pegawai->get_by_id($skhp->id_pegawai);

        $tahun_tera_full = date('Y', strtotime($surat_tugas->tanggal_pelaksanaan));
        $tahun_tera = substr($tahun_tera_full, -2);

        $pengujian_selanjutnya = $skhp->pengujian_selanjutnya;

        $data = [
            'skhp'              => $skhp,
            'surat_tugas'       => $surat_tugas,
            'kepala_uml'        => $kepala_uml,
            'cerapan'           => $cerapan,
            'meter_air'         => $meter_air,
            'perusahaan'        => $perusahaan,
            'ketua_pelaksana'   => $ketua_pelaksana,
            'tahun_tera'        => $tahun_tera,
            'pengujian_selanjutnya' => $pengujian_selanjutnya,
        ];

        $html = $this->load->view('generate_pdf/skhp_meter_air_pdf', $data, true);

        $this->dompdf_lib->loadHtml($html);
        $this->dompdf_lib->setPaper('A4', 'portrait');
        $this->dompdf_lib->render();

        $safe_nomor_skhp = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $nomor_skhp);
        $filename = 'SKHP Nomor ' . $safe_nomor_skhp . '.pdf';
        $output = $this->dompdf_lib->output();
        file_put_contents(FCPATH . 'assets/skhp_meter_air/' . $filename, $output);
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $record = $this->model_skhp_meter_air->get_by_id($id);
        if ($record && $record->nomor_skhp) {
            $safe_nomor_skhp = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $record->nomor_skhp);
            $filename = 'SKHP Nomor ' . $safe_nomor_skhp . '.pdf';
            $filepath = FCPATH . 'assets/skhp_meter_air/' . $filename;

            if (file_exists($filepath)) {
                unlink($filepath); // Delete PDF file
            }
        }

        $this->model_skhp_meter_air->delete($id);
        $this->session->set_flashdata('success', 'Surat keterangan hasil pengujian berhasil dihapus');
        redirect('kepala_uml/skhp_meter_air');
    }
}