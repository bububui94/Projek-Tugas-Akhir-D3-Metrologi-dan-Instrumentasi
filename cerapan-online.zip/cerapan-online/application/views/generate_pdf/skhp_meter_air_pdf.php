<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SKHP Meter Air <?= $skhp->nomor_skhp ?></title>

    <link rel="stylesheet" href="<?= base_url('assets/css/skhp_meter_air_pdf.css') ?>">
</head>

<body>
    <img class="kop-surat" src="<?= base_url('assets/img/Kop_Surat_Akmet.png') ?>" alt="kop_akmet">
    <hr>
    <br>
    <table>
        <tr>
            <td class="col-5"></td>
            <td class="col-5"></td>
            <td class="col-35"></td>
            <td class="col-5"></td>
            <td></td>
        </tr>
        <tr class="font-size-14 bold center underline">
            <td colspan="5">SURAT KETERANGAN HASIL PENGUJIAN</td>
        </tr>
        <tr>
            <td colspan="5" class="font-size-10 center">Nomor Surat: <?= $skhp->nomor_skhp ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>A.</td>
            <td colspan="4">Pemilik dan Penguji :</td>
        </tr>
        <tr>
            <td></td>
            <td>1.</td>
            <td>Nama Pemilik / Perusahaan</td>
            <td>:</td>
            <td class="bold"><?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td></td>
            <td>2.</td>
            <td>Alamat</td>
            <td>:</td>
            <td class="justify"><?= $perusahaan->alamat ?></td>
        </tr>
        <tr>
            <td></td>
            <td>3.</td>
            <td>Nama Penguji</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->nama_lengkap ?></td>
        </tr>
        <tr>
            <td></td>
            <td>4.</td>
            <td>NIP Penguji</td>
            <td>:</td>
            <td><?= $ketua_pelaksana->nip ?></td>
        </tr>
        <tr>
            <td></td>
            <td>5.</td>
            <td>Tanggal Pengujian</td>
            <td>:</td>
            <td><?= indo_date($surat_tugas->tanggal_pelaksanaan) ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>B.</td>
            <td colspan="4">Spesifikasi UTTP :</td>
        </tr>
        <tr>
            <td></td>
            <td>1.</td>
            <td>Jenis UTTP</td>
            <td>:</td>
            <td>Meter Air</td>
        </tr>
        <tr>
            <td></td>
            <td>2.</td>
            <td>Merek</td>
            <td>:</td>
            <td><?= $meter_air->merek ?></td>
        </tr>
        <tr>
            <td></td>
            <td>3.</td>
            <td>Model/Tipe ; Nomor Seri</td>
            <td>:</td>
            <td><?= $meter_air->model_tipe ?> ; <?= $meter_air->nomor_seri ?></td>
        </tr>
        <tr>
            <td></td>
            <td>4.</td>
            <td>Laju Alir Nominal (Q<sub>3</sub>) ; Rasio</td>
            <td>:</td>
            <td><?= $meter_air->laju_alir_nominal ?> m<sup>3</sup>/h ; <?= $meter_air->rasio ?></td>
        </tr>
        <tr>
            <td></td>
            <td>5.</td>
            <td>Kelas Ketelitian</td>
            <td>:</td>
            <td><?= $meter_air->kelas ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>C.</td>
            <td colspan="4">Hasil Pengujian :</td>
        </tr>
        <tr>
            <td></td>
            <td colspan="4" class="justify">Telah diuji berdasarkan SK Dirjen SPK No. 133 Tahun 2015 tentang Syarat Teknis Meter Air dengan menggunakan alat standar Bejana ukur dan pengujian tersebut <?= ($meter_air->sah_batal == 'SAH') ? 'telah' : 'tidak' ?> memenuhi ketentuan Perundang-undangan dan dinyatakan <?= ($meter_air->sah_batal == 'SAH') ? 'SAH' : 'BATAL' ?> dengan dibubuhi tanda tera <?= ($meter_air->sah_batal == 'SAH') ? 'sah berupa angka ' . $tahun_tera . ' dalam segi lima beraturan' : 'batal berupa 13 garis sejajar tegak lurus pada salah satu sisi segitiga sama sisi' ?> </td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td>D.</td>
            <td colspan="2">Pengujian Berkala Selanjutnya</td>
            <td>:</td>
            <td><?= ($meter_air->sah_batal == 'SAH') ? indo_date($pengujian_selanjutnya) : '-' ?></td>
        </tr>
    </table>
    <br class="spacing-2">
    <br class="spacing-2">

    <table>
        <tr>
            <td class="col-50"></td>
            <td class="col-5"></td>
            <td class=""></td>
        </tr>
        <tr>
            <td>
                <div class="table-left">
                    <table>
                        <tr>
                            <td class="col-5"></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="underline">Catatan:</td>
                        </tr>
                        <tr>
                            <td>1.</td>
                            <td>Surat Keterangan Hasil Pengujian ini tidak berlaku apabila alat ukur atau tanda teranya rusak;</td>
                        </tr>
                        <tr>
                            <td>2.</td>
                            <td>Penggandaan / Foto copy SKHP ini tidak berlaku tanpa izin dari Kepala UML Akmet</td>
                        </tr>
                        <tr>
                            <td>3.</td>
                            <td>Penggunaannya harus dilengkapi dengan saringan</td>
                        </tr>
                        <tr>
                            <td><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="center top-border bold underline">PERHATIAN</td>
                        </tr>
                        <tr>
                            <td colspan="2" class="center side-border">TANDA TERA RUSAK / PUTUS DIANCAM PENJARA</td>
                        </tr>
                        <tr>
                            <td colspan="2" class="center side-border">SATU TAHUN DAN ATAU DENDA Rp. 1.000.000,-</td>
                        </tr>
                        <tr>
                            <td colspan="2" class="center italic bottom-border">(Pasal 25 huruf c Jo. Pasal 32 UUML)</td>
                        </tr>

                    </table>
                </div>
            </td>
            <td></td>
            <td>
                <div class="table-right">
                    <table>
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Sumedang, <?= indo_date($skhp->tanggal_dibuat) ?></td>
                        </tr>
                        <tr>
                            <td><br></td>
                        </tr>
                        <tr>
                            <td>Kepala UML,</td>
                        </tr>
                        <tr>
                            <td><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Rijal.jpg') ?>" alt="ttd"></td>
                        </tr>
                        <tr>
                            <td class="underline bold"><?= $kepala_uml->nama_lengkap ?></td>
                        </tr>
                        <tr>
                            <td><?= $kepala_uml->jabatan ?></td>
                        </tr>
                        <tr>
                            <td>NIP. <?= $kepala_uml->nip ?></td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
    </table>

    <div class="page-break"></div>

    <table>
        <tr>
            <td class="col-50"></td>
            <td class="col-10"></td>
            <td class=""></td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td class="font-size-10">Surat Keterangan Hasil Pengujian</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td class="font-size-10">Nomor Surat: <?= $skhp->nomor_skhp ?></td>
        </tr>
    </table>
    <br class="spacing-2">
    <br class="spacing-2">
    <table>
        <tr>
            <td class="col-5"></td>
            <td></td>
        </tr>
        <tr>
            <td>E.</td>
            <td>Metode, Standar dan Ketertelusuran</td>
        </tr>
        <tr>
            <td></td>
            <td>- SK Dirjen SPK No. 133 Tahun 2015 Tentang Syarat Teknis Meter Air</td>
        </tr>
        <tr>
            <td></td>
            <td>- Peralatan standar yang digunakan adalah Bejana Ukur</td>
        </tr>
        <tr>
            <td><br class="spacing-2"></td>
        </tr>
        <tr>
            <td>F.</td>
            <td>Hasil Pengujian</td>
        </tr>
    </table>
    <br>
    <?php if ($cerapan->q1_sensitivity == -100) : ?>
        <table class="tanpa_kepekaan center">
            <tr>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="3" class="border-hasil">Suhu 28°C pada Tekanan 1 atm</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="3" class="border-hasil">Kesalahan pada laju alir</td>
                <td></td>
            </tr>
            <tr class="bold">
                <td></td>
                <td class="border-sisi">Q<sub>1</sub></td>
                <td class="border-sisi">Q<sub>2</sub></td>
                <td class="border-sisi">Q<sub>3</sub></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_minimum ?> m<sup>3</sup>/h )</td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_transisi ?> m<sup>3</sup>/h )</td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_nominal ?> m<sup>3</sup>/h )</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q1_average_error == -0 ? 0 : $cerapan->q1_average_error ?> %</td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q2_average_error == -0 ? 0 : $cerapan->q2_average_error ?> %</td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q3_average_error == -0 ? 0 : $cerapan->q3_average_error ?> %</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
        </table>
    <?php else : ?>
        <table class="kepekaan center">
            <tr>
                <td class="col-10"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-20"></td>
                <td class="col-10"></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="4" class="border-hasil">Suhu 28°C pada Tekanan 1 atm</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="4" class="border-hasil">Kesalahan pada laju alir</td>
                <td></td>
            </tr>
            <tr class="bold">
                <td></td>
                <td class="border-sisi">Q<sub>1</sub></td>
                <td class="border-sisi">Q<sub>2</sub></td>
                <td class="border-sisi">Q<sub>3</sub></td>
                <td class="border-sisi">Kepekaan</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_minimum ?> m<sup>3</sup>/h )</td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_transisi ?> m<sup>3</sup>/h )</td>
                <td class="border-sisi">( <?= $meter_air->laju_alir_nominal ?> m<sup>3</sup>/h )</td>
                <td class="border-sisi">DN = 15 mm</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q1_average_error == -0 ? 0 : $cerapan->q1_average_error ?> %</td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q2_average_error == -0 ? 0 : $cerapan->q2_average_error ?> %</td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q3_average_error == -0 ? 0 : $cerapan->q3_average_error ?> %</td>
                <td rowspan="2" class="border-hasil"><?= $cerapan->q1_sensitivity ?> L/min</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>
        </table>
    <?php endif; ?>
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <br class="spacing-2">
    <table class="center">
        <tr>
            <td class="col-20"></td>
            <td></td>
            <td class="col-20"></td>
        </tr>
        <tr>
            <td></td>
            <td>Penguji,</td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Chasien.jpg') ?>" alt="ttd"></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold underline"><?= $ketua_pelaksana->nama_lengkap ?></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td>NIP. <?= $ketua_pelaksana->nip ?></td>
            <td></td>
        </tr>
    </table>
</body>