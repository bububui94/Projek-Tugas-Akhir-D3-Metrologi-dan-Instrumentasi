<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-color-1 font-weight-bold sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('kepala_uml/dashboard') ?>">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="sidebar-brand-text mx-3">KEPALA UML</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading text-color-5">
                Daftar Alat Ukur
            </div>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/pubbm') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>Daftar PUBBM</span></a>
            </li>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/meter_air') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>Daftar Meter Air</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading text-color-5">
                Surat Tugas
            </div>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/st_pubbm') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>Surat Tugas PUBBM</span></a>
            </li>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/st_meter_air') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>Surat Tugas Meter Air</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading text-color-5">
                SKHP
            </div>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/skhp_pubbm') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>SKHP PUBBM</span></a>
            </li>

            <!-- Nav Item -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('kepala_uml/skhp_meter_air') ?>">
                    <i class="fas fa-fw fa-file"></i>
                    <span>SKHP Meter Air</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-3 d-none d-lg-inline text-gray-700"><?= $this->session->userdata('username') ?></span>
                                <img class="img-profile rounded-circle"
                                    src="<?= base_url() ?>assets/img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>

                </nav>
                <!-- End of Topbar -->