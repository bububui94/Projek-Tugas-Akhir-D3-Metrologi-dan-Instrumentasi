<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class St_pubbm extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('kepala_uml/model_st_pubbm');
        $this->load->model('tata_usaha/model_pegawai');
        $this->load->model('tata_usaha/model_users');
        $this->load->model('tata_usaha/model_pt_pubbm');
        $this->load->model('tata_usaha/model_spbu');
        $this->load->model('tata_usaha/model_nozzle');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 1) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data['perusahaan']    = $this->model_pt_pubbm->read()->result();
        $data['users']         = $this->model_users->read()->result();
        $data['pegawai']       = $this->model_pegawai->read()->result();
        $data['surat_tugas']   = $this->model_st_pubbm->read()->result();
        $data['daftar_spbu']   = $this->model_spbu->read()->result();

        $this->load->view('templates_kepala_uml/header');
        $this->load->view('templates_kepala_uml/sidebar');
        $this->load->view('kepala_uml/surat_tugas/list_st_pubbm', $data);
        $this->load->view('templates_kepala_uml/footer');
    }

    public function add() {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('nomor_st', 'Nomor Surat', 'required');
        $this->form_validation->set_rules('ttu', 'Tera / Tera Ulang', 'required');
        $this->form_validation->set_rules('spbu_id', 'SPBU', 'required');
        $this->form_validation->set_rules('jumlah_nozzle', 'Jumlah Nozzle', 'required');
        $this->form_validation->set_rules('ketua_pelaksana', 'Ketua Pelaksana', 'required');
        $this->form_validation->set_rules('tgl_pelaksanaan', 'Tanggal Pelaksanaan', 'required');
        $this->form_validation->set_rules('jumlah_pendamping', 'Jumlah Pendamping', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('kepala_uml/st_pubbm');
        } else {
            $list_nomor_seri = $this->input->post('list_nomor_seri');

            $data = [
                'nomor_st'          => $this->input->post('nomor_st'),
                'ttu'               => $this->input->post('ttu'),
                'spbu_id'           => $this->input->post('spbu_id'),
                'jumlah_nozzle'     => $this->input->post('jumlah_nozzle'),
                'list_nomor_seri'   => $list_nomor_seri ? json_encode($list_nomor_seri) : null,
                'ketua_pelaksana'   => $this->input->post('ketua_pelaksana'),
                'tgl_pelaksanaan'   => $this->input->post('tgl_pelaksanaan'),
                'tgl_pembuatan'     => date('Y-m-d'), 
                'pendamping_1'      => $this->input->post('pendamping_1'),
                'pendamping_2'      => $this->input->post('pendamping_2'),
                'pendamping_3'      => $this->input->post('pendamping_3'),
                'status_kirim'      => 0
            ];

            $this->model_st_pubbm->add($data);

            $nomor_st = $this->input->post('nomor_st');
            $this->generate_pdf($nomor_st);

            $this->session->set_flashdata('success', 'Data surat tugas berhasil ditambahkan dan PDF berhasil dibuat!');
            redirect('kepala_uml/st_pubbm');
        }
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $record = $this->model_st_pubbm->get_by_id($id);
        if ($record && $record->nomor_st) {
            $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $record->nomor_st);
            $filename = 'Surat Tugas Nomor ' . $safe_nomor_st . '.pdf';
            $filepath = FCPATH . 'assets/st_pubbm/' . $filename;

            if (file_exists($filepath)) {
                unlink($filepath);
            }
        }

        $this->model_st_pubbm->delete($id);
        redirect('kepala_uml/st_pubbm');
    }

    public function generate_pdf($nomor_st) {
        $this->load->library('dompdf_lib');

        $surat_tugas = $this->model_st_pubbm->get_by_nomor_st($nomor_st);

        if (!$surat_tugas) {
            show_error("Surat Tugas Nomor $nomor_st tidak ditemukan", 404);
            return;
        }

        // Fix: decode JSON list nomor seri
        $nomor_seri = json_decode(isset($surat_tugas->list_nomor_seri) ? $surat_tugas->list_nomor_seri : '[]');

        // Ambil semua data
        $list_pubbm = $this->model_nozzle->get_by_nomor_seri($nomor_seri);
        $daftar_spbu = $this->model_spbu->get_by_id($surat_tugas->spbu_id);
        $ketua_pelaksana = $this->model_pegawai->get_by_id($surat_tugas->ketua_pelaksana);

        $pendamping_ids = [];
        if (!empty($surat_tugas->pendamping_1) && $surat_tugas->pendamping_1 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_1;
        }
        if (!empty($surat_tugas->pendamping_2) && $surat_tugas->pendamping_2 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_2;
        }
        if (!empty($surat_tugas->pendamping_3) && $surat_tugas->pendamping_3 !== '-') {
            $pendamping_ids[] = $surat_tugas->pendamping_3;
        }

        $pendampings = [];
        if (!empty($pendamping_ids)) {
            $pendampings = $this->model_pegawai->get_by_ids($pendamping_ids);
        }

        // Kirim semua data ke view
        $data = [
            'surat_tugas'      => $surat_tugas,
            'daftar_spbu'      => $daftar_spbu,
            'ketua_pelaksana'  => $ketua_pelaksana,
            'pendampings'      => $pendampings,
            'list_pubbm'       => $list_pubbm
        ];

        $html = $this->load->view('generate_pdf/st_pubbm_pdf', $data, true);

        $this->dompdf_lib->loadHtml($html);
        $this->dompdf_lib->setPaper('A4', 'portrait');
        $this->dompdf_lib->render();

        $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $nomor_st);
        $filename = 'Surat Tugas Nomor ' . $safe_nomor_st . '.pdf';
        $output = $this->dompdf_lib->output();

        file_put_contents(FCPATH . 'assets/st_pubbm/' . $filename, $output);
    }

    public function send() {
        $id = $this->input->post('id');

        if (!$id) {
            show_error('Invalid ID', 400);
            return;
        }

        $this->load->model('kepala_uml/model_st_pubbm');
        $st = $this->model_st_pubbm->get_by_id($id);
        if (!$st) {
            $this->session->set_flashdata('error', 'Data ST tidak ditemukan.');
            redirect('kepala_uml/st_pubbm');
            return;
        }

        // ✅ Update hanya status_kirim (tidak insert ke cerapan)
        $this->model_st_pubbm->update($id, ['status_kirim' => 1]);

        $this->session->set_flashdata('success', 'ST berhasil dikirim ke Penera.');
        redirect('kepala_uml/st_pubbm');
    }


    public function get_nozzle_by_spbu() {
        $spbu_id = $this->input->post('spbu_id');
        if (!$spbu_id) {
            echo json_encode([]);
            return;
        }
        $data = $this->model_nozzle->get_by_spbu($spbu_id);
        echo json_encode($data);
    }
}
