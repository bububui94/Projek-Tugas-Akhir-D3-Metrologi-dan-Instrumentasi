<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Standar extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_standar');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $data ['standar'] = $this->model_standar->read()->result();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/standar/list_standar', $data);
        $this->load->view('templates_tata_usaha/footer');
    }

    public function add() {
        $this->form_validation->set_rules('merek_bus', 'Merek_Bus', 'required');
        $this->form_validation->set_rules('tipe_bus', 'Tipe_Bus', 'required');
        $this->form_validation->set_rules('kelas_bus', 'Kelas_Bus', 'required');
        $this->form_validation->set_rules('nomor_seri_bus', 'Nomor_Seri_Bus', 'required');
        $this->form_validation->set_rules('koefisien_muai_bahan', 'Koefisien_Muai_Bahan', 'required|numeric');
        $this->form_validation->set_rules('kapasitas', 'Kapasitas', 'required|integer');
        $this->form_validation->set_rules('koreksi_bus', 'Koreksi_Bus', 'required|numeric');
        $this->form_validation->set_rules('waktu_tetes', 'Waktu_tetes', 'required|integer');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/standar');
            return;
        }

        $data = [
            'merek_bus'             => $this->input->post('merek_bus'),
            'tipe_bus'              => $this->input->post('tipe_bus'),
            'kelas_bus'             => $this->input->post('kelas_bus'),
            'nomor_seri_bus'        => $this->input->post('nomor_seri_bus'),
            'koefisien_muai_bahan'  => $this->input->post('koefisien_muai_bahan'),
            'kapasitas'             => $this->input->post('kapasitas'),
            'koreksi_bus'           => $this->input->post('koreksi_bus'),
            'waktu_tetes'           => $this->input->post('waktu_tetes'),
        ];

        $this->model_standar->add($data);
        $this->session->set_flashdata('success', 'Standar baru berhasil ditambahkan');
        redirect('tata_usaha/standar');
    }

    public function update() {
        $this->form_validation->set_rules('id', 'ID', 'required|integer');
        $this->form_validation->set_rules('merek_bus', 'Merek_Bus', 'required');
        $this->form_validation->set_rules('tipe_bus', 'Tipe_Bus', 'required');
        $this->form_validation->set_rules('kelas_bus', 'Kelas_Bus', 'required');
        $this->form_validation->set_rules('nomor_seri_bus', 'Nomor_Seri_Bus', 'required');
        $this->form_validation->set_rules('koefisien_muai_bahan', 'Koefisien_Muai_Bahan', 'required|numeric');
        $this->form_validation->set_rules('kapasitas', 'Kapasitas', 'required|integer');
        $this->form_validation->set_rules('koreksi_bus', 'Koreksi_Bus', 'required|numeric');
        $this->form_validation->set_rules('waktu_tetes', 'Waktu_tetes', 'required|integer');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('tata_usaha/standar');
            return;
        }

        $id = $this->input->post('id');

        $data = [
            'merek_bus'             => $this->input->post('merek_bus'),
            'tipe_bus'              => $this->input->post('tipe_bus'),
            'kelas_bus'             => $this->input->post('kelas_bus'),
            'nomor_seri_bus'        => $this->input->post('nomor_seri_bus'),
            'koefisien_muai_bahan'  => $this->input->post('koefisien_muai_bahan'),
            'kapasitas'             => $this->input->post('kapasitas'),
            'koreksi_bus'           => $this->input->post('koreksi_bus'),
            'waktu_tetes'           => $this->input->post('waktu_tetes'),
        ];

        $this->model_standar->update($id, $data);
        $this->session->set_flashdata('success', 'Data standar berhasil diperbarui');
        redirect('tata_usaha/standar');
    }

    public function delete() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
        }

        $this->model_standar->delete($id);
        $this->session->set_flashdata('success', 'Standar berhasil dihapus');
        redirect('tata_usaha/standar');
    }
}