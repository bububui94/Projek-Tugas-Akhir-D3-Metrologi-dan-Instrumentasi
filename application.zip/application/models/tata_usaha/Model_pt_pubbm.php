<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_pt_pubbm extends CI_Model {
    public function add($data) {
        return $this->db->insert('m_pt_pubbm', $data);
    }

    public function read() {
        $this->db->select('m_pt_pubbm.*, COUNT(m_spbu.id) as jumlah_spbu');
        $this->db->from('m_pt_pubbm');
        $this->db->join('m_spbu', 'm_spbu.perusahaan_id = m_pt_pubbm.id', 'left');
        $this->db->group_by('m_pt_pubbm.id');
        return $this->db->get();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('m_pt_pubbm', $data);
    }

    public function delete($id) {
        return $this->db->delete('m_pt_pubbm', ['id' => $id]);
    }

    public function count() {
        return $this->db->count_all('m_pt_pubbm');
    }
}