<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_auth extends CI_Model {
    public function get_by_username($username) {
        return $this->db->where('username', $username)
                        ->get('m_users')
                        ->row();
    }
}