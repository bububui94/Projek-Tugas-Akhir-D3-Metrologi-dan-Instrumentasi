<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Cerapan Meter Air <?= $cerapan->nomor_seri ?></title>

    <link rel="stylesheet" href="<?= base_url('assets/css/cerapan_meter_air_pdf.css') ?>">
</head>

<body>
    <img class="kop-surat" src="<?= base_url('assets/img/Kop_Surat_Akmet.png') ?>" alt="kop_akmet">
    <hr>
    <br class="spacing-0">
    <table>
        <tr>
            <td class="col-12"></td>
            <td class="col-30"></td>
            <td class="col-25"></td>
            <td></td>
        </tr>
        <tr>
            <td>Pemilik</td>
            <td colspan="3">: <?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td colspan="3">: <?= $perusahaan->alamat ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td colspan="2" class="bold">DATA METER AIR</td>
            <td colspan="2" class="bold">DATA BEJANA UKUR STANDAR</td>
        </tr>
        <tr>
            <td>Merek</td>
            <td>: <?= $meter_air->merek ?></td>
            <td>Merek</td>
            <td>: <?= $q1_standar->merek_bus ?></td>
        </tr>
        <tr>
            <td>Model/tipe</td>
            <td>: <?= $meter_air->model_tipe ?></td>
            <td>Tipe/No. Seri</td>
            <td>: <?= $q1_standar->tipe_bus ?> / <?= $q1_standar->nomor_seri_bus ?></td>
        </tr>
        <tr>
            <td>No. Seri</td>
            <td>: <?= $meter_air->nomor_seri ?></td>
            <td>Volume Nominal</td>
            <td>: <?= $q1_standar->kapasitas ?> L</td>
        </tr>
        <tr>
            <td>Pemasangan</td>
            <td>: <?= $meter_air->pemasangan ?></td>
            <td>Koefisien Muai Bahan (<span style="font-family: 'DejaVu Serif'; font-size: 10pt;">α</span>)</td>
            <td>: <?= $q1_standar->koefisien_muai_bahan ?> /°C</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td>Koreksi (C<span class="subscript">b</span>)</td>
            <td>: <?= $q1_standar->koreksi_bus ?> L</td>
        </tr>
        <tr>
            <td colspan="2" class="bold">CAIRAN UJI</td>
            <td>Waktu Tetes</td>
            <td>: <?= $q1_standar->waktu_tetes ?> sekon</td>
        </tr>
        <tr>
            <td>Jenis Cairan</td>
            <td>: <?= $cerapan->jenis_cairan ?></td>
        </tr>
    </table>
    <br>
    <table class="bordered">
        <tr class="no-border">
            <td class="col-5"></td>
            <td class="col-35"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
        </tr>
        <tr class="bold">
            <td rowspan="2" class="vertical-align">No.</td>
            <td rowspan="2" class="vertical-align">Uraian</td>
            <td rowspan="2" class="vertical-align">Satuan</td>
            <td colspan="3">Pengujian ke:</td>
        </tr>
        <tr class="bold">
            <td>1</td>
            <td>2</td>
            <td>3</td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Laju Alir Minimum (Q<span class="subscript">1</span>)</td>
            <td class="bold">(m³/h)</td>
            <td colspan="3"><?= $meter_air->laju_alir_minimum ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Bejana Ukur Standar</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>1</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">b1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vb1_r1 ?></td>
            <td><?= $cerapan->q1_vb1_r2 ?></td>
            <td><?= $cerapan->q1_vb1_r3 ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">b2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vb2_r1 ?></td>
            <td><?= $cerapan->q1_vb2_r2 ?></td>
            <td><?= $cerapan->q1_vb2_r3 ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">b</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vb_r1 ?></td>
            <td><?= $cerapan->q1_vb_r2 ?></td>
            <td><?= $cerapan->q1_vb_r3 ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Meter Air</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>4</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">m1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vm1_r1 ?></td>
            <td><?= $cerapan->q1_vm1_r2 ?></td>
            <td><?= $cerapan->q1_vm1_r3 ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">m2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vm2_r1 ?></td>
            <td><?= $cerapan->q1_vm2_r2 ?></td>
            <td><?= $cerapan->q1_vm2_r3 ?></td>
        </tr>
        <tr>
            <td>6</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">m</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q1_vm_r1 ?></td>
            <td><?= $cerapan->q1_vm_r2 ?></td>
            <td><?= $cerapan->q1_vm_r3 ?></td>
        </tr>
        <tr>
            <td>7</td>
            <td class="left-align">Suhu (T<span class="subscript">m</span>)</td>
            <td>°C</td>
            <td><?= $cerapan->q1_tm_r1 ?></td>
            <td><?= $cerapan->q1_tm_r2 ?></td>
            <td><?= $cerapan->q1_tm_r3 ?></td>
        </tr>
        <tr>
            <td class="vertical-align">8</td>
            <td class="left-align vertical-align">Tekanan (P<span class="subscript">m</span>)</td>
            <td class="vertical-align">kPa <span style="text-decoration: line-through;">atau kg/cm²</span></td>
            <td class="vertical-align"><?= $cerapan->q1_pm_r1 ?></td>
            <td class="vertical-align"><?= $cerapan->q1_pm_r2 ?></td>
            <td class="vertical-align"><?= $cerapan->q1_pm_r3 ?></td>
        </tr>
        <tr>
            <td>9</td>
            <td class="left-align">Kesalahan Penunjukkan Meter Air</td>
            <td>%</td>
            <td><?= $cerapan->q1_error_r1 == -0 ? 0 : $cerapan->q1_error_r1 ?></td>
            <td><?= $cerapan->q1_error_r2 == -0 ? 0 : $cerapan->q1_error_r2 ?></td>
            <td><?= $cerapan->q1_error_r3 == -0 ? 0 : $cerapan->q1_error_r3 ?></td>
        </tr>
        <tr>
            <td>10</td>
            <td class="left-align">Kesalahan Penunjukkan Rata-Rata</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q1_average_error == -0 ? 0 : $cerapan->q1_average_error ?></td>
        </tr>
        <tr>
            <td>11</td>
            <td class="left-align">BKD</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q1_bkd ?></td>
        </tr>
        <tr>
            <td>12</td>
            <td class="left-align">Ketidaktetapan</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q1_repeat == -0 ? 0 : $cerapan->q1_repeat ?></td>
        </tr>
        <tr>
            <td>13</td>
            <td class="left-align">Kepekaan (Khusus DN = 15 mm)</td>
            <td>L/min</td>
            <td colspan="3"><?= $cerapan->q1_sensitivity == -100 ? '-' : $cerapan->q1_sensitivity; ?></td>
        </tr>
        <tr>
            <td colspan="6" class="left-align justify">Keterangan: <?= $cerapan->q1_keterangan ?></td>
        </tr>
        <tr>
            <td colspan="2" class="left-align bold sah">Sah <span style="font-family: DejaVu Sans;"> <?= $cerapan->q1_sah_batal == 'SAH' ? '☑' : '☐'; ?> </span></td>
            <td colspan="4" class="left-align bold batal">Batal <span style="font-family: DejaVu Sans;"> <?= $cerapan->q1_sah_batal == 'BATAL' ? '☑' : '☐'; ?> </span></td>
        </tr>
        <tr class="no-border">
            <td colspan="6"><br></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Sumedang, <?= indo_date($surat_tugas->tanggal_pelaksanaan) ?></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Petugas</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3"><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Chasien.jpg') ?>" alt="ttd"></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">( <?= $ketua_pelaksana->nama_lengkap ?> )</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">NIP. <?= $ketua_pelaksana->nip ?></td>
        </tr>
    </table>

    <div class="page-break"></div>

    <img class="kop-surat" src="<?= base_url('assets/img/Kop_Surat_Akmet.png') ?>" alt="kop_akmet">
    <hr>
    <br class="spacing-0">
    <table>
        <tr>
            <td class="col-12"></td>
            <td class="col-30"></td>
            <td class="col-25"></td>
            <td></td>
        </tr>
        <tr>
            <td>Pemilik</td>
            <td colspan="3">: <?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td colspan="3">: <?= $perusahaan->alamat ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td colspan="2" class="bold">DATA METER AIR</td>
            <td colspan="2" class="bold">DATA BEJANA UKUR STANDAR</td>
        </tr>
        <tr>
            <td>Merek</td>
            <td>: <?= $meter_air->merek ?></td>
            <td>Merek</td>
            <td>: <?= $q2_standar->merek_bus ?></td>
        </tr>
        <tr>
            <td>Model/tipe</td>
            <td>: <?= $meter_air->model_tipe ?></td>
            <td>Tipe/No. Seri</td>
            <td>: <?= $q2_standar->tipe_bus ?> / <?= $q2_standar->nomor_seri_bus ?></td>
        </tr>
        <tr>
            <td>No. Seri</td>
            <td>: <?= $meter_air->nomor_seri ?></td>
            <td>Volume Nominal</td>
            <td>: <?= $q2_standar->kapasitas ?> L</td>
        </tr>
        <tr>
            <td>Pemasangan</td>
            <td>: <?= $meter_air->pemasangan ?></td>
            <td>Koefisien Muai Bahan (<span style="font-family: 'DejaVu Serif'; font-size: 10pt;">α</span>)</td>
            <td>: <?= $q2_standar->koefisien_muai_bahan ?> /°C</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td>Koreksi (C<span class="subscript">b</span>)</td>
            <td>: <?= $q2_standar->koreksi_bus ?> L</td>
        </tr>
        <tr>
            <td colspan="2" class="bold">CAIRAN UJI</td>
            <td>Waktu Tetes</td>
            <td>: <?= $q2_standar->waktu_tetes ?> sekon</td>
        </tr>
        <tr>
            <td>Jenis Cairan</td>
            <td>: <?= $cerapan->jenis_cairan ?></td>
        </tr>
    </table>
    <br>
    <table class="bordered">
        <tr class="no-border">
            <td class="col-5"></td>
            <td class="col-35"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
        </tr>
        <tr class="bold">
            <td rowspan="2" class="vertical-align">No.</td>
            <td rowspan="2" class="vertical-align">Uraian</td>
            <td rowspan="2" class="vertical-align">Satuan</td>
            <td colspan="3">Pengujian ke:</td>
        </tr>
        <tr class="bold">
            <td>1</td>
            <td>2</td>
            <td>3</td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Laju Alir Transisi (Q<span class="subscript">2</span>)</td>
            <td class="bold">(m³/h)</td>
            <td colspan="3"><?= $meter_air->laju_alir_transisi ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Bejana Ukur Standar</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>1</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">b1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vb1_r1 ?></td>
            <td><?= $cerapan->q2_vb1_r2 ?></td>
            <td><?= $cerapan->q2_vb1_r3 ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">b2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vb2_r1 ?></td>
            <td><?= $cerapan->q2_vb2_r2 ?></td>
            <td><?= $cerapan->q2_vb2_r3 ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">b</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vb_r1 ?></td>
            <td><?= $cerapan->q2_vb_r2 ?></td>
            <td><?= $cerapan->q2_vb_r3 ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Meter Air</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>4</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">m1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vm1_r1 ?></td>
            <td><?= $cerapan->q2_vm1_r2 ?></td>
            <td><?= $cerapan->q2_vm1_r3 ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">m2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vm2_r1 ?></td>
            <td><?= $cerapan->q2_vm2_r2 ?></td>
            <td><?= $cerapan->q2_vm2_r3 ?></td>
        </tr>
        <tr>
            <td>6</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">m</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q2_vm_r1 ?></td>
            <td><?= $cerapan->q2_vm_r2 ?></td>
            <td><?= $cerapan->q2_vm_r3 ?></td>
        </tr>
        <tr>
            <td>7</td>
            <td class="left-align">Suhu (T<span class="subscript">m</span>)</td>
            <td>°C</td>
            <td><?= $cerapan->q2_tm_r1 ?></td>
            <td><?= $cerapan->q2_tm_r2 ?></td>
            <td><?= $cerapan->q2_tm_r3 ?></td>
        </tr>
        <tr>
            <td class="vertical-align">8</td>
            <td class="left-align vertical-align">Tekanan (P<span class="subscript">m</span>)</td>
            <td class="vertical-align">kPa <span style="text-decoration: line-through;">atau kg/cm²</span></td>
            <td class="vertical-align"><?= $cerapan->q2_pm_r1 ?></td>
            <td class="vertical-align"><?= $cerapan->q2_pm_r2 ?></td>
            <td class="vertical-align"><?= $cerapan->q2_pm_r3 ?></td>
        </tr>
        <tr>
            <td>9</td>
            <td class="left-align">Kesalahan Penunjukkan Meter Air</td>
            <td>%</td>
            <td><?= $cerapan->q2_error_r1 == -0 ? 0 : $cerapan->q2_error_r1 ?></td>
            <td><?= $cerapan->q2_error_r2 == -0 ? 0 : $cerapan->q2_error_r2 ?></td>
            <td><?= $cerapan->q2_error_r3 == -0 ? 0 : $cerapan->q2_error_r3 ?></td>
        </tr>
        <tr>
            <td>10</td>
            <td class="left-align">Kesalahan Penunjukkan Rata-Rata</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q2_average_error == -0 ? 0 : $cerapan->q2_average_error ?></td>
        </tr>
        <tr>
            <td>11</td>
            <td class="left-align">BKD</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q2_bkd ?></td>
        </tr>
        <tr>
            <td>12</td>
            <td class="left-align">Ketidaktetapan</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q2_repeat == -0 ? 0 : $cerapan->q2_repeat ?></td>
        </tr>
        <tr>
            <td>13</td>
            <td class="left-align">Kepekaan (Khusus DN = 15 mm)</td>
            <td>L/min</td>
            <td colspan="3">-</td>
        </tr>
        <tr>
            <td colspan="6" class="left-align justify">Keterangan: <?= $cerapan->q2_keterangan ?></td>
        </tr>
        <tr>
            <td colspan="2" class="left-align bold sah">Sah <span style="font-family: DejaVu Sans;"> <?= $cerapan->q2_sah_batal == 'SAH' ? '☑' : '☐'; ?> </span></td>
            <td colspan="4" class="left-align bold batal">Batal <span style="font-family: DejaVu Sans;"> <?= $cerapan->q2_sah_batal == 'BATAL' ? '☑' : '☐'; ?> </span></td>
        </tr>
        <tr class="no-border">
            <td colspan="6"><br></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Sumedang, <?= indo_date($surat_tugas->tanggal_pelaksanaan) ?></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Petugas</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3"><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Chasien.jpg') ?>" alt="ttd"></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">( <?= $ketua_pelaksana->nama_lengkap ?> )</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">NIP. <?= $ketua_pelaksana->nip ?></td>
        </tr>
    </table>

    <div class="page-break"></div>

    <img class="kop-surat" src="<?= base_url('assets/img/Kop_Surat_Akmet.png') ?>" alt="kop_akmet">
    <hr>
    <br class="spacing-0">
    <table>
        <tr>
            <td class="col-12"></td>
            <td class="col-30"></td>
            <td class="col-25"></td>
            <td></td>
        </tr>
        <tr>
            <td>Pemilik</td>
            <td colspan="3">: <?= $perusahaan->nama_pt ?></td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td colspan="3">: <?= $perusahaan->alamat ?></td>
        </tr>
        <tr>
            <td><br></td>
        </tr>
        <tr>
            <td colspan="2" class="bold">DATA METER AIR</td>
            <td colspan="2" class="bold">DATA BEJANA UKUR STANDAR</td>
        </tr>
        <tr>
            <td>Merek</td>
            <td>: <?= $meter_air->merek ?></td>
            <td>Merek</td>
            <td>: <?= $q3_standar->merek_bus ?></td>
        </tr>
        <tr>
            <td>Model/tipe</td>
            <td>: <?= $meter_air->model_tipe ?></td>
            <td>Tipe/No. Seri</td>
            <td>: <?= $q3_standar->tipe_bus ?> / <?= $q3_standar->nomor_seri_bus ?></td>
        </tr>
        <tr>
            <td>No. Seri</td>
            <td>: <?= $meter_air->nomor_seri ?></td>
            <td>Volume Nominal</td>
            <td>: <?= $q3_standar->kapasitas ?> L</td>
        </tr>
        <tr>
            <td>Pemasangan</td>
            <td>: <?= $meter_air->pemasangan ?></td>
            <td>Koefisien Muai Bahan (<span style="font-family: 'DejaVu Serif'; font-size: 10pt;">α</span>)</td>
            <td>: <?= $q3_standar->koefisien_muai_bahan ?> /°C</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td>Koreksi (C<span class="subscript">b</span>)</td>
            <td>: <?= $q3_standar->koreksi_bus ?> L</td>
        </tr>
        <tr>
            <td colspan="2" class="bold">CAIRAN UJI</td>
            <td>Waktu Tetes</td>
            <td>: <?= $q3_standar->waktu_tetes ?> sekon</td>
        </tr>
        <tr>
            <td>Jenis Cairan</td>
            <td>: <?= $cerapan->jenis_cairan ?></td>
        </tr>
    </table>
    <br>
    <table class="bordered">
        <tr class="no-border">
            <td class="col-5"></td>
            <td class="col-35"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
            <td class="col-15"></td>
        </tr>
        <tr class="bold">
            <td rowspan="2" class="vertical-align">No.</td>
            <td rowspan="2" class="vertical-align">Uraian</td>
            <td rowspan="2" class="vertical-align">Satuan</td>
            <td colspan="3">Pengujian ke:</td>
        </tr>
        <tr class="bold">
            <td>1</td>
            <td>2</td>
            <td>3</td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Laju Alir Nominal (Q<span class="subscript">3</span>)</td>
            <td class="bold">(m³/h)</td>
            <td colspan="3"><?= $meter_air->laju_alir_nominal ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Bejana Ukur Standar</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>1</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">b1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vb1_r1 ?></td>
            <td><?= $cerapan->q3_vb1_r2 ?></td>
            <td><?= $cerapan->q3_vb1_r3 ?></td>
        </tr>
        <tr>
            <td>2</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">b2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vb2_r1 ?></td>
            <td><?= $cerapan->q3_vb2_r2 ?></td>
            <td><?= $cerapan->q3_vb2_r3 ?></td>
        </tr>
        <tr>
            <td>3</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">b</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vb_r1 ?></td>
            <td><?= $cerapan->q3_vb_r2 ?></td>
            <td><?= $cerapan->q3_vb_r3 ?></td>
        </tr>
        <tr>
            <td></td>
            <td class="bold left-align">Meter Air</td>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td>4</td>
            <td class="left-align">Pembacaan Awal (V<span class="subscript">m1</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vm1_r1 ?></td>
            <td><?= $cerapan->q3_vm1_r2 ?></td>
            <td><?= $cerapan->q3_vm1_r3 ?></td>
        </tr>
        <tr>
            <td>5</td>
            <td class="left-align">Pembacaan Akhir (V<span class="subscript">m2</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vm2_r1 ?></td>
            <td><?= $cerapan->q3_vm2_r2 ?></td>
            <td><?= $cerapan->q3_vm2_r3 ?></td>
        </tr>
        <tr>
            <td>6</td>
            <td class="left-align">Volume Yang Diukur (V<span class="subscript">m</span>)</td>
            <td>L</td>
            <td><?= $cerapan->q3_vm_r1 ?></td>
            <td><?= $cerapan->q3_vm_r2 ?></td>
            <td><?= $cerapan->q3_vm_r3 ?></td>
        </tr>
        <tr>
            <td>7</td>
            <td class="left-align">Suhu (T<span class="subscript">m</span>)</td>
            <td>°C</td>
            <td><?= $cerapan->q3_tm_r1 ?></td>
            <td><?= $cerapan->q3_tm_r2 ?></td>
            <td><?= $cerapan->q3_tm_r3 ?></td>
        </tr>
        <tr>
            <td class="vertical-align">8</td>
            <td class="left-align vertical-align">Tekanan (P<span class="subscript">m</span>)</td>
            <td class="vertical-align">kPa <span style="text-decoration: line-through;">atau kg/cm²</span></td>
            <td class="vertical-align"><?= $cerapan->q3_pm_r1 ?></td>
            <td class="vertical-align"><?= $cerapan->q3_pm_r2 ?></td>
            <td class="vertical-align"><?= $cerapan->q3_pm_r3 ?></td>
        </tr>
        <tr>
            <td>9</td>
            <td class="left-align">Kesalahan Penunjukkan Meter Air</td>
            <td>%</td>
            <td><?= $cerapan->q3_error_r1 == -0 ? 0 : $cerapan->q3_error_r1 ?></td>
            <td><?= $cerapan->q3_error_r2 == -0 ? 0 : $cerapan->q3_error_r2 ?></td>
            <td><?= $cerapan->q3_error_r3 == -0 ? 0 : $cerapan->q3_error_r3 ?></td>
        </tr>
        <tr>
            <td>10</td>
            <td class="left-align">Kesalahan Penunjukkan Rata-Rata</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q3_average_error == -0 ? 0 : $cerapan->q3_average_error ?></td>
        </tr>
        <tr>
            <td>11</td>
            <td class="left-align">BKD</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q3_bkd ?></td>
        </tr>
        <tr>
            <td>12</td>
            <td class="left-align">Ketidaktetapan</td>
            <td>%</td>
            <td colspan="3"><?= $cerapan->q3_repeat == -0 ? 0 : $cerapan->q3_repeat ?></td>
        </tr>
        <tr>
            <td>13</td>
            <td class="left-align">Kepekaan (Khusus DN = 15 mm)</td>
            <td>L/min</td>
            <td colspan="3">-</td>
        </tr>
        <tr>
            <td colspan="6" class="left-align justify">Keterangan: <?= $cerapan->q3_keterangan ?></td>
        </tr>
        <tr>
            <td colspan="2" class="left-align bold sah">Sah <span style="font-family: DejaVu Sans;"> <?= $cerapan->q3_sah_batal == 'SAH' ? '☑' : '☐'; ?> </span></td>
            <td colspan="4" class="left-align bold batal">Batal <span style="font-family: DejaVu Sans;"> <?= $cerapan->q3_sah_batal == 'BATAL' ? '☑' : '☐'; ?> </span></td>
        </tr>
        <tr class="no-border">
            <td colspan="6"><br></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Sumedang, <?= indo_date($surat_tugas->tanggal_pelaksanaan) ?></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">Petugas</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3"><img class="img-fit" src="<?= base_url('assets/img/Tanda_Tangan_Chasien.jpg') ?>" alt="ttd"></td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">( <?= $ketua_pelaksana->nama_lengkap ?> )</td>
        </tr>
        <tr class="no-border">
            <td colspan="3"></td>
            <td colspan="3">NIP. <?= $ketua_pelaksana->nip ?></td>
        </tr>
    </table>
</body>