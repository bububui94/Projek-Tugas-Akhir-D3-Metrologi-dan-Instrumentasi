<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cerapan_meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('kepala_uml/model_st_meter_air');
        $this->load->model('penera/model_cerapan_meter_air');
        $this->load->model('tata_usaha/model_standar');
        $this->load->model('tata_usaha/model_pt_meter_air');
        $this->load->model('tata_usaha/model_meter_air');
        $this->load->model('tata_usaha/model_pegawai');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 3) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $id_pegawai = $this->session->userdata('id_pegawai');
        $data['cerapan'] = $this->model_cerapan_meter_air->read_by_ketua($id_pegawai)->result();
        
        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/cerapan/list_cerapan_meter_air', $data);
        $this->load->view('templates_penera/footer');
    }

    public function edit($id) {
        $data['cerapan'] = $this->model_cerapan_meter_air->get_by_id($id)->row();
        $data['standar'] = $this->model_standar->read()->result();

        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/cerapan/edit_cerapan_meter_air', $data);
        $this->load->view('templates_penera/footer');
    }

    public function update($id) {
        $this->form_validation->set_rules('jenis_cairan', 'Jenis_Cairan', 'trim');

        $this->form_validation->set_rules('q1_standar', 'Q1_Standar', 'integer');
        $this->form_validation->set_rules('q1_vb1_r1', 'Q1_Vb1_R1', 'numeric');
        $this->form_validation->set_rules('q1_vb1_r2', 'Q1_Vb1_R2', 'numeric');
        $this->form_validation->set_rules('q1_vb1_r3', 'Q1_Vb1_R3', 'numeric');
        $this->form_validation->set_rules('q1_vb2_r1', 'Q1_Vb2_R1', 'numeric');
        $this->form_validation->set_rules('q1_vb2_r2', 'Q1_Vb2_R2', 'numeric');
        $this->form_validation->set_rules('q1_vb2_r3', 'Q1_Vb2_R3', 'numeric');
        $this->form_validation->set_rules('q1_vb_r1', 'Q1_Vb_R1', 'numeric');
        $this->form_validation->set_rules('q1_vb_r2', 'Q1_Vb_R2', 'numeric');
        $this->form_validation->set_rules('q1_vb_r3', 'Q1_Vb_R3', 'numeric');
        $this->form_validation->set_rules('q1_vm1_r1', 'Q1_Vm1_R1', 'numeric');
        $this->form_validation->set_rules('q1_vm1_r2', 'Q1_Vm1_R2', 'numeric');
        $this->form_validation->set_rules('q1_vm1_r3', 'Q1_Vm1_R3', 'numeric');
        $this->form_validation->set_rules('q1_vm2_r1', 'Q1_Vm2_R1', 'numeric');
        $this->form_validation->set_rules('q1_vm2_r2', 'Q1_Vm2_R2', 'numeric');
        $this->form_validation->set_rules('q1_vm2_r3', 'Q1_Vm2_R3', 'numeric');
        $this->form_validation->set_rules('q1_vm_r1', 'Q1_Vm_R1', 'numeric');
        $this->form_validation->set_rules('q1_vm_r2', 'Q1_Vm_R2', 'numeric');
        $this->form_validation->set_rules('q1_vm_r3', 'Q1_Vm_R3', 'numeric');
        $this->form_validation->set_rules('q1_tm_r1', 'Q1_Tm_R1', 'numeric');
        $this->form_validation->set_rules('q1_tm_r2', 'Q1_Tm_R2', 'numeric');
        $this->form_validation->set_rules('q1_tm_r3', 'Q1_Tm_R3', 'numeric');
        $this->form_validation->set_rules('q1_pm_r1', 'Q1_Pm_R1', 'numeric');
        $this->form_validation->set_rules('q1_pm_r2', 'Q1_Pm_R2', 'numeric');
        $this->form_validation->set_rules('q1_pm_r3', 'Q1_Pm_R3', 'numeric');
        $this->form_validation->set_rules('q1_error_r1', 'Q1_Error_R1', 'numeric');
        $this->form_validation->set_rules('q1_error_r2', 'Q1_Error_R2', 'numeric');
        $this->form_validation->set_rules('q1_error_r3', 'Q1_Error_R3', 'numeric');
        $this->form_validation->set_rules('q1_average_error', 'Q1_Average_Error', 'numeric');
        $this->form_validation->set_rules('q1_bkd', 'Q1_BKD', 'numeric');
        $this->form_validation->set_rules('q1_repeat', 'Q1_Repeat', 'numeric');
        $this->form_validation->set_rules('q1_sensitivity', 'Q1_Sensitivity', 'numeric');
        $this->form_validation->set_rules('q1_keterangan', 'Q1_Keterangan', 'trim');
        $this->form_validation->set_rules('q1_sah_batal', 'Q1_Sah_Batal', 'trim');

        $this->form_validation->set_rules('q2_standar', 'Q2_Standar', 'integer');
        $this->form_validation->set_rules('q2_vb1_r1', 'Q2_Vb1_R1', 'numeric');
        $this->form_validation->set_rules('q2_vb1_r2', 'Q2_Vb1_R2', 'numeric');
        $this->form_validation->set_rules('q2_vb1_r3', 'Q2_Vb1_R3', 'numeric');
        $this->form_validation->set_rules('q2_vb2_r1', 'Q2_Vb2_R1', 'numeric');
        $this->form_validation->set_rules('q2_vb2_r2', 'Q2_Vb2_R2', 'numeric');
        $this->form_validation->set_rules('q2_vb2_r3', 'Q2_Vb2_R3', 'numeric');
        $this->form_validation->set_rules('q2_vb_r1', 'Q2_Vb_R1', 'numeric');
        $this->form_validation->set_rules('q2_vb_r2', 'Q2_Vb_R2', 'numeric');
        $this->form_validation->set_rules('q2_vb_r3', 'Q2_Vb_R3', 'numeric');
        $this->form_validation->set_rules('q2_vm1_r1', 'Q2_Vm1_R1', 'numeric');
        $this->form_validation->set_rules('q2_vm1_r2', 'Q2_Vm1_R2', 'numeric');
        $this->form_validation->set_rules('q2_vm1_r3', 'Q2_Vm1_R3', 'numeric');
        $this->form_validation->set_rules('q2_vm2_r1', 'Q2_Vm2_R1', 'numeric');
        $this->form_validation->set_rules('q2_vm2_r2', 'Q2_Vm2_R2', 'numeric');
        $this->form_validation->set_rules('q2_vm2_r3', 'Q2_Vm2_R3', 'numeric');
        $this->form_validation->set_rules('q2_vm_r1', 'Q2_Vm_R1', 'numeric');
        $this->form_validation->set_rules('q2_vm_r2', 'Q2_Vm_R2', 'numeric');
        $this->form_validation->set_rules('q2_vm_r3', 'Q2_Vm_R3', 'numeric');
        $this->form_validation->set_rules('q2_tm_r1', 'Q2_Tm_R1', 'numeric');
        $this->form_validation->set_rules('q2_tm_r2', 'Q2_Tm_R2', 'numeric');
        $this->form_validation->set_rules('q2_tm_r3', 'Q2_Tm_R3', 'numeric');
        $this->form_validation->set_rules('q2_pm_r1', 'Q2_Pm_R1', 'numeric');
        $this->form_validation->set_rules('q2_pm_r2', 'Q2_Pm_R2', 'numeric');
        $this->form_validation->set_rules('q2_pm_r3', 'Q2_Pm_R3', 'numeric');
        $this->form_validation->set_rules('q2_error_r1', 'Q2_Error_R1', 'numeric');
        $this->form_validation->set_rules('q2_error_r2', 'Q2_Error_R2', 'numeric');
        $this->form_validation->set_rules('q2_error_r3', 'Q2_Error_R3', 'numeric');
        $this->form_validation->set_rules('q2_average_error', 'Q2_Average_Error', 'numeric');
        $this->form_validation->set_rules('q2_bkd', 'Q2_BKD', 'numeric');
        $this->form_validation->set_rules('q2_repeat', 'Q2_Repeat', 'numeric');
        $this->form_validation->set_rules('q2_keterangan', 'Q2_Keterangan', 'trim');
        $this->form_validation->set_rules('q2_sah_batal', 'Q2_Sah_Batal', 'trim');

        $this->form_validation->set_rules('q3_standar', 'Q3_Standar', 'integer');
        $this->form_validation->set_rules('q3_vb1_r1', 'Q3_Vb1_R1', 'numeric');
        $this->form_validation->set_rules('q3_vb1_r2', 'Q3_Vb1_R2', 'numeric');
        $this->form_validation->set_rules('q3_vb1_r3', 'Q3_Vb1_R3', 'numeric');
        $this->form_validation->set_rules('q3_vb2_r1', 'Q3_Vb2_R1', 'numeric');
        $this->form_validation->set_rules('q3_vb2_r2', 'Q3_Vb2_R2', 'numeric');
        $this->form_validation->set_rules('q3_vb2_r3', 'Q3_Vb2_R3', 'numeric');
        $this->form_validation->set_rules('q3_vb_r1', 'Q3_Vb_R1', 'numeric');
        $this->form_validation->set_rules('q3_vb_r2', 'Q3_Vb_R2', 'numeric');
        $this->form_validation->set_rules('q3_vb_r3', 'Q3_Vb_R3', 'numeric');
        $this->form_validation->set_rules('q3_vm1_r1', 'Q3_Vm1_R1', 'numeric');
        $this->form_validation->set_rules('q3_vm1_r2', 'Q3_Vm1_R2', 'numeric');
        $this->form_validation->set_rules('q3_vm1_r3', 'Q3_Vm1_R3', 'numeric');
        $this->form_validation->set_rules('q3_vm2_r1', 'Q3_Vm2_R1', 'numeric');
        $this->form_validation->set_rules('q3_vm2_r2', 'Q3_Vm2_R2', 'numeric');
        $this->form_validation->set_rules('q3_vm2_r3', 'Q3_Vm2_R3', 'numeric');
        $this->form_validation->set_rules('q3_vm_r1', 'Q3_Vm_R1', 'numeric');
        $this->form_validation->set_rules('q3_vm_r2', 'Q3_Vm_R2', 'numeric');
        $this->form_validation->set_rules('q3_vm_r3', 'Q3_Vm_R3', 'numeric');
        $this->form_validation->set_rules('q3_tm_r1', 'Q3_Tm_R1', 'numeric');
        $this->form_validation->set_rules('q3_tm_r2', 'Q3_Tm_R2', 'numeric');
        $this->form_validation->set_rules('q3_tm_r3', 'Q3_Tm_R3', 'numeric');
        $this->form_validation->set_rules('q3_pm_r1', 'Q3_Pm_R1', 'numeric');
        $this->form_validation->set_rules('q3_pm_r2', 'Q3_Pm_R2', 'numeric');
        $this->form_validation->set_rules('q3_pm_r3', 'Q3_Pm_R3', 'numeric');
        $this->form_validation->set_rules('q3_error_r1', 'Q3_Error_R1', 'numeric');
        $this->form_validation->set_rules('q3_error_r2', 'Q3_Error_R2', 'numeric');
        $this->form_validation->set_rules('q3_error_r3', 'Q3_Error_R3', 'numeric');
        $this->form_validation->set_rules('q3_average_error', 'Q3_Average_Error', 'numeric');
        $this->form_validation->set_rules('q3_bkd', 'Q3_BKD', 'numeric');
        $this->form_validation->set_rules('q3_repeat', 'Q3_Repeat', 'numeric');
        $this->form_validation->set_rules('q3_keterangan', 'Q3_Keterangan', 'trim');
        $this->form_validation->set_rules('q3_sah_batal', 'Q3_Sah_Batal', 'trim');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('penera/cerapan_meter_air/edit/' . $id);
            return;
        }

        $data = [
            'jenis_cairan'     => $this->input->post('jenis_cairan'),

            'q1_standar'       => $this->input->post('q1_standar'),
            'q1_vb1_r1'        => $this->input->post('q1_vb1_r1'),
            'q1_vb1_r2'        => $this->input->post('q1_vb1_r2'),
            'q1_vb1_r3'        => $this->input->post('q1_vb1_r3'),
            'q1_vb2_r1'        => $this->input->post('q1_vb2_r1'),
            'q1_vb2_r2'        => $this->input->post('q1_vb2_r2'),
            'q1_vb2_r3'        => $this->input->post('q1_vb2_r3'),
            'q1_vb_r1'         => $this->input->post('q1_vb_r1'),
            'q1_vb_r2'         => $this->input->post('q1_vb_r2'),
            'q1_vb_r3'         => $this->input->post('q1_vb_r3'),
            'q1_vm1_r1'        => $this->input->post('q1_vm1_r1'),
            'q1_vm1_r2'        => $this->input->post('q1_vm1_r2'),
            'q1_vm1_r3'        => $this->input->post('q1_vm1_r3'),
            'q1_vm2_r1'        => $this->input->post('q1_vm2_r1'),
            'q1_vm2_r2'        => $this->input->post('q1_vm2_r2'),
            'q1_vm2_r3'        => $this->input->post('q1_vm2_r3'),
            'q1_vm_r1'         => $this->input->post('q1_vm_r1'),
            'q1_vm_r2'         => $this->input->post('q1_vm_r2'),
            'q1_vm_r3'         => $this->input->post('q1_vm_r3'),
            'q1_tm_r1'         => $this->input->post('q1_tm_r1'),
            'q1_tm_r2'         => $this->input->post('q1_tm_r2'),
            'q1_tm_r3'         => $this->input->post('q1_tm_r3'),
            'q1_pm_r1'         => $this->input->post('q1_pm_r1'),
            'q1_pm_r2'         => $this->input->post('q1_pm_r2'),
            'q1_pm_r3'         => $this->input->post('q1_pm_r3'),
            'q1_error_r1'      => $this->input->post('q1_error_r1'),
            'q1_error_r2'      => $this->input->post('q1_error_r2'),
            'q1_error_r3'      => $this->input->post('q1_error_r3'),
            'q1_average_error' => $this->input->post('q1_average_error'),
            'q1_bkd'           => $this->input->post('q1_bkd'),
            'q1_repeat'        => $this->input->post('q1_repeat'),
            'q1_sensitivity'   => $this->input->post('q1_sensitivity') ?: '-100',
            'q1_keterangan'    => $this->input->post('q1_keterangan'),
            'q1_sah_batal'     => $this->input->post('q1_sah_batal'),

            'q2_standar'       => $this->input->post('q2_standar'),
            'q2_vb1_r1'        => $this->input->post('q2_vb1_r1'),
            'q2_vb1_r2'        => $this->input->post('q2_vb1_r2'),
            'q2_vb1_r3'        => $this->input->post('q2_vb1_r3'),
            'q2_vb2_r1'        => $this->input->post('q2_vb2_r1'),
            'q2_vb2_r2'        => $this->input->post('q2_vb2_r2'),
            'q2_vb2_r3'        => $this->input->post('q2_vb2_r3'),
            'q2_vb_r1'         => $this->input->post('q2_vb_r1'),
            'q2_vb_r2'         => $this->input->post('q2_vb_r2'),
            'q2_vb_r3'         => $this->input->post('q2_vb_r3'),
            'q2_vm1_r1'        => $this->input->post('q2_vm1_r1'),
            'q2_vm1_r2'        => $this->input->post('q2_vm1_r2'),
            'q2_vm1_r3'        => $this->input->post('q2_vm1_r3'),
            'q2_vm2_r1'        => $this->input->post('q2_vm2_r1'),
            'q2_vm2_r2'        => $this->input->post('q2_vm2_r2'),
            'q2_vm2_r3'        => $this->input->post('q2_vm2_r3'),
            'q2_vm_r1'         => $this->input->post('q2_vm_r1'),
            'q2_vm_r2'         => $this->input->post('q2_vm_r2'),
            'q2_vm_r3'         => $this->input->post('q2_vm_r3'),
            'q2_tm_r1'         => $this->input->post('q2_tm_r1'),
            'q2_tm_r2'         => $this->input->post('q2_tm_r2'),
            'q2_tm_r3'         => $this->input->post('q2_tm_r3'),
            'q2_pm_r1'         => $this->input->post('q2_pm_r1'),
            'q2_pm_r2'         => $this->input->post('q2_pm_r2'),
            'q2_pm_r3'         => $this->input->post('q2_pm_r3'),
            'q2_error_r1'      => $this->input->post('q2_error_r1'),
            'q2_error_r2'      => $this->input->post('q2_error_r2'),
            'q2_error_r3'      => $this->input->post('q2_error_r3'),
            'q2_average_error' => $this->input->post('q2_average_error'),
            'q2_bkd'           => $this->input->post('q2_bkd'),
            'q2_repeat'        => $this->input->post('q2_repeat'),
            'q2_keterangan'    => $this->input->post('q2_keterangan'),
            'q2_sah_batal'     => $this->input->post('q2_sah_batal'),

            'q3_standar'       => $this->input->post('q3_standar'),
            'q3_vb1_r1'        => $this->input->post('q3_vb1_r1'),
            'q3_vb1_r2'        => $this->input->post('q3_vb1_r2'),
            'q3_vb1_r3'        => $this->input->post('q3_vb1_r3'),
            'q3_vb2_r1'        => $this->input->post('q3_vb2_r1'),
            'q3_vb2_r2'        => $this->input->post('q3_vb2_r2'),
            'q3_vb2_r3'        => $this->input->post('q3_vb2_r3'),
            'q3_vb_r1'         => $this->input->post('q3_vb_r1'),
            'q3_vb_r2'         => $this->input->post('q3_vb_r2'),
            'q3_vb_r3'         => $this->input->post('q3_vb_r3'),
            'q3_vm1_r1'        => $this->input->post('q3_vm1_r1'),
            'q3_vm1_r2'        => $this->input->post('q3_vm1_r2'),
            'q3_vm1_r3'        => $this->input->post('q3_vm1_r3'),
            'q3_vm2_r1'        => $this->input->post('q3_vm2_r1'),
            'q3_vm2_r2'        => $this->input->post('q3_vm2_r2'),
            'q3_vm2_r3'        => $this->input->post('q3_vm2_r3'),
            'q3_vm_r1'         => $this->input->post('q3_vm_r1'),
            'q3_vm_r2'         => $this->input->post('q3_vm_r2'),
            'q3_vm_r3'         => $this->input->post('q3_vm_r3'),
            'q3_tm_r1'         => $this->input->post('q3_tm_r1'),
            'q3_tm_r2'         => $this->input->post('q3_tm_r2'),
            'q3_tm_r3'         => $this->input->post('q3_tm_r3'),
            'q3_pm_r1'         => $this->input->post('q3_pm_r1'),
            'q3_pm_r2'         => $this->input->post('q3_pm_r2'),
            'q3_pm_r3'         => $this->input->post('q3_pm_r3'),
            'q3_error_r1'      => $this->input->post('q3_error_r1'),
            'q3_error_r2'      => $this->input->post('q3_error_r2'),
            'q3_error_r3'      => $this->input->post('q3_error_r3'),
            'q3_average_error' => $this->input->post('q3_average_error'),
            'q3_bkd'           => $this->input->post('q3_bkd'),
            'q3_repeat'        => $this->input->post('q3_repeat'),
            'q3_keterangan'    => $this->input->post('q3_keterangan'),
            'q3_sah_batal'     => $this->input->post('q3_sah_batal'),
        ];

        foreach ($data as $key => $value) {
            if ($value === '' || $value === null) {
                $data[$key] = null;
            }
        }

        $this->model_cerapan_meter_air->update($id, $data);
        $this->session->set_flashdata('success', 'Data cerapan berhasil diperbarui');
        redirect('penera/cerapan_meter_air');
    }

    public function send() {
        $id = $this->input->post('id');

        if (!$id) {
            show_error('Invalid ID', 400);
            return;
        }

        $this->model_cerapan_meter_air->mark_as_sent($id);
        $this->model_cerapan_meter_air->update_meter_air($id);

        $this->session->set_flashdata('success', 'Cerapan berhasil dikirim ke Kepala UML');
        $this->generate_pdf($id);
        redirect('penera/cerapan_meter_air');
    }

    public function generate_pdf($id) {
        $this->load->library('dompdf_lib');
        $cerapan = $this->model_cerapan_meter_air->get_by_id_cerapan($id);

        if (!$cerapan) {
            show_error("Cerapan Meter Air $cerapan tidak ditemukan", 404);
            return;
        }

        $surat_tugas = $this->model_st_meter_air->get_by_id($cerapan->id_surat_tugas);
        $perusahaan = $this->model_pt_meter_air->get_by_id($cerapan->id_perusahaan);
        $meter_air = $this->model_meter_air->get_by_single_nomor_seri($cerapan->nomor_seri);
        $q1_standar = $this->model_standar->get_by_id($cerapan->q1_standar);
        $q2_standar = $this->model_standar->get_by_id($cerapan->q2_standar);
        $q3_standar = $this->model_standar->get_by_id($cerapan->q3_standar);
        $ketua_pelaksana = $this->model_pegawai->get_by_id($cerapan->id_pegawai);

        $tahun_tera = date('Y', strtotime($surat_tugas->tanggal_pelaksanaan));

        $data = [
            'surat_tugas'       => $surat_tugas,
            'cerapan'           => $cerapan,
            'perusahaan'        => $perusahaan,
            'meter_air'         => $meter_air,
            'q1_standar'        => $q1_standar,
            'q2_standar'        => $q2_standar,
            'q3_standar'        => $q3_standar,
            'ketua_pelaksana'   => $ketua_pelaksana,
        ];

        $html = $this->load->view('generate_pdf/cerapan_meter_air_pdf', $data, true);

        $this->dompdf_lib->loadHtml($html);
        $this->dompdf_lib->setPaper('A4', 'portrait');
        $this->dompdf_lib->render();

        $safe_cerapan = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $cerapan->nomor_seri);
        $filename = 'Cerapan Meter Air ' . $safe_cerapan . ' Tahun ' . $tahun_tera . '.pdf';
        $output = $this->dompdf_lib->output();
        file_put_contents(FCPATH . 'assets/cerapan_meter_air/' . $filename, $output);
    }
}