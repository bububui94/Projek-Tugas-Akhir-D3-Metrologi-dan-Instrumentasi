<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tata_usaha/model_pegawai');
        $this->load->model('tata_usaha/model_users');
        $this->load->model('tata_usaha/model_standar');
        $this->load->model('tata_usaha/model_pt_pubbm');
        $this->load->model('tata_usaha/model_spbu');
        $this->load->model('tata_usaha/model_nozzle');
        $this->load->model('tata_usaha/model_pt_meter_air');
        $this->load->model('tata_usaha/model_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 2) {
            show_error('Unauthorized access');
        }
    }
    public function index() {
        $data ['pegawai'] = $this->model_pegawai->count();
        $data ['user'] = $this->model_users->count();
        $data ['standar'] = $this->model_standar->count();
        $data ['pt_pubbm'] = $this->model_pt_pubbm->count();
        $data ['spbu'] = $this->model_spbu->count();
        $data ['nozzle'] = $this->model_nozzle->count();
        $data ['pt_meter_air'] = $this->model_pt_meter_air->count();
        $data ['meter_air'] = $this->model_meter_air->count();

        $this->load->view('templates_tata_usaha/header');
        $this->load->view('templates_tata_usaha/sidebar');
        $this->load->view('tata_usaha/dashboard', $data);
        $this->load->view('templates_tata_usaha/footer');
    }
}