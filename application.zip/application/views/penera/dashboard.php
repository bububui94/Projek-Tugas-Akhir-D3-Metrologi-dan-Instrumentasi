                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-black"><strong>Pompa Ukur Bahan Bakar Minyak</strong></h1>
                    </div>
                    <div class="row mb-1">
                        <div class="col-xl-6 col-md-6 mb-4">
                            <div class="card shadow h-100 bg-color-2 text-black clickable-card"
                                data-url="<?= base_url('penera/st_pubbm') ?>">
                                <div class="card-body">
                                    <div class="row no-gutters ">
                                        <div class="col mr-1">
                                            <div class="h5 font-weight-bold mb-3">
                                                Jumlah Surat Tugas PUBBM</div>
                                            <div class="h2 mb-0 font-weight-bold" id="jumlahStPubbm"><?= $st_pubbm ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6 mb-4">
                            <div class="card shadow h-100 bg-color-3 text-black clickable-card"
                                data-url="<?= base_url('penera/cerapan_pubbm') ?>">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 font-weight-bold mb-3">
                                                Jumlah Cerapan PUBBM</div>
                                            <div class="h2 mb-0 font-weight-bold" id="jumlahCerapanPubbm"><?= $cerapan_pubbm ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-black"><strong>Meter Air</strong></h1>
                    </div>
                    <div class="row mb-1">
                        <div class="col-xl-6 col-md-6 mb-4">
                            <div class="card shadow h-100 bg-color-4 text-black clickable-card"
                                data-url="<?= base_url('penera/st_meter_air') ?>">
                                <div class="card-body">
                                    <div class="row no-gutters ">
                                        <div class="col mr-1">
                                            <div class="h5 font-weight-bold mb-3">
                                                Jumlah Surat Tugas Meter Air</div>
                                            <div class="h2 mb-0 font-weight-bold" id="jumlahStMeterAir"><?= $st_meter_air ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6 mb-4">
                            <div class="card shadow h-100 bg-color-5 text-black clickable-card"
                                data-url="<?= base_url('penera/cerapan_meter_air') ?>">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="h5 font-weight-bold mb-3">
                                                Jumlah Cerapan Meter Air</div>
                                            <div class="h2 mb-0 font-weight-bold" id="jumlahCerapanMeterAir"><?= $cerapan_meter_air ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    function animateCounter(id, target, duration = 300) {
                        $({
                            countNum: 0
                        }).animate({
                            countNum: target
                        }, {
                            duration: duration,
                            easing: 'swing',
                            step: function() {
                                $('#' + id).text(Math.floor(this.countNum).toLocaleString());
                            },
                            complete: function() {
                                $('#' + id).text(this.countNum.toLocaleString());
                            }
                        });
                    }

                    $(document).ready(function() {
                        animateCounter('jumlahStPubbm', <?= $st_pubbm ?>);
                        animateCounter('jumlahCerapanPubbm', <?= $cerapan_pubbm ?>);
                        animateCounter('jumlahStMeterAir', <?= $st_meter_air ?>);
                        animateCounter('jumlahCerapanMeterAir', <?= $cerapan_meter_air ?>);
                    });
                </script>

                <script>
                    $(document).ready(function() {
                        $('.clickable-card').css('cursor', 'pointer').on('click', function() {
                            const target = $(this).data('url');
                            if (target) {
                                window.location.href = target;
                            }
                        });
                    });
                </script>