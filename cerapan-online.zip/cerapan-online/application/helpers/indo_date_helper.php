<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function indo_date($date) {
    $bulan = [
        'January' => 'Januari',
        'February' => 'Februari',
        'March' => 'Maret',
        'April' => 'April',
        'May' => 'Mei',
        'June' => 'Juni',
        'July' => 'Juli',
        'August' => 'Agustus',
        'September' => 'September',
        'October' => 'Oktober',
        'November' => 'November',
        'December' => 'Desember'
    ];

    $tanggal = date('d', strtotime($date));
    $bulan_en = date('F', strtotime($date));
    $tahun = date('Y', strtotime($date));

    return $tanggal . ' ' . $bulan[$bulan_en] . ' ' . $tahun;
}
