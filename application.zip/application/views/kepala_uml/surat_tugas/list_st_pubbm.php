<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0"><strong>Daftar Surat Tugas PUBBM</strong></h1>
        </div>

        <section class="content">
            <div>
                <button class="btn btn-color-1 mb-3" data-toggle="modal" data-target="#add_st_pubbm"><i class="fa fa-plus"></i> Tambah Surat Tugas</button>
            </div>

            <table class="table box table-sm" id="list_st_pubbm">
                <thead>
                    <tr>
                        <th>NO.</th>
                        <th>NO. SURAT</th>
                        <th>NAMA / KODE SPBU</th>
                        <th>TERA / TERA ULANG</th>
                        <th>KETUA PELAKSANA</th>
                        <th colspan="3" class="text-center">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($surat_tugas as $st): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $st->nomor_st ?></td>
                            <td><?= $st->nama_spbu ?></td>
                            <td><?= $st->ttu ?></td>
                            <td><?= $st->nama_lengkap ?></td>

                            <?php $safe_nomor_st = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $st->nomor_st); ?>
                            <td><a href="<?= base_url('assets/st_pubbm/Surat Tugas Nomor ' . $safe_nomor_st . '.pdf') ?>" target="_blank" class="btn btn-warning btn-sm"> <i class="fas fa-download"></i></a></td>

                                <?php if ($st->status_kirim == 0): ?>
                                    <td>
                                        <?= form_open('kepala_uml/st_pubbm/send'); ?>
                                            <input type="hidden" name="id" value="<?= $st->id ?>">
                                            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-paper-plane"></i></button>
                                        <?= form_close(); ?>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check-circle"></i></button>
                                    </td>
                                <?php endif; ?>

                            <td>
                                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_st_pubbm_<?= $st->id ?>"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>

                        <div class="modal fade" id="delete_st_pubbm_<?= $st->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <?= form_open('kepala_uml/st_pubbm/delete'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"><strong>Hapus ST PUBBM</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $st->id ?>">

                                        <h5>Apakah kamu yakin untuk menghapus ST PUBBM ini?</h5>
                                        <p class="text-danger"><strong>Seluruh cerapan dan SKHP</strong> yang terkait dengan ST ini akan ikut terhapus. Aksi ini <strong>tidak dapat dipulihkan!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Modal Tambah ST PUBBM -->
        <div class="modal fade" id="add_st_pubbm" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <?= form_open('kepala_uml/st_pubbm/add', ['id' => 'form-add-st']); ?>
                    <div class="modal-header">
                        <h5 class="modal-title text-primary"><strong>Tambah Surat Tugas</strong></h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group row">
                            <div class="col-sm-7">
                                <label>No. Surat Tugas</label>
                                <input type="text" name="nomor_st" class="form-control" required>
                            </div>
                            <div class="col-sm-5">
                                <label>Tera / Tera Ulang</label>
                                <select class="form-control" name="ttu" required>
                                    <option value="">-- Pilih --</option>
                                    <option value="Tera">Tera</option>
                                    <option value="Tera Ulang">Tera Ulang</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                                <label>SPBU Pemilik PUBBM</label>
                                <select name="spbu_id" class="form-control" required>
                                    <option value="">-- Pilih SPBU --</option>
                                    <?php foreach ($daftar_spbu as $spbu): ?>
                                        <option value="<?= $spbu->id ?>"><?= $spbu->nama_spbu ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <label>Jumlah Nozzle</label>
                                <input type="number" name="jumlah_nozzle" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Nomor Seri</label>
                            <div id="list-nozzle" class="border rounded p-2" style="min-height: 100px;">
                                <p class="text-muted">Pilih SPBU terlebih dahulu untuk melihat nomor seri nozzle.</p>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-5">
                                <label>Ketua Pelaksana</label>
                                <select class="form-control" name="ketua_pelaksana" id="ketua_pelaksana" required>
                                    <option value="">-- Pilih Ketua Pelaksana --</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?= $user->id_pegawai ?>"><?= $user->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                <label>Tanggal Pelaksanaan</label>
                                <input type="date" name="tgl_pelaksanaan" class="form-control" required>
                            </div>
                            <div class="col-sm-3">
                                <label>Jumlah Pendamping</label>
                                <select class="form-control" name="jumlah_pendamping" id="jumlah_pendamping" required>
                                    <option value="">-- Pilih --</option>
                                    <option value="0">Tidak Ada</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                </select>
                            </div>
                        </div>
                        <div class="row" id="wrapper_pendamping_fields">
                            <div class="col-sm-4" id="pendamping_1_wrapper" style="display: none;">
                                <label for="pendamping_1">Pendamping 1</label>
                                <select class="form-control select-pendamping" name="pendamping_1" id="pendamping_1">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4" id="pendamping_2_wrapper" style="display: none;">
                                <label for="pendamping_2">Pendamping 2</label>
                                <select class="form-control select-pendamping" name="pendamping_2" id="pendamping_2">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-sm-4" id="pendamping_3_wrapper" style="display: none;">
                                <label for="pendamping_3">Pendamping 3</label>
                                <select class="form-control select-pendamping" name="pendamping_3" id="pendamping_3">
                                    <option value="">-- Pilih Pendamping --</option>
                                    <?php foreach ($pegawai as $pgw): ?>
                                        <option value="<?= $pgw->id ?>"><?= $pgw->nama_lengkap ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#list_st_pubbm').DataTable({
        columnDefs: [{
            targets: '_all',
            className: 'text-center align-middle'
        }]
    });

    // Toggle jumlah pendamping
    $('#jumlah_pendamping').on('change', function() {
        var jumlah = parseInt($(this).val());
        $('#pendamping_1_wrapper, #pendamping_2_wrapper, #pendamping_3_wrapper').hide();
        $('#pendamping_1, #pendamping_2, #pendamping_3').val('');

        if (jumlah >= 1) $('#pendamping_1_wrapper').show();
        if (jumlah >= 2) $('#pendamping_2_wrapper').show();
        if (jumlah >= 3) $('#pendamping_3_wrapper').show();

        updateDropdowns(); // update dropdown setelah reset
    });

    // AJAX untuk nozzle
    $('select[name="spbu_id"]').on('change', function () {
        var spbuId = $(this).val();
        if (spbuId) {
            $.ajax({
                url: "<?= base_url('kepala_uml/st_pubbm/get_nozzle_by_spbu') ?>",
                type: "POST",
                data: { spbu_id: spbuId },
                dataType: "json",
                success: function (response) {
                    var html = '';
                    if (response.length > 0) {
                        response.forEach(function (item, i) {
                            html += '<div class="form-check">';
                            html += '<input class="form-check-input" type="checkbox" name="list_nomor_seri[]" value="' + item.nomor_seri + '" id="nozzle_' + i + '">';
                            html += '<label class="form-check-label" for="nozzle_' + i + '">' + item.nomor_seri + '</label>';
                            html += '</div>';
                        });
                    } else {
                        html = '<p class="text-danger">Tidak ada nozzle untuk SPBU ini.</p>';
                    }
                    $('#list-nozzle').html(html);
                },
                error: function () {
                    $('#list-nozzle').html('<p class="text-danger">Gagal mengambil data nozzle.</p>');
                }
            });
        } else {
            $('#list-nozzle').html('<p class="text-muted">Pilih SPBU terlebih dahulu untuk melihat nomor seri nozzle.</p>');
        }
    });

    // Hilangkan opsi yang sudah dipilih di ketua atau pendamping
    function updateDropdowns() {
        var selectedValues = [];

        var ketua = $('select[name="ketua_pelaksana"]').val();
        if (ketua) selectedValues.push(ketua);

        for (var i = 1; i <= 3; i++) {
            var pendampingVal = $('#pendamping_' + i).val();
            if (pendampingVal) selectedValues.push(pendampingVal);
        }

        // Reset semua option visible
        $('select[name="ketua_pelaksana"] option').show();
        for (var i = 1; i <= 3; i++) {
            $('#pendamping_' + i + ' option').show();
        }

        // Sembunyikan yang sudah dipilih
        selectedValues.forEach(function(val) {
            $('select[name="ketua_pelaksana"] option[value="' + val + '"]').not(':selected').hide();
            for (var i = 1; i <= 3; i++) {
                $('#pendamping_' + i + ' option[value="' + val + '"]').not(':selected').hide();
            }
        });
    }

    // Jalankan updateDropdowns saat ada perubahan pilihan
    $('select[name="ketua_pelaksana"]').on('change', function() {
        updateDropdowns();
    });
    $('#pendamping_1, #pendamping_2, #pendamping_3').on('change', function() {
        updateDropdowns();
    });

    // Panggil sekali saat awal buka
    updateDropdowns();
});
</script>
