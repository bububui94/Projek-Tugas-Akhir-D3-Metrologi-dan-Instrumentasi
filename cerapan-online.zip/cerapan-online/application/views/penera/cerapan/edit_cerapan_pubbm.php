<div class="container-fluid text-dark">
    <div class="content-wrapper">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h2 class="h3 mb-0 text-primary"><strong>Form Pemeriksaan PUBBM</strong></h2>
        </div>

        <section class="content">
            <?= form_open('penera/cerapan_pubbm/simpan_form_awal'); ?>
            <input type="hidden" name="id" value="<?= $cerapan->id ?>">

            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pertanyaan Pemeriksaan</th>
                        <th>YA</th>
                        <th>TIDAK</th>
                        <th>Keterangan (Opsional)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <!-- Q1a -->
                        <td>1</td>
                        <td>Apakah PUBBM dilengkapi dengan Izin Tipe (untuk tera)?</td>
                        <td>
                            <input type="radio" name="q1a" value="YA" onchange="checkKesimpulan()"
                            <?= set_radio('q1a','YA', isset($cerapan->q1a) && $cerapan->q1a==='YA') ?>>
                        </td>
                        <td><input type="radio" name="q1a" value="TIDAK" onchange="checkKesimpulan()"
                            <?= set_radio('q1a','TIDAK', isset($cerapan->q1a) && $cerapan->q1a==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q1a" class="form-control"
                            value="<?= set_value('ket_q1a', isset($cerapan->ket_q1a)? $cerapan->ket_q1a : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <!-- Q1b -->
                        <td></td>
                        <td>Apakah spesifikasi teknis PUBBM sesuai dengan Izin Tipenya?</td>
                        <td>
                            <input type="radio" name="q1b" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q1b','YA', isset($cerapan->q1b) && $cerapan->q1b==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q1b" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q1b','TIDAK', isset($cerapan->q1b) && $cerapan->q1b==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q1b" class="form-control"
                            value="<?= set_value('ket_q1b', isset($cerapan->ket_q1b)? $cerapan->ket_q1b : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <!-- Q1c -->
                        <td></td>
                        <td>Apakah terdapat alat tambahan yang bisa merubah spesifikasi atau mempengaruhi hasil ukuran PUBBM?</td>
                        <td>
                            <input type="radio" name="q1c" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q1c','YA', isset($cerapan->q1c) && $cerapan->q1c==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q1c" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q1c','TIDAK', isset($cerapan->q1c) && $cerapan->q1c==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q1c" class="form-control"
                            value="<?= set_value('ket_q1c', isset($cerapan->ket_q1c)? $cerapan->ket_q1c : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Apakah PUBBM digunakan dengan benar?</td>
                        <td>
                            <input type="radio" name="q2a" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q2a','YA', isset($cerapan->q2a) && $cerapan->q2a==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q2a" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q2a','TIDAK', isset($cerapan->q2a) && $cerapan->q2a==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q2a" class="form-control"
                            value="<?= set_value('ket_q2a', isset($cerapan->ket_q2a)? $cerapan->ket_q2a : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Apakah produk BBM yang diukur sesuai dengan yang tertulis pada pelat data?</td>
                        <td>
                            <input type="radio" name="q2b" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q2b','YA', isset($cerapan->q2b) && $cerapan->q2a==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q2b" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q2b','TIDAK', isset($cerapan->q2b) && $cerapan->q2b==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q2b" class="form-control"
                            value="<?= set_value('ket_q2b', isset($cerapan->ket_q2b)? $cerapan->ket_q2b : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Apakah tanda tera sebelumnya masih utuh dan tidak ada yang rusak?</td>
                        <td>
                            <input type="radio" name="q2c" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q2c','YA', isset($cerapan->q2c) && $cerapan->q2c==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q2c" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q2c','TIDAK', isset($cerapan->q2c) && $cerapan->q2c==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q2c" class="form-control"
                            value="<?= set_value('ket_q2c', isset($cerapan->ket_q2c)? $cerapan->ket_q2c : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Apakah semua deskripsi yang wajib jelas terpasang pada pelat data dan terpasang tetap pada PUBBM?</td>
                        <td>
                            <input type="radio" name="q3a" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q3a','YA', isset($cerapan->q3a) && $cerapan->q3a==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q3a" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q3a','TIDAK', isset($cerapan->q3a) && $cerapan->q3a==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q3a" class="form-control"
                            value="<?= set_value('ket_q3a', isset($cerapan->ket_q3a)? $cerapan->ket_q3a : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Apakah identitas pada pelat data lengkap sesuai dengan syarat teknis?</td>
                        <td>
                            <input type="radio" name="q3b" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q3b','YA', isset($cerapan->q3b) && $cerapan->q3b==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q3b" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q3b','TIDAK', isset($cerapan->q3b) && $cerapan->q3b==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q3b" class="form-control"
                            value="<?= set_value('ket_q3b', isset($cerapan->ket_q3b)? $cerapan->ket_q3b : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Apakah identitas pada pelat data mudah terlihat, jelas dan mudah dibaca?</td>
                        <td>
                            <input type="radio" name="q3c" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q3c','YA', isset($cerapan->q3c) && $cerapan->q3c==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q3c" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q3c','TIDAK', isset($cerapan->q3c) && $cerapan->q3c==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q3c" class="form-control"
                            value="<?= set_value('ket_q3c', isset($cerapan->ket_q3c)? $cerapan->ket_q3c : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Apakah PUBBM dalam kondisi lengkap dan bersih?</td>
                        <td>
                            <input type="radio" name="q4" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q4','YA', isset($cerapan->q4) && $cerapan->q4==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q4" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q4','TIDAK', isset($cerapan->q4) && $cerapan->q4==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q4" class="form-control"
                            value="<?= set_value('ket_q4', isset($cerapan->ket_q4)? $cerapan->ket_q4 : '') ?>">
                        </td>
                    <tr>
                        <td>5</td>
                        <td>Apakah PUBBM terpasang dengan kokoh pada pondasinya?</td>
                        <td>
                            <input type="radio" name="q5" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q5','YA', isset($cerapan->q5) && $cerapan->q5==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q5" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q5','TIDAK', isset($cerapan->q5) && $cerapan->q5==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q5" class="form-control"
                            value="<?= set_value('ket_q5', isset($cerapan->ket_q5)? $cerapan->ket_q5 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Apakah tutup penunjukan rusak?</td>
                        <td>
                            <input type="radio" name="q6" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q6','YA', isset($cerapan->q6) && $cerapan->q6==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q6" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q6','TIDAK', isset($cerapan->q6) && $cerapan->q6==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q6" class="form-control"
                            value="<?= set_value('ket_q6', isset($cerapan->ket_q6)? $cerapan->ket_q6 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Apakah gelas penglihat bersih serta penuh dengan produk?</td>
                        <td>
                            <input type="radio" name="q7" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q7','YA', isset($cerapan->q7) && $cerapan->q7==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q7" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q7','TIDAK', isset($cerapan->q7) && $cerapan->q7==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q7" class="form-control"
                            value="<?= set_value('ket_q7', isset($cerapan->ket_q7)? $cerapan->ket_q7 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Apakah penunjukan volume, harga satuan dan harga total sesuai dengan selang yang dipilih?</td>
                        <td>
                            <input type="radio" name="q8" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q8','YA', isset($cerapan->q8) && $cerapan->q8==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q8" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q8','TIDAK', isset($cerapan->q8) && $cerapan->q8==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q8" class="form-control"
                            value="<?= set_value('ket_q8', isset($cerapan->ket_q8)? $cerapan->ket_q8 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>Apakah semua penunjukan terlihat dengan jelas pada semua kondisi siang dan malam?</td>
                        <td>
                            <input type="radio" name="q9" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q9','YA', isset($cerapan->q9) && $cerapan->q9==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q9" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q9','TIDAK', isset($cerapan->q9) && $cerapan->q9==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q9" class="form-control"
                            value="<?= set_value('ket_q9', isset($cerapan->ket_q9)? $cerapan->ket_q9 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Apakah sedang dalam kondisi baik, misal tidak lecet, retak, atau pembungkus selangnya tidak usang?</td>
                        <td>
                            <input type="radio" name="q10" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q10','YA', isset($cerapan->q10) && $cerapan->q10==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q10" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q10','TIDAK', isset($cerapan->q10) && $cerapan->q10==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q10" class="form-control"
                            value="<?= set_value('ket_q10', isset($cerapan->ket_q10)? $cerapan->ket_q10 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>11</td>
                        <td>Apakah masing-masing nozzle menghentikan aliran cairan ketika dikembalikan ke tempat penyimpanannya?</td>
                        <td>
                            <input type="radio" name="q11" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q11','YA', isset($cerapan->q11) && $cerapan->q11==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q11" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q11','TIDAK', isset($cerapan->q11) && $cerapan->q11==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q11" class="form-control"
                            value="<?= set_value('ket_q11', isset($cerapan->ket_q11)? $cerapan->ket_q11 : '') ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Apakah tidak terdapat kebocoran?</td>
                        <td>
                            <input type="radio" name="q12" value="YA" onchange="checkKesimpulan()"
                                <?= set_radio('q12','YA', isset($cerapan->q12) && $cerapan->q12==='YA') ?>>
                        </td>
                        <td>
                            <input type="radio" name="q12" value="TIDAK" onchange="checkKesimpulan()"
                                <?= set_radio('q12','TIDAK', isset($cerapan->q12) && $cerapan->q12==='TIDAK') ?>>
                        </td>
                        <td>
                            <input type="text" name="ket_q12" class="form-control"
                            value="<?= set_value('ket_q12', isset($cerapan->ket_q12)? $cerapan->ket_q12 : '') ?>">
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="form-group mt-3">
                <label for="kesimpulan">Kesimpulan</label>
                <input type="text" id="hasil_kesimpulan" name="hasil_kesimpulan" class="form-control"
                    value="<?= set_value('hasil_kesimpulan', isset($cerapan->hasil_kesimpulan)? $cerapan->hasil_kesimpulan : '') ?>" readonly>
            </div>

            <div class="form-group mt-3">
                <button type="submit" class="btn btn-primary">Selanjutnya</button>
            </div>

            <?= form_close(); ?>
        </section>
    </div>
</div>

<script>
function checkKesimpulan() {
    const kunciJawaban = {
        q1a: "YA", q1b: "YA", q1c: "TIDAK",
        q2a: "YA", q2b: "YA", q2c: "YA",
        q3a: "YA", q3b: "YA", q3c: "YA",
        q4: "YA", q5: "YA", q6: "TIDAK",
        q7: "YA", q8: "YA", q9: "YA", q10: "YA",
        q11: "YA", q12: "YA"
    };

    let sah = true;
    for (let key in kunciJawaban) {
        const pilihan = document.querySelector('input[name="' + key + '"]:checked');
        if (!pilihan || pilihan.value !== kunciJawaban[key]) {
            sah = false;
            break;
        }
    }

    document.getElementById("hasil_kesimpulan").value = sah ? "SAH" : "BATAL";
}

document.addEventListener('DOMContentLoaded', function () {
    if (typeof checkKesimpulan === 'function') checkKesimpulan();
});
</script>
