<link rel="stylesheet" href="<?= base_url() ?>assets/DataTables/datatables.css">
<script src="<?= base_url() ?>assets/DataTables/datatables.js"></script>

<div class="container-fluid">
    <div class="content-wrapper text-dark">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0">
                <strong>Daftar PUBBM</strong>
                <div class="small text-muted">Berdasarkan Nozzle</div>
            </h1>
        </div>

        <section class="content">

            <table class="table box table-sm" id="list_pubbm">
                <thead>
                    <tr>
                        <th class="col-1">NO.</th>
                        <th class="col-2">NAMA/KODE SPBU</th>
                        <th class="col-2">MEREK</th>
                        <th class="col-2">NOMOR SERI</th>
                        <th class="col-2">JENIS BBM</th>
                        <th class="col-2">STATUS</th>
                        <th class="col-1">DETAIL</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($nozzle as $pu) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $pu->nama_spbu ?></td>
                            <td><?= $pu->merek ?></td>
                            <td><?= $pu->nomor_seri ?></td>
                            <td><?= $pu->jenis_bbm ?></td>
                            <td><?= $pu->status ?></td>

                            <td><button class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail_pubbm_<?= $pu->id ?>" type="button"><i class="fas fa-search"></i></button></td>
                        </tr>

                        <div class="modal fade" id="detail_pubbm_<?= $pu->id ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary"> <strong>Detail PUBBM</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Nama/Kode SPBU:</strong> <?= $pu->nama_spbu ?></p>
                                        <p><strong>Merek:</strong> <?= $pu->merek ?></p>
                                        <p><strong>Tahun Pembuatan:</strong> <?= $pu->tahun_pembuatan ?></p>
                                        <p><strong>Model / Tipe:</strong> <?= $pu->model_tipe ?></p>
                                        <p><strong>Nomor Seri:</strong> <?= $pu->nomor_seri ?></p>
                                        <p><strong>Jenis Bahan Bakar Minyak:</strong> <?= $pu->jenis_bbm ?></p>
                                        <p><strong>Kepasitas Maksimum:</strong> <?= $pu->kapasitas_max ?> L/min</p>
                                        <p><strong>Kapasitas Minimum:</strong> <?= $pu->kapasitas_min ?> L/min</p>
                                        <p><strong>Tekanan Maksimum:</strong> <?= $pu->tekanan_max ?>MPa</p>
                                        <p><strong>Suhu Minimum:</strong> <?= $pu->suhu_min ?> °C</p>
                                        <p><strong>Suhu Maksimum:</strong> <?= $pu->suhu_max ?> °C</p>
                                        <p><strong>Status:</strong> <?= $pu->status ?></p>
                                        <?php if ($pu->status == 'Sudah Ditera' || $pu->status == 'Sudah Ditera Ulang') : ?>
                                            <p><strong>Sah / Batal:</strong> <?= $pu->sah_batal == 'SAH' ? '<span class="badge badge-success">SAH</span>' : '<span class="badge badge-danger">BATAL</span>' ?></p>
                                        <?php endif ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-primary"><strong>Logout</strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5 class="text-dark">Apakah kamu yakin untuk keluar?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger" href="<?= base_url('auth/logout') ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        DataTable.type('num', 'className', 'dt-body-right');
        DataTable.type('num-fmt', 'className', 'dt-body-right');
        DataTable.type('date', 'className', 'dt-body-right');

        $('#list_pubbm').DataTable({
            columnDefs: [{
                targets: '_all',
                className: 'text-center align-middle'
            }],
        });
    });
</script>