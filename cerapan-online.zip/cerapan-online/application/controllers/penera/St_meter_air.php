<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class St_meter_air extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('penera/model_st_meter_air');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
        if ($this->session->userdata('id_role') != 3) {
            show_error('Unauthorized access');
        }
    }

    public function index() {
        $id_pegawai = $this->session->userdata('id_pegawai');
        $data['surat_tugas'] = $this->model_st_meter_air->read_sent_for_penera($id_pegawai)->result();
        
        $this->load->view('templates_penera/header');
        $this->load->view('templates_penera/sidebar');
        $this->load->view('penera/daftar_surat_tugas/list_st_meter_air', $data);
        $this->load->view('templates_penera/footer');
    }

    public function accept() {
        $id = $this->input->post('id');
        if (!$id) {
            show_error('Invalid request', 400);
            return;
        }

        // Get the ST record
        $st = $this->model_st_meter_air->get_by_id($id);
        if (!$st) {
            show_error('Surat tugas tidak ditemukan', 404);
            return;
        }

        // Make sure only ketua_pelaksana can accept it
        if ($this->session->userdata('id_pegawai') != $st->ketua_pelaksana) {
            show_error('Unauthorized', 403);
            return;
        }

        // Prevent duplicate acceptance
        if ($st->status_terima == 1) {
            $this->session->set_flashdata('error', 'Surat tugas ini sudah diterima');
            redirect('penera/st_meter_air');
            return;
        }

        // Insert cerapan rows per nomor_seri
        $list_nomor_seri = array_filter(array_map('trim', explode("\n", $st->list_nomor_seri)));

        foreach ($list_nomor_seri as $nomor_seri) {
            $this->db->insert('t_cerapan_meter_air', [
                'id_surat_tugas'    => $st->id,
                'tera_tera_ulang'   => $st->tera_tera_ulang,
                'id_perusahaan'     => $st->id_perusahaan,
                'nomor_seri'        => $nomor_seri,
                'id_pegawai'        => $st->ketua_pelaksana,
            ]);
        }

        // Mark ST as accepted
        $this->model_st_meter_air->update($id, ['status_terima' => 1]);

        $this->session->set_flashdata('success', 'Surat tugas berhasil diterima, dan cerapan berhasil dibuat');
        redirect('penera/st_meter_air');
    }
}